# Claude Code Prompt: PSX Live Terminal — Step 1/4: Scaffold + Layout + WebSocket

## What this is

Step 1 of building a real-time PSX trading terminal in React. This step creates the project, sets up the theme, builds the layout shell, and connects to the WebSocket relay.

**After this step:** You'll have a working app with dark trading terminal theme, navigation between 4 empty pages, and a live 🟢/🔴 connection indicator.

## Project setup

```bash
cd ~/projects
npm create vite@latest psx-live -- --template react-typescript
cd psx-live
npm install
npm install -D tailwindcss @tailwindcss/vite
npm install react-router-dom zustand lightweight-charts lucide-react clsx
```

## Vite config

```ts
// vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 3000,
    proxy: {
      '/api': 'http://localhost:8765',
    }
  }
})
```

## Create these files

### `src/index.css` — Tailwind + dark trading theme

```css
@import "tailwindcss";

:root {
  --bg-primary: #0a0e17;
  --bg-secondary: #0f172a;
  --bg-tertiary: #1e293b;
  --bg-hover: #334155;
  --text-primary: #f1f5f9;
  --text-secondary: #94a3b8;
  --text-muted: #475569;
  --green: #22c55e;
  --green-bg: rgba(34,197,94,0.15);
  --red: #ef4444;
  --red-bg: rgba(239,68,68,0.15);
  --blue: #3b82f6;
  --border: #1e293b;
}

body {
  background: var(--bg-primary);
  color: var(--text-primary);
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, system-ui, monospace;
  margin: 0;
}

@keyframes flash-green {
  0% { background-color: rgba(34,197,94,0.4); }
  100% { background-color: transparent; }
}
@keyframes flash-red {
  0% { background-color: rgba(239,68,68,0.4); }
  100% { background-color: transparent; }
}
.flash-up { animation: flash-green 0.3s ease-out; }
.flash-down { animation: flash-red 0.3s ease-out; }

::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: var(--bg-primary); }
::-webkit-scrollbar-thumb { background: var(--bg-tertiary); border-radius: 3px; }
```

### `src/types/market.ts` — All TypeScript interfaces

```typescript
export interface Tick {
  symbol: string;
  market: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  high: number;
  low: number;
  bid?: number;
  ask?: number;
  bidVol?: number;
  askVol?: number;
  trades?: number;
  timestamp: number;
}

export interface IndexTick {
  symbol: string;
  value: number;
  change: number;
  changePercent: number;
  volume: number;
  turnover: number;
  high: number;
  low: number;
  open: number;
  previousClose: number;
  timestamp: number;
}

export interface WSMessage {
  type: "tick" | "snapshot";
  data: Tick | IndexTick;
}

export interface MarketBreadth {
  gainers: number;
  losers: number;
  unchanged: number;
}

export interface Snapshot {
  connected: boolean;
  tick_count: number;
  symbol_count: number;
  index_count: number;
  ws_clients: number;
  symbols: Tick[];
  indices: IndexTick[];
}
```

### `src/lib/ws.ts` — WebSocket manager with auto-reconnect

Single manager that:
- Connects to ws://localhost:8765 channels
- Auto-reconnects with exponential backoff (2s → 4s → 8s → max 30s)
- Exposes `connected` state
- Supports multiple subscriptions per channel
- Returns cleanup functions from connect() and subscribe()

### `src/lib/api.ts` — REST client

```typescript
const BASE = "http://localhost:8765";

export const api = {
  snapshot: (): Promise<Snapshot> => fetch(`${BASE}/snapshot`).then(r => r.json()),
  symbol: (sym: string) => fetch(`${BASE}/symbol/${sym}`).then(r => r.json()),
  health: () => fetch(`${BASE}/health`).then(r => r.json()),
  stats: () => fetch(`${BASE}/stats`).then(r => r.json()),
};
```

### `src/lib/format.ts` — Number formatters

```typescript
export const fmtPrice = (n: number) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
export const fmtPct = (n: number) => `${n >= 0 ? '+' : ''}${(n * 100).toFixed(2)}%`;
export const fmtVol = (n: number) => {
  if (n >= 1e9) return `${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(2)}M`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
  return n.toString();
};
export const fmtInt = (n: number) => n.toLocaleString('en-US');
```

### `src/components/Layout.tsx` — Top bar + router outlet

```
┌──────────────────────────────────────────────────────────┐
│  📈 PSX LIVE    Dashboard  Market  Heatmap    🟢 LIVE    │
├──────────────────────────────────────────────────────────┤
│                                                          │
│                     <Outlet />                           │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

- Sticky top bar with dark background (#0f172a), border-bottom
- Left: "PSX LIVE" logo text in bold white
- Center: Nav links (Dashboard, Market, Heatmap) — active has blue underline
- Right: ConnectionBadge component
- Uses react-router-dom `<NavLink>` for active state
- `<Outlet />` for page content below

### `src/components/ConnectionBadge.tsx`

- Shows 🟢 dot + "LIVE" in green when WebSocket connected
- Shows 🔴 dot + "OFFLINE" in red with pulse animation when disconnected
- Reads connection state from the WebSocket manager
- Small text below showing tick count or "Connecting..."

### `src/pages/Dashboard.tsx` — Placeholder

```tsx
export default function Dashboard() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-slate-200">Dashboard</h1>
      <p className="text-slate-400 mt-2">KSE-100 + Indices — coming in Step 2</p>
    </div>
  );
}
```

### `src/pages/LiveMarket.tsx` — Placeholder

Same pattern, says "Market table — coming in Step 3"

### `src/pages/SymbolDetail.tsx` — Placeholder

Same pattern, reads `:symbol` from URL params, shows "Symbol detail for {symbol} — coming in Step 3"

### `src/pages/Heatmap.tsx` — Placeholder

Same pattern, says "Sector heatmap — coming in Step 4"

### `src/App.tsx` — Router setup

```tsx
Routes:
  /                → Dashboard
  /market          → LiveMarket
  /symbol/:symbol  → SymbolDetail
  /heatmap         → Heatmap
  
All wrapped in Layout component.
```

### `src/main.tsx` — Entry with BrowserRouter

Standard Vite entry wrapping App in BrowserRouter.

## VERIFY

```bash
cd ~/projects/psx-live
npm run dev
# Browser: http://localhost:3000
# Should see: dark theme, nav bar, "Dashboard" placeholder, connection badge
# Click Market → shows market placeholder
# Click Heatmap → shows heatmap placeholder
# Connection badge: 🔴 OFFLINE if tick_service not running, 🟢 LIVE if running
npx tsc --noEmit  # no TypeScript errors
```

## Files created in this step

| File | Purpose |
|------|---------|
| `vite.config.ts` | Vite + Tailwind + proxy |
| `src/index.css` | Tailwind + dark theme + animations |
| `src/main.tsx` | Entry point |
| `src/App.tsx` | Router + Layout |
| `src/types/market.ts` | All TypeScript interfaces |
| `src/lib/ws.ts` | WebSocket manager |
| `src/lib/api.ts` | REST client |
| `src/lib/format.ts` | Number formatters |
| `src/components/Layout.tsx` | Top bar + nav + outlet |
| `src/components/ConnectionBadge.tsx` | Live/offline indicator |
| `src/pages/Dashboard.tsx` | Placeholder |
| `src/pages/LiveMarket.tsx` | Placeholder |
| `src/pages/SymbolDetail.tsx` | Placeholder |
| `src/pages/Heatmap.tsx` | Placeholder |
