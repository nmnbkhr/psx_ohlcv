# pakfindata — Sections 4-7: FX, Commodities, Funds & Research

---

# Section 4: FX & Rates

## The Currency Desk

Pakistan's FX market operates across three layers: SBP interbank (official), open market (exchange companies), and kerb (informal). The spread between these layers signals currency pressure. pakfindata monitors all three.

---

## Page 1: FX Rates Terminal

### What You See

**Seven tabs:** Overview, Charts, Spreads, Volatility, Carry, FX Signals, Sync.

**Overview — Header Cards:**
- USD/PKR Interbank: 279.36 (-0.06)
- USD/PKR Open Market: 280.25
- USD/PKR Kerb: 280.25
- Kerb Premium: +0.89
- DXY Index: 99.22

**Currency Rates Comparison — five currency pairs, three markets each:**

| Pair | Interbank | Open Market | Kerb | Spread |
|------|-----------|-------------|------|--------|
| USD/PKR | 278.93 | 279.20 | 279.20 | +0.27 |
| EUR/PKR | 329.87 | 319.90 | 319.90 | -9.97 |
| GBP/PKR | 377.63 | 370.36 | 370.36 | -7.27 |
| SAR/PKR | 74.47 | 73.85 | 73.85 | +0.62 |
| AED/PKR | 76.40 | 75.55 | 75.55 | -0.85 |

**All Currency Rates table:** Full interbank rates from SBP.

### Business Value

**The spread is the signal.** USD/PKR interbank at 278.93 vs open market at 279.20 — only Rs. 0.27 spread. That's healthy. When spreads widen to Rs. 5-10, it signals currency pressure and potential devaluation.

EUR/PKR shows a -9.97 spread (open market BELOW interbank) — unusual, suggesting EUR oversupply in the open market. Corporate treasurers hedging EUR receivables use this to time their conversions.

**For remittance companies:** SAR/PKR open market at 73.85 vs interbank at 74.47 — the Rs. 0.62 premium represents remittance corridor economics. Monitoring this spread drives pricing decisions for Roshan Digital Account (RDA) products.

### Target Audience

Bank FX desks, corporate treasurers, remittance companies, trade finance teams, SBP monitoring teams, overseas Pakistani investors.

---

## Page 2: FX Dashboard / Interbank vs Open / Rate History

### What You See

These pages provide deeper FX analysis:
- **Historical FX charts:** USD/PKR trends over months/years
- **Interbank vs Open Market spread history:** when did spreads blow out?
- **NBP TT Buying/Selling rates:** the official commercial rates
- **Cross-currency movements:** EUR, GBP, SAR, AED, CNY against PKR

### Business Value

A corporate treasurer planning FX forward covers looks at 3-month rate history. "PKR has been stable at 278-280 for 2 months — low volatility means forward points are cheap." This informs hedging strategy.

### Target Audience

FX dealers, corporate treasurers, trade finance teams, economists, remittance pricing teams.

---

# Section 5: Commodities

## Cross-Asset Context for Pakistan

Commodity prices directly impact Pakistan's economy — oil imports drive current account deficit, cotton affects textile sector, gold affects jewelry and investment demand.

---

## Page 1: Commodities Terminal

### What You See

**Seven tabs:** Dashboard, Charts, Categories, Pakistan View, Local Markets, PMEX Portal, Export.

**Market Snapshot — eight key commodities:**

| Commodity | Price | Change |
|-----------|-------|--------|
| Gold (USD/oz) | 4,474.90 | +1.61% |
| Brent Crude (USD/bbl) | 100.04 | +0.10% |
| Cotton #2 (USD/lb) | 67.34 | +0.24% |
| Wheat (USD/bu) | 591.75 | +0.68% |
| Natural Gas (USD/mmbtu) | 2.87 | -0.90% |
| USD/PKR | 278.93 | +0.57% |
| Sugar #11 (USD/lb) | 15.90 | +2.45% |
| Copper (USD/lb) | 5.56 | +2.18% |

**30-Day Trends:** Sparkline charts for Gold, Brent, Cotton, Wheat — visual trend at a glance.

**Sector Performance (Latest Session):** Agriculture (+2.78%), Livestock (+2.15%), Metals (+1.49%), Energy (+0.85%) — commodity sector breakdown.

**Pakistan Prices (PKR):** Local conversion table:

| Commodity | Symbol | PKR Price | Unit | Date | USD/PKR |
|-----------|--------|-----------|------|------|---------|
| Brent Crude | BRENT | 175.51 | PKR/litre | 2026-03-24 | 278.93 |
| Cotton #2 | COTTON | 1,545,586.89 | PKR/maund | 2026-03-24 | 278.93 |
| Crude Oil WTI | CRUDE_WTI | 155.07 | PKR/litre | 2026-03-24 | 278.93 |

### Business Value

Oil at $100/bbl means Pakistan's current account deficit widens — bearish for PKR. Cotton at 67.34 USD/lb translates to Rs. 15.4 lakh/maund — textile companies' raw material cost visible instantly.

**PMEX Portal tab:** Directly integrates Pakistan Mercantile Exchange data — commodity futures OI, margins, and OHLC for locally traded contracts.

A cement company treasurer checks natural gas at $2.87 (energy cost input) alongside Brent at $100 (transport cost) — both inputs to production cost calculations.

### Target Audience

Commodity traders, agricultural enterprises, energy sector analysts, corporate procurement, PMEX traders, textile companies (cotton monitoring), oil refineries, fertilizer companies.

---

# Section 6: Funds

## Pakistan's Rs. 2 Trillion Mutual Fund Industry

MUFAP (Mutual Funds Association of Pakistan) oversees 1,200+ funds. pakfindata provides the most comprehensive fund analytics platform outside of Bloomberg.

---

## Page 1: Fund & ETF Explorer

### What You See

**Eight views:** Mutual Funds, ETFs, VPS Pension, Top Performers, Compare Funds, Risk Analytics, Factor Analysis, LLM Analysis, Sync & Tools.

**Fund Universe Summary:**
- EQUITY: 86 funds (YTD -12.6%, 1M +3.2%)
- INCOME / MM: 420 funds (YTD +33.1%, 1M +30.6%)
- ISLAMIC: 425 funds (YTD +7.5%, 1M +4.4%)
- VPS PENSION: 68 funds (YTD +12.4%, 1M +7.9%)

**Filter Bar:** Category, AMC (asset management company), Shariah (compliant/conventional), Type (open/close-end), Search by name.

**Fund Table (1,208 funds):**

| Symbol | Fund | Category | NAV | 1M % | 3M % |
|--------|------|----------|-----|------|------|
| 786-14750 | 786 Islamic Money Market Fund | Shariah Money Market | 107.28 | +9.04% | +8.99 |
| F037 | 786 Smart Fund | Shariah Income | 89.93 | +9.78% | +9.81 |
| ABL-BAL | ABL Balanced Fund | Balanced | 24.77 | -2.23% | -1.47 |
| ABL-CSF | ABL Cash Fund | Money Market | 10.53 | +9.18% | +9.48 |

**Fund Detail View:** Select any fund → category, AMC, type, expense ratio, NAV chart, risk metrics (Sharpe, max drawdown, volatility), performance comparison.

### Business Value

**1,208 funds searchable and sortable** — every Pakistani mutual fund and pension scheme in one table. A wealth manager selecting funds for a client portfolio:
- Filters by "Shariah Compliant" → 425 Islamic funds
- Sorts by 1M return → finds top performers
- Clicks "Compare Funds" → side-by-side NAV comparison
- Checks "Risk Analytics" → Sharpe ratio, drawdown profile

**Income/Money Market funds returning +33% YTD** reflects the high-rate environment (SBP at 10.5%). This data point alone justifies client conversations about fixed income allocation.

**MUFAP NAV data auto-synced** — no manual downloads from mufap.com.pk.

### Target Audience

Wealth managers, fund distributors, pension fund selectors, retail investors, AMC sales teams, SECP fund regulation teams, insurance investment teams.

---

## Page 2: VPS Pension / Top Performers / Fund Analytics / ETFs

### What You See

**VPS Pension:** 68 voluntary pension scheme sub-funds — equity, debt, money market allocations tracked separately. Critical for employers selecting pension providers.

**Top Performers:** Ranked by 1M, 3M, 6M, 1Y returns across categories. Instantly see which AMC is winning.

**Fund Analytics:** Risk-return scatter plots, Sharpe ratio rankings, correlation matrices across fund categories.

**ETFs:** Pakistan's small but growing ETF market — NAV, premium/discount to NAV, tracking error.

### Business Value

Pakistan's pension market is nascent but growing fast (mandatory pensions proposed in 2026). VPS analytics helps employers select the best pension provider — a decision affecting thousands of employees' retirement savings.

### Target Audience

HR departments (pension selection), pension fund consultants, AMC distribution teams, SECP pension oversight.

---

# Section 7: Research (Quantitative Analytics)

## The Quant Lab

This is pakfindata's deepest technical section — institutional-grade quantitative analytics that don't exist anywhere else for PSX.

---

## Page 1: Signal Analysis (Composite Signal Scanner)

### What You See

**Batch Scanner:** Select "ALL" → scan 500+ symbols → ranked by composite score 1-100.

**Single Symbol Deep Dive (HUBC example — score 80):**

**Layer 1 — Macro Regime (27/33):**
- Hurst Exponent: 0.665 → TRENDING (favors momentum)
- Annualized Volatility: 37.44% → MODERATE
- SMA-200: PKR 197.02 — price is ABOVE (+0.37%)
- Sector: POWER GENERATION & DISTRIBUTION
- Circuit Breaker (5d): None

**Layer 2 — Intraday Anchor (33/33):**
- VWAP Distance: -0.49σ (within normal range)
- POC (Point of Control): PKR 197.01
- Value Area: PKR 192-200
- ER Status: Clean (no earnings risk)
- VWAP Bands + Volume Profile chart: 5 days of intraday bands with volume concentration zones

**Layer 3 — Execution DNA (19/33):**
- Ticks: 18,244 (2 days of data)
- Buy/Sell split: 50.1% / 49.9% — balanced
- CVD Slope: +0.0004 (slight accumulation)
- Recent OFI (15m): +0.376 (buyers dominant recently)
- VPIN: 0.395 → LOW (no toxic flow)
- Blocks: 0 | Bias: NEUTRAL
- CVD & Block Trades chart: price vs cumulative volume delta
- Order Flow Imbalance chart: per-minute buy/sell pressure

**Intelligence Brief — Cross-Data Summary:**
- Price Action: Close 269.89, Range 268-272, Volume 8,170
- Microstructure: No block trades
- Derivatives: Futures 273.27 (APR), Basis +3.38 (+1.252%) — Premium (Bullish), Fut Volume 0
- Institutional: Index weight 0.215%

**Quant Analyst Commentary (AI-generated):**
"Strong Signal — Composite score of 80/100 indicates high confluence across macro, intraday, and execution layers. Macro Regime (27/33): Hurst = 0.665, trending regime — momentum strategies favored. Momentum: BEARISH (20/60 SMA crossover). Intraday (33/33): Price is -0.49σ from VWAP — within normal range."

### Business Value

This is **the crown jewel of pakfindata**. Nothing like this exists for PSX at any price:

1. **Three-layer signal architecture** combines macro (what's the regime?), intraday (where's the anchor?), and execution (who's buying/selling?) — each contributes 33 points to a 100-point score
2. **Batch scanner** scores 500+ symbols in seconds — find the strongest setups market-wide
3. **VPIN toxicity** detects informed trading before price moves — an early warning system
4. **CVD + Order Flow** shows the battle between buyers and sellers at the tick level
5. **AI commentary** synthesizes all three layers into plain English

A prop trader's daily workflow: Batch scan at 9:30 AM → filter top 10 scores → drill into each → check Layer 3 execution signals → trade the highest-conviction setups.

### Target Audience

Proprietary traders, quantitative fund managers, systematic strategy developers, institutional execution desks, academic researchers.

---

## Page 2: Market Microstructure & Risk

### What You See

**VPIN Toxicity Monitor:** Large gauge dial showing current VPIN (0.173 — SAFE zone in green). VPIN Statistics: Current 0.1731, Mean 0.1737, Max 0.2521, Std Dev 0.0538. Buckets: 200, Size: 9,602.

**Volume Bucket Flow:** Stacked bar chart — red (sell volume) vs green (buy volume) per bucket, with VPIN line overlay. Shows the balance between aggressive buyers and sellers over time.

**Trade Size Distribution, Order Flow Imbalance, Bid-Ask Spread Analysis, Tick Table** — all below.

### Business Value

VPIN (Volume-Synchronized Probability of Informed Trading) is used by CME and major exchanges for market surveillance. It predicted the 2010 Flash Crash 2 hours before it happened. pakfindata brings this institutional tool to PSX.

When VPIN spikes above 0.7, it means informed traders are likely active — the market is about to move. A risk manager can tighten stops or reduce position size. A market maker can widen spreads to protect themselves.

### Target Audience

Algorithmic traders, market surveillance teams, exchange compliance, risk managers, academic researchers studying market microstructure.

---

## Page 3: Tick Analytics Terminal

### What You See

**Overview:** Market-wide tick metrics — 483,886 total ticks, 485 symbols traded, 375.3M volume, PKR 22.98B turnover, 282,143 trades, 1,215 ticks/min. Breadth: A/D ratio 0.40, Breadth -41%. Microstructure: Median spread 0.0 bps, P90 spread 0.0 bps, Cross-sec vol 4.43%, Top-10 concentration 48.4%, 176 futures active.

**Daily KPI History:** Table of per-day market-wide metrics with vs-average comparisons.

**Sync Tab:** JSONL → DuckDB import buttons, tick_bars.db sync, Full Nightly Sync.

### Business Value

"How liquid was the market today?" — answered with one number (1,215 ticks/min). "How concentrated?" — 48.4% of volume in top 10 names. "How was breadth?" — 134 advancers vs 333 decliners. These are institutional quality metrics.

### Target Audience

Market makers, exchange surveillance, quantitative researchers, fund managers assessing market conditions.

---

## Page 4: Tick Replay

### What You See

60fps client-side replay using TradingView Lightweight Charts:
- Play/Pause, speed 0.1x to 500x
- Timeline scrubber — drag to any moment
- Live stats: price, change, OHLC, volume, trades, VWAP
- Order book: bid, ask, spread, imbalance
- Last 5 trades: tick log with buy/sell coloring
- All running in browser JavaScript — zero Streamlit rerenders

### Business Value

"What happened at 11:47 AM when the stock dropped 3%?" — a compliance officer drags the scrubber to 11:47 and watches tick-by-tick. Was there unusual volume? Did the spread widen? Were there block trades? All visible in the replay.

A trading coach reviews a trainee's fills: "You bought at 11:52 but the VWAP was 0.5% lower 3 minutes earlier — you could have gotten a better price."

### Target Audience

Compliance/surveillance teams, trade analysis, execution quality assessment, trading education, market research.

---

## Page 5: Quant Lab / Macro Cycles / Sector Breadth / Market Research

### What You See

**Quant Lab:** Multi-timeframe analysis workspace using PSX Terminal klines (1m-1w). Strategy backtesting sandbox.

**Macro Cycles:** SBP EasyData integration — CPI trends, money supply (M2), balance of payments, GDP growth. Macro regime identification with interest rate cycle overlay.

**Sector Breadth:** Per-sector advance/decline tracking. Breadth divergence detection — when the index rises but fewer sectors participate, it's a warning signal.

**Market Research:** AI-powered research synthesis combining market data with narrative analysis.

### Business Value

Macro Cycles answers: "We're in an easing cycle — which sectors historically outperform when SBP cuts rates?" Using 195 SBP EasyData datasets with 20+ years of history.

Sector Breadth answers: "KSE-100 up 0.8% but only 2 of 35 sectors are green — rally is narrow and vulnerable."

### Target Audience

Macro strategists, asset allocators, systematic researchers, fund managers making top-down decisions.

---

## Section Summaries

### Section 4: FX & Rates

| Page | Key Feature | Differentiator |
|------|-------------|----------------|
| FX Terminal | 5 pairs × 3 markets (interbank/open/kerb) | Spread monitoring across market layers |
| Charts/History | Historical FX trends | NBP TT rates + interbank + kerb |

### Section 5: Commodities

| Page | Key Feature | Differentiator |
|------|-------------|----------------|
| Commodities Terminal | 8 commodities + PKR conversion | Pakistan View + PMEX Portal integration |

### Section 6: Funds

| Page | Key Feature | Differentiator |
|------|-------------|----------------|
| Fund Explorer | 1,208 funds, Shariah filter | Most comprehensive Pakistani fund database |
| VPS/Performers | Pension analytics, rankings | Only free VPS analytics platform |

### Section 7: Research

| Page | Key Feature | Differentiator |
|------|-------------|----------------|
| Signal Analysis | 3-layer composite score (100pt) | **Only multi-factor signal scanner for PSX** |
| Microstructure | VPIN toxicity + order flow | Exchange-grade microstructure analytics |
| Tick Analytics | Market-wide tick metrics | 4.6M+ ticks in DuckDB |
| Tick Replay | 60fps client-side playback | TradingView charts, 0.1x-500x speed |
| Quant Lab | Multi-timeframe strategies | PSX Terminal klines integration |
| Macro Cycles | SBP EasyData (195 datasets) | 20-year macro-financial linkages |

---

## The Complete pakfindata Terminal

**Total pages documented: 34+**

| Section | Pages | Key Audience |
|---------|-------|-------------|
| S1: Market Overview | 3 | Everyone |
| S2: Equities | 9 | Stock traders, analysts |
| S3: Fixed Income | 5 | Treasury, bond traders |
| S4: FX & Rates | 2 | FX desks, corporates |
| S5: Commodities | 1 | Commodity traders, procurement |
| S6: Funds | 2 | Wealth managers, AMCs |
| S7: Research | 6+ | Quants, prop traders |

**What no other platform offers for PSX:**
1. VPIN toxicity monitoring
2. 3-layer composite signal scoring
3. 60fps tick replay
4. CHEAP/RICH bond signals
5. Real OI derivatives analytics
6. 20-year rate history with SBP annotations
7. 1,208 mutual funds with Shariah filter
8. DuckDB-powered analytics (104x faster)
9. Integrated SBP macro data (195 datasets)
10. Commodity prices in PKR with PMEX portal

---

*Built by Godaitec (godai.tech) — Karachi, Pakistan*
