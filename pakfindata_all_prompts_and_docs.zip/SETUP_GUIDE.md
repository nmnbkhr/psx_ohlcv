# FX Trading Module — Complete Setup Guide
## WSL2 + Conda + VS Code

---

## Prerequisites Checklist

- [x] WSL2 running (Ubuntu 24)
- [x] Conda installed in WSL
- [x] VS Code with Remote-WSL extension
- [x] E: drive accessible at `/mnt/e/`

---

## Step 1: Create the Project Folder

```bash
# Create project directory and data directory
mkdir -p /mnt/e/fx/{db,logs,exports}
mkdir -p /mnt/e/projects/fx-trading-module

# Unzip the module (adjust path to where you downloaded it)
# If you downloaded to Windows Downloads:
cp /mnt/c/Users/<YOUR_USERNAME>/Downloads/fx-trading-module.zip /mnt/e/projects/
cd /mnt/e/projects
unzip fx-trading-module.zip
cd fx-trading-module
```

---

## Step 2: Create Conda Environment

```bash
# Create a dedicated conda env for FX module
conda create -n fx python=3.11 -y

# Activate it
conda activate fx

# Verify
python --version
# Should show: Python 3.11.x
```

---

## Step 3: Install Dependencies

```bash
# Make sure you're in the project folder with env active
cd /mnt/e/projects/fx-trading-module
conda activate fx

# Install all Python packages
pip install -r requirements.txt

# Verify key packages
python -c "import fastapi; print(f'FastAPI {fastapi.__version__}')"
python -c "import yfinance; print(f'yfinance {yfinance.__version__}')"
python -c "import pandas; print(f'pandas {pandas.__version__}')"
python -c "import uvicorn; print(f'uvicorn {uvicorn.__version__}')"
python -c "import streamlit; print(f'streamlit {streamlit.__version__}')"
python -c "import pdfplumber; print(f'pdfplumber {pdfplumber.__version__}')"  # Required for SBP M2M PDFs
```

---

## Step 4: Configure API Keys (Optional but Recommended)

```bash
# Copy example env file
cp .env.example .env

# Edit with your keys
nano .env
```

**Get free API keys:**

| Service | Free Tier | Signup URL |
|---------|-----------|------------|
| Alpha Vantage | 25 req/day | https://www.alphavantage.co/support/#api-key |
| FCSAPI | 30 req/hr | https://fcsapi.com/dashboard |

```bash
# Set them in your shell (add to ~/.bashrc for persistence)
echo 'export ALPHA_VANTAGE_KEY=your_key_here' >> ~/.bashrc
echo 'export FCSAPI_KEY=your_key_here' >> ~/.bashrc
source ~/.bashrc
```

> **Note:** yfinance works without any API key. If you skip this step,
> the module still works — just with fewer data sources.

---

## Step 5: Verify Data Directory

```bash
# Check the E: drive path exists
ls -la /mnt/e/fx/
# Should show: db/  logs/  exports/

# Test write access
touch /mnt/e/fx/test.txt && rm /mnt/e/fx/test.txt && echo "Write OK"
```

---

## Step 6: Initial Historical Data Load (One-Time)

```bash
cd /mnt/e/projects/fx-trading-module
conda activate fx

# Load 1 year of historical OHLCV data for all pairs
python main.py --initial-load

# This takes 2-3 minutes. You'll see output like:
#   Fetching OHLCV via yfinance: 16 pairs, period=1y, interval=1d
#   Collected 4000+ total OHLCV candles via yfinance
#   Initial load complete: 4000+ candles loaded
```

---

## Step 7: Run First Full Collection

```bash
# Collect live data from all sources
python main.py --collect

# You'll see:
#   Starting full collection run
#   Fetching SBP interbank rates via M2M PDF...
#   Got 35 rates from M2M PDF dated 2026-02-18       ← 35 currencies!
#   Fetching open market rates...
#   Fetching current KIBOR rates from SBP...
#     KIBOR 3M: Bid=10.30% Offer=10.55%
#     KIBOR 6M: Bid=10.31% Offer=10.56%
#     KIBOR 12M: Bid=10.33% Offer=10.83%
#   Fetching latest rates via yfinance...
#   Collection Summary:
#     sbp_interbank: 35
#     open_market: X
#     kibor: 3-4
#     international_rates: X
#     international_ohlcv: X
```

---

## Step 8: Generate First Signal Report

```bash
# Generate and print trading signals
python main.py --report

# Output looks like:
#   ════════════════════════════════════════════════════
#   FX TRADING SIGNAL REPORT
#   Date: 2026-02-19
#   ════════════════════════════════════════════════════
#   📊 OVERALL: MILDLY POSITIVE — Moderate conditions
#      Score: 2 | Action: Selective positioning
#   💰 CARRY TRADE:
#      🟢 USD: +12.00% differential | strong_carry
#   📈 PREMIUM SPREAD:
#      🟢 USD/PKR: +0.45% | normal
#   🏦 SBP INTERVENTION:
#      ✅ No intervention detected
```

---

## Step 9: Check Database Status

```bash
python main.py --status

# Shows:
#   FX Trading Module — Database Status
#   Database: /mnt/e/fx/db/fx_trading.db
#   fx_rates          :    X records
#   fx_ohlcv          :    X records
#   kibor_rates       :    X records
#   TOTAL             :    X records
#
#   Latest USD/PKR:
#     Source: yfinance
#     Mid: 278.XXXX
```

---

## Step 10: Start the API Service

```bash
# Terminal 1: Start FastAPI microservice
cd /mnt/e/projects/fx-trading-module
conda activate fx

uvicorn api.service:app --host 0.0.0.0 --port 8100 --reload

# You'll see:
#   INFO:     Uvicorn running on http://0.0.0.0:8100
#   INFO:     Started reloader process
```

**Test it — open a new terminal:**

```bash
# Health check
curl http://localhost:8100/health
# {"status":"healthy","service":"fx-trading-module","db_records":4523}

# Get snapshot (everything in one call)
curl http://localhost:8100/snapshot | python -m json.tool

# Get latest rates
curl http://localhost:8100/rates/latest | python -m json.tool

# Get KIBOR
curl http://localhost:8100/kibor | python -m json.tool

# Get signal report
curl http://localhost:8100/signals/report | python -m json.tool

# Trigger collection via API
curl -X POST http://localhost:8100/collect
# {"status":"started","type":"full"}

# Swagger docs (open in browser)
echo "Open: http://localhost:8100/docs"
```

---

## Step 11: Start the Background Scheduler

```bash
# Terminal 2: Run scheduled data collection
cd /mnt/e/projects/fx-trading-module
conda activate fx

python main.py --schedule

# Collects automatically:
#   Pakistan market hours (Mon-Fri 9:30-15:30 PKT): every 30 min
#   International forex hours: every 60 min
#   Off hours: skips
```

---

## Step 12: Launch Streamlit Dashboard (Optional)

```bash
# Terminal 3: Interactive dashboard
cd /mnt/e/projects/fx-trading-module
conda activate fx

streamlit run dashboard/app.py --server.port 8501

# Open in browser: http://localhost:8501
```

---

## Step 13: Open in VS Code

```bash
# From WSL terminal:
cd /mnt/e/projects/fx-trading-module
code .

# This opens VS Code with Remote-WSL connected
```

**VS Code setup:**

1. When VS Code opens, it will ask to select a Python interpreter
2. Click the Python version in the bottom status bar
3. Select: `~/miniconda3/envs/fx/bin/python` (or wherever your conda env is)
4. Install recommended extensions if prompted:
   - Python
   - Pylance

**VS Code terminal shortcut:**

Press `` Ctrl+` `` to open integrated terminal, then:

```bash
conda activate fx
python main.py --status
```

---

## Step 14: Connect to PSX OHLCV App

Copy `client/fx_client.py` into your PSX OHLCV project:

```bash
# Copy the client adapter to your PSX OHLCV sources
cp /mnt/e/projects/fx-trading-module/client/fx_client.py \
   /path/to/your/psx-ohlcv/sources/fx_client.py
```

Then in your PSX OHLCV code:

```python
from sources.fx_client import FXClient

fx = FXClient("http://localhost:8100")

# Always check health first — graceful degradation
if fx.is_healthy():
    snapshot = fx.get_snapshot()
    regime = fx.get_regime()
else:
    # FX is down, equity app keeps running
    pass
```

---

## Daily Workflow

```bash
# Morning: activate env, start services
conda activate fx

# Tab 1: API
cd /mnt/e/projects/fx-trading-module
uvicorn api.service:app --host 0.0.0.0 --port 8100

# Tab 2: Scheduler (auto-collects during market hours)
cd /mnt/e/projects/fx-trading-module
python main.py --schedule

# Check signals anytime
curl http://localhost:8100/signals/report | python -m json.tool
```

---

## Useful Commands Cheat Sheet

```bash
# ─── Data ────────────────────────────────────────
python main.py --collect                # Collect all data now
python main.py --collect --signals      # Collect + generate signals
python main.py --report                 # Print signal report
python main.py --status                 # Show DB status
python main.py --initial-load           # Re-load 1yr history

# ─── API ─────────────────────────────────────────
uvicorn api.service:app --host 0.0.0.0 --port 8100 --reload

# ─── Scheduler ───────────────────────────────────
python main.py --schedule               # Auto-collect during market hours

# ─── Dashboard ───────────────────────────────────
streamlit run dashboard/app.py --server.port 8501

# ─── Quick API Tests ─────────────────────────────
curl localhost:8100/health
curl localhost:8100/snapshot
curl localhost:8100/rates/interbank
curl localhost:8100/kibor
curl localhost:8100/signals/carry
curl localhost:8100/signals/regime
curl -X POST localhost:8100/collect

# ─── Database ────────────────────────────────────
sqlite3 /mnt/e/fx/db/fx_trading.db ".tables"
sqlite3 /mnt/e/fx/db/fx_trading.db "SELECT pair, date, mid FROM fx_rates ORDER BY date DESC LIMIT 10;"
sqlite3 /mnt/e/fx/db/fx_trading.db "SELECT COUNT(*) FROM fx_ohlcv;"

# ─── Logs ────────────────────────────────────────
tail -f /mnt/e/fx/logs/fx_$(date +%Y-%m-%d).log

# ─── Conda ───────────────────────────────────────
conda activate fx
conda deactivate
conda env list
```

---

## Folder Layout After Setup

```
/mnt/e/
├── fx/                                 # Data (persistent)
│   ├── db/
│   │   └── fx_trading.db              # SQLite database
│   ├── logs/
│   │   └── fx_2026-02-19.log          # Daily logs
│   └── exports/                        # CSV/Parquet exports
│
└── projects/
    └── fx-trading-module/              # Code (this project)
        ├── api/
        ├── client/
        ├── collectors/
        ├── config/
        ├── dashboard/
        ├── indicators/
        ├── storage/
        ├── utils/
        ├── main.py
        ├── requirements.txt
        └── Dockerfile
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `ModuleNotFoundError` | Make sure `conda activate fx` is run |
| `/mnt/e/fx permission denied` | Run `sudo chmod -R 777 /mnt/e/fx` |
| `No PDF library available` | Run `pip install pdfplumber` (needed for SBP M2M PDFs) |
| `M2M PDF not found` | Normal on weekends/holidays — falls back to sidebar (USD only) |
| `yfinance` returns empty | Check internet, sometimes Yahoo throttles — wait 1 min |
| `SBP scraper returns 0 rates` | SBP site may be down; M2M PDFs try 5 previous days automatically |
| Port 8100 in use | `lsof -i :8100` then `kill <PID>`, or use `--port 8101` |
| `sqlite3: database is locked` | Stop the scheduler before running manual commands |
| VS Code can't find conda env | Open command palette → `Python: Select Interpreter` → find `fx` env |
