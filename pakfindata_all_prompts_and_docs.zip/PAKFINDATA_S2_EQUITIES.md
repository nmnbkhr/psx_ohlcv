# pakfindata — Section 2: Equities

## The Stock Analyst's Toolkit

The Equities section covers everything an equity analyst, trader, or portfolio manager needs — from screening and profiling to intraday trading and derivatives. Nine pages that replace a Bloomberg equity terminal.

---

## Page 1: Stock Screener

### What You See

**Filter Bar:** Sector dropdown (All / COMMERCIAL BANKS / CEMENT / FERTILIZER / etc.), Min P/E, Min Market Cap (M), Min Avg Volume, Max P/E — all adjustable with +/- buttons.

**Example — COMMERCIAL BANKS sector selected:**
- MATCHES: 19 stocks
- AVG P/E: N/A (pending deep scrape)
- TOTAL MARKET CAP: N/A
- TOTAL TURNOVER: Rs. 5.66B

**Results Table (19 banks):**

| Symbol | Name | Price | Volume | Turnover | Change |
|--------|------|-------|--------|----------|--------|
| BOP | Bank of Punjab | 27.55 | 54,733,142 | 1.51B | +1.76% |
| NBP | National Bank | 243.81 | 6,160,333 | 1.50B | +1.35% |
| MEBL | Meezan Bank | 447.48 | 1,289,180 | 576.9M | -9.21% |
| HBL | Habib Bank | 263.20 | 1,872,002 | 492.7M | +3.68% |
| UBL | United Bank | 382.07 | 1,164,731 | 445.0M | +17.24% |
| MCB | MCB Bank | 361.33 | 1,126,543 | 407.1M | +11.03% |
| BAFL | Bank Alfalah | 115.20 | 2,828,606 | 325.9M | -1.86% |
| FABL | Faysal Bank | 87.84 | 1,744,418 | 153.2M | +4.78% |
| AKBL | Askari Bank | 83.11 | 1,048,023 | 87.1M | -2.36% |
| SNBL | Soneri Bank | 28.49 | 2,215,053 | 45.4M | -1.65% |

**Export CSV button** at bottom for download.

### Business Value

"Show me all banking stocks sorted by turnover" — answered in 2 seconds. A fund manager evaluating the banking sector sees all 19 banks with live prices, volumes, and daily performance. Combined with P/E and market cap (after deep scrape), this becomes a full fundamental screener.

The Export CSV button feeds directly into Excel models. No manual data entry from PSX website.

### Target Audience

Stock pickers, portfolio managers, fundamental analysts, value investors, compliance teams (monitoring sector exposure).

---

## Page 2: Company Profile (Company Analytics)

### What You See

**Symbol Search Bar:** Type any symbol (e.g., OGDC, HBL, ENGRO) — 564 companies available.

**Company Analytics View (when symbol entered):**
- Company name, sector, listing date
- Quote: last price, change, volume, 52-week high/low
- Trading data across markets: REG (regular), FUT (futures), CONT (continuous), ODL (odd lot)
- Financial ratios: P/E, EPS, dividend yield, book value, market cap
- Announcements: recent corporate announcements from PSX
- Historical price chart with SMA overlay

**Batch Deep Scrape:** Background scraper for all 563 symbols — pulls trading data, profile, financials, ratios, announcements, and payouts from PSX DPS. Last run: 155/563 OK, 408 failed (rate limited).

### Business Value

A credit analyst evaluating a loan application types "ENGRO" and instantly sees financials, market cap, dividend history, and recent announcements — all from official PSX data. No need to visit 5 different PSX pages.

Investment banks preparing IPO comps use batch deep scrape to pull fundamentals for every listed company at once.

### Target Audience

Research analysts, credit officers, investment bankers, corporate finance teams, compliance (KYC/AML checks on listed entities).

---

## Page 3: Sector Analysis

### What You See

**Sector Performance (Treemap):** Visual treemap sized by index weight or volume, showing relative sector sizes and daily performance via color coding (green = up, red = down).

**Sector Breadth Chart:** Stacked bar chart for each of PSX's ~35 sectors showing gainers (green) vs losers (red) count. Key observations from the chart:

- INV. BANKS / SECURITIES COS.: highest count, roughly split between gainers/losers
- COMMERCIAL BANKS: ~30 stocks, more losers than gainers
- TEXTILE SPINNING: large sector, balanced breadth
- CEMENT: predominantly green (gainers)
- PHARMACEUTICALS: mostly green
- OIL & GAS EXPLORATION: mixed
- Smaller sectors (REFINERY, SYNTHETIC & RAYON, WEAVING) show just 1-3 stocks

### Business Value

Sector rotation is the single most important equity strategy in Pakistan. When SBP cuts rates, money flows from banking to cement and consumer. This page shows that rotation in real-time through the breadth chart.

A fund manager overweight in banking sees BKTI breadth turning red while CEMENT turns green — signal to rotate. No other Pakistani platform provides this visualization.

### Target Audience

Sector rotation traders, portfolio constructors, asset allocators, fund managers making tactical allocation decisions.

---

## Page 4: Symbol Financials

### What You See

**Symbol Selector:** Pick any listed company.

**Financial Statement Tabs:**
- Income Statement: revenue, cost of sales, gross profit, operating expenses, net income — quarterly and annual
- Balance Sheet: total assets, equity, liabilities
- Cash Flow: operating, investing, financing cash flows
- Key Ratios: ROE, ROA, debt-to-equity, current ratio, interest coverage

**Charts:** Trend visualization for revenue, profit margins, and EPS over time.

### Business Value

Fundamental analysis without downloading annual reports. A research analyst writing a company initiation note gets 5 years of financial data in seconds. Compare across companies — "Is HBL's ROE improving faster than UBL's?"

### Target Audience

Fundamental analysts, credit analysts, corporate finance teams, equity research departments.

---

## Page 5: Factors

### What You See

**Factor Analysis Dashboard:**
- Momentum factor: 20-day vs 60-day SMA crossover signals
- Value factor: P/E, P/B, dividend yield rankings
- Quality factor: ROE, debt ratios, earnings stability
- Volatility factor: annualized vol, Hurst exponent
- Size factor: market cap rankings

**Factor Returns:** Historical performance of each factor across PSX stocks — which factors work in Pakistan's market?

### Business Value

Quantitative factor investing, adapted for PSX. "Does momentum work in Pakistan?" — the data shows it. "Does low P/E outperform?" — testable here. This is the foundation for smart-beta ETF products in Pakistan.

### Target Audience

Quant analysts, factor-based portfolio managers, ETF designers, academic researchers studying emerging market factors.

---

## Page 6: Intraday Trading Terminal

### What You See

**Eight tabs — a complete intraday trading desk:**

**Dashboard Tab:**
- Market-wide intraday stats: total trades, volume, turnover
- Breadth evolution through the day
- Most active symbols with intraday change

**Charts Tab:**
- Select any symbol → intraday OHLCV candlestick chart
- Resample: 5-second, 1-minute, 5-minute, 15-minute, 1-hour bars
- Volume bars with buy/sell coloring

**Market Pulse Tab:**
- Intraday breadth snapshot at current time
- Advancing vs declining count evolution

**Volume Tab:**
- Intraday volume analysis — which symbols are seeing unusual volume
- Volume-weighted average price (VWAP) calculations

**Movers Tab:**
- Real-time top movers (biggest % change intraday)
- Volume-spike alerts

**Index Tab:**
- KSE-100 intraday overlay from 5-second index bars
- Index vs symbol correlation intraday

**Sync Tab (admin — skipped):** Data sync buttons.

### Business Value

This is the day-trading nerve center. A prop trader monitors 487 symbols through intraday breadth, spots volume spikes on Movers tab, drills into a symbol on Charts tab, checks KSE-100 overlay on Index tab — all without leaving the page.

**Key differentiator:** 5-second bar resolution from cloud tick collection. Most Pakistani platforms show 1-minute or 15-minute bars at best.

### Target Audience

Day traders, proprietary trading desks, market makers, scalpers, algorithmic strategy developers.

---

## Page 7: Live Ticker

### What You See

**Real-time market watch table:**
- All ~539 active symbols updating from PSX DPS API
- Columns: Symbol, Name, Sector, Price, Change, Change%, Volume, Value, High, Low, Open, Prev Close
- Color-coded: green for up, red for down
- Auto-refresh capability

**Filter options:** Search by symbol or sector.

### Business Value

A broker's screen showing all symbols live. Replace the PSX DPS website's market watch with a faster, filterable, sortable version that sits inside the same terminal as all other analytics.

### Target Audience

Active traders, brokers, market monitors, operations teams watching for unusual activity.

---

## Page 8: Futures & Odd Lot

### What You See

**Deliverable Futures Contracts (DFC):**
- Open Interest table: REAL OI data from PSX DFC XLS files (not volume proxy)
- Columns: Symbol-Month (e.g., HUBC-MAR, OGDC-APR), OI in contracts, OI in volume, OI in value, Free Float, % of Free Float
- Basis Analysis: futures price vs spot price for each symbol — premium (bullish) or discount (bearish)
- OI Buildup/Unwind Matrix: which symbols have rising OI + rising price (long buildup) vs rising OI + falling price (short buildup)
- Rollover Tracker: contract month transitions showing when positions roll from current to next month

**Cash Settled Futures (CSF):** Same analysis for cash-settled contracts.

**Odd Lot Market:** Small lot trading activity — volume and value.

### Business Value

This is **unique in Pakistan**. No free platform provides real open interest analytics. The buildup/unwind matrix is what institutional derivative traders use on Bloomberg:

| OI | Price | Signal |
|----|-------|--------|
| ↑ OI + ↑ Price | Long Buildup | Bullish — fresh money entering longs |
| ↑ OI + ↓ Price | Short Buildup | Bearish — fresh shorts |
| ↓ OI + ↓ Price | Long Unwinding | Exiting longs |
| ↓ OI + ↑ Price | Short Covering | Shorts exiting — bullish |

A derivatives trader sees HUBC has OI rising 5% with price up 1.3% — long buildup confirmation. The basis is +1.2% premium — market expects further upside. No other Pakistani platform shows this.

### Target Audience

Derivatives traders, institutional desks, prop trading firms, risk managers monitoring futures exposure.

---

## Page 9: Post Close

### What You See

- Post-close session data (15:30-16:00 on Mon-Thu)
- Final settlement prices
- Closing auction results
- Any trade corrections or adjustments from the post-close window

### Business Value

Complete end-of-day picture. Settlement teams need the final prices (not just last trade). Closing auction prices determine mutual fund NAVs and index calculations.

### Target Audience

Settlement/clearing teams, fund administrators (NAV calculation), index providers, risk managers.

---

## Section Summary: Equities

| Page | Primary Use | Key Data | Differentiator |
|------|------------|----------|----------------|
| Stock Screener | Filter & compare | Price, Volume, Turnover, Sector, P/E | Multi-filter with CSV export |
| Company Profile | Company deep-dive | Financials, ratios, announcements | 564 companies from PSX DPS |
| Sector Analysis | Sector rotation | Breadth by sector, treemap | Per-sector gainer/loser count |
| Symbol Financials | Fundamental analysis | 5-year income/balance/cash flow | Trend charts, ratio comparison |
| Factors | Quant factor research | Momentum, value, quality, vol | Factor returns for PSX — first of its kind |
| Intraday Terminal | Day trading | 5-second bars, 8 analysis tabs | Cloud tick collection, 487 symbols |
| Live Ticker | Real-time monitoring | All 539 symbols live | Filterable, sortable, fast |
| Futures & Odd Lot | Derivatives intelligence | REAL OI, basis, buildup/unwind | Only free OI analytics in Pakistan |
| Post Close | Settlement data | Final prices, closing auction | Complete EOD picture |

**Competitive moat:** The Futures OI analytics and 5-second intraday bars are capabilities no other free Pakistani platform offers. Bloomberg has them at $24,000/year. pakfindata has them at zero marginal cost.

---

*Section 3: Fixed Income — coming next.*
