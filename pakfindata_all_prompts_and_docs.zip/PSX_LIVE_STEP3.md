# Claude Code Prompt: PSX Live Terminal — Step 3/4: Live Market Table + Symbol Detail

## What this is

Step 3 — Build the Live Market table (500+ symbols, virtualized, price flash animations) and the Symbol Detail page (candlestick chart, tick log, order book).

**After this step:** Full market table with real-time updates, click any symbol to see live candlestick chart building from ticks.

**Prerequisite:** Steps 1-2 completed. Dashboard working with live indices and breadth.

## Page 1: Live Market — `src/pages/LiveMarket.tsx`

### Toolbar

```
┌──────────────────────────────────────────────────────────┐
│  [ALL ▾] [REG] [FUT] [ODL] [BNB]    🔍 Search symbol    │
│  489 symbols | 12,340 ticks | Sorted by: Volume ▼       │
└──────────────────────────────────────────────────────────┘
```

- Market filter buttons (ALL/REG/FUT/ODL/BNB) — toggle style, active has blue bg
- Search input — filters symbols containing typed text (debounced 200ms)
- Stats line: symbol count, tick count, current sort

### Virtualized Market Table — `src/components/MarketTable.tsx`

THIS IS THE MOST PERFORMANCE-CRITICAL COMPONENT. 500+ rows updating multiple times per second.

**Virtualization approach:**
- Container has fixed height (calc 100vh - top bar - toolbar)
- Only render rows visible in viewport + 10 buffer rows above/below
- Row height: 36px fixed
- On scroll: recalculate visible range using scrollTop / rowHeight
- Use `position: absolute` + `top: index * 36px` for each visible row
- Total scrollable height = totalRows * 36px (set on inner container)

**Columns:**

| Symbol | Mkt | Price | Change | Chg% | Volume | High | Low | Bid | Ask | Trades |
|--------|-----|-------|--------|------|--------|------|-----|-----|-----|--------|

- Symbol: bold white, left-aligned
- Mkt: muted badge (REG in slate, FUT in blue, etc.)
- Price: right-aligned, **use PriceCell component with flash animation**
- Change: green/red text
- Chg%: green/red text, format as +1.45%
- Volume: right-aligned, formatted (5.7M)
- High/Low: muted text
- Bid/Ask: if available, else "—"
- Trades: formatted integer

**Sort:** Click any column header to sort. Toggle asc/desc. Default: volume desc.
Show ▲/▼ arrow on active sort column.

**Row click:** Navigate to `/symbol/{symbol}` using react-router.

**Row hover:** Background changes to var(--bg-hover).

### PriceCell Component — `src/components/PriceCell.tsx`

```typescript
// This component is React.memo'd — only re-renders when price changes
// Uses CSS class toggling for flash animation, NOT state

interface Props {
  price: number;
  prevPrice?: number;
}

// On render, compare price vs prevPrice:
// - If price > prevPrice → add class "flash-up" 
// - If price < prevPrice → add class "flash-down"
// - Remove class after 300ms via setTimeout
// Use useRef to track previous price and avoid unnecessary re-renders
```

**Critical:** Do NOT store animation state in React state. Use refs + CSS classes + setTimeout. State changes trigger re-renders which defeats the purpose.

### SearchBar — `src/components/SearchBar.tsx`

- Input field with search icon (lucide-react Search icon)
- As user types, filter the market table in real-time
- Debounce at 200ms
- Clear button (X) when text is present
- Placeholder: "Search symbol..."
- Style: dark input, border on focus

### Data flow for LiveMarket

This page reads from `marketStore` which is already populated by `useMarketData` hook
(set up in Layout or Dashboard). If user navigates directly to /market, the hook
in Layout should ensure data is loaded.

Move `useMarketData()` call to Layout.tsx (if not already there) so it runs
regardless of which page is active. This ensures the store is always populated.

---

## Page 2: Symbol Detail — `src/pages/SymbolDetail.tsx`

Route: `/symbol/:symbol`

### Hook: `src/hooks/useSymbol.ts`

```typescript
// Subscribes to ws://localhost:8765/ws/symbol/{SYMBOL}
// Returns: { tick, ticks (last 100), candles (1-min OHLCV), connected }
// 
// On first message (type: "snapshot") → set initial state
// On subsequent messages (type: "tick") → update tick, append to ticks array,
//   update current candle or create new candle
//
// Candle building logic:
//   bucket = Math.floor(timestamp / 60) * 60  (1-minute buckets)
//   If bucket == currentCandle.time → update H/L/C/V
//   If bucket > currentCandle.time → close current, start new candle
//
// Cleanup: disconnect WS on unmount
```

### Layout

```
┌──────────────────────────────────────────────────────────┐
│  ← Back   HUBC — Hub Power Company                       │
│  234.98   ▼ -2.02 (-0.85%)                              │
│  Open: 237.00  High: 240.00  Low: 234.50  Vol: 5.7M     │
├──────────────────────────────────────────────────────────┤
│                                                          │
│              Candlestick Chart (60% height)              │
│              (TradingView Lightweight Charts)             │
│                                                          │
├─────────────────────────────┬────────────────────────────┤
│       Order Book            │         Tick Log           │
│                             │                            │
│  Bid         Ask            │  12:34:56  234.98  +0.12  │
│  235.00 ████  235.10 ████  │  12:34:51  234.86  -0.05  │
│  234.90 ██    235.20 ██    │  12:34:48  234.91  +0.03  │
│  234.80 █     235.50 █     │  12:34:45  234.88  -0.10  │
│                             │  ... last 50 ticks         │
└─────────────────────────────┴────────────────────────────┘
```

### Header section

- Back button (← icon) → navigate(-1)
- Symbol large + company name (if available from tick data, else just symbol)
- Current price: large, white, text-3xl
- Change + change%: green/red, text-xl
- Stats row: Open, High, Low, Volume, Trades — in muted text

### Candlestick Chart — `src/components/CandlestickChart.tsx`

Wrapper around TradingView Lightweight Charts:

```typescript
// Props:
//   candles: Array<{ time: number, open: number, high: number, low: number, close: number }>
//   volumeData: Array<{ time: number, value: number, color: string }>

// On mount:
//   createChart() with dark theme options:
//     layout: { background: { color: '#0f172a' }, textColor: '#94a3b8' }
//     grid: { vertLines: { color: '#1e293b' }, horzLines: { color: '#1e293b' } }
//     crosshair: { mode: CrosshairMode.Normal }
//     timeScale: { timeVisible: true, secondsVisible: false }
//
//   addCandlestickSeries():
//     upColor: '#22c55e', downColor: '#ef4444'
//     borderUpColor: '#22c55e', borderDownColor: '#ef4444'
//     wickUpColor: '#22c55e', wickDownColor: '#ef4444'
//
//   addHistogramSeries() for volume:
//     priceScaleId: 'volume' (separate scale)
//     scaleMargins: { top: 0.8, bottom: 0 }
//
// On candle update:
//   candleSeries.update(lastCandle)  — updates in place if same time
//
// On unmount:
//   chart.remove()
//
// Use useRef for chart instance. useEffect for setup/teardown.
```

Chart height: ~60% of available page height. Responsive.

### Order Book (simple) — if bid/ask available

Two columns: Bid (left, green) and Ask (right, red).
Show bid/ask price + horizontal bar proportional to volume.
If bid/ask data not available in tick, show "No depth data available" message.

This is a simple visualization — NOT a full L2 order book (we only have top of book).

### Tick Log

Scrolling list of last 50 raw ticks:
- Columns: Time (HH:MM:SS), Price, Change from prev tick
- New ticks prepend at top
- Green row bg if price up from prev, red if down
- Auto-scroll to top on new tick (but stop auto-scroll if user manually scrolled up)
- Fixed height container with overflow-y: auto
- Monospace font for alignment

---

## VERIFY

```bash
cd ~/projects/psx-live
npm run dev

# With tick_service running:

# 1. Go to localhost:3000/market
#    - See 500+ symbols in table
#    - Prices flashing green/red on updates
#    - Sort by clicking column headers
#    - Filter by market (REG/FUT/etc)
#    - Search for "HUB" → shows HUBC, HUBCO, etc.

# 2. Click any symbol row → navigates to /symbol/HUBC
#    - See price updating live
#    - Candlestick chart building candles in real-time
#    - Tick log scrolling with new ticks
#    - Click ← Back → returns to market table

# 3. Scroll fast in market table → no lag (virtualization working)

npx tsc --noEmit  # no errors
```

## Files created/modified in this step

| Action | File | Purpose |
|--------|------|---------|
| CREATE | `src/hooks/useSymbol.ts` | Hook — subscribe to single symbol WS |
| CREATE | `src/components/MarketTable.tsx` | Virtualized 500+ row table |
| CREATE | `src/components/PriceCell.tsx` | Price with flash animation |
| CREATE | `src/components/SearchBar.tsx` | Symbol search with debounce |
| CREATE | `src/components/CandlestickChart.tsx` | TradingView chart wrapper |
| MODIFY | `src/pages/LiveMarket.tsx` | Full market table page |
| MODIFY | `src/pages/SymbolDetail.tsx` | Full symbol detail page |
| MODIFY | `src/components/Layout.tsx` | Move useMarketData to Layout so store is always populated |
