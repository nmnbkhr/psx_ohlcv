# Claude Code Prompt: PSX Live Terminal — Step 2/4: Dashboard + Indices

## What this is

Step 2 — Build the Dashboard page with live KSE-100 hero card, all 12 indices, market breadth bar, and top movers. Also create the Zustand stores and WebSocket hooks that ALL pages will use.

**After this step:** Dashboard shows live KSE-100 value updating in real-time, all 12 indices with sparklines, gainers/losers/active columns, and breadth bar.

**Prerequisite:** Step 1 completed. Project at ~/projects/psx-live with dark theme, layout, routing, and WebSocket manager working.

## Create Zustand stores

### `src/stores/marketStore.ts`

Zustand store for all stock symbol data:

```typescript
State:
  symbols: Map<string, Tick>        // "HUBC" → latest tick
  breadth: MarketBreadth            // {gainers, losers, unchanged}
  topGainers: Tick[]                // top 10 by changePercent
  topLosers: Tick[]                 // bottom 10 by changePercent
  mostActive: Tick[]                // top 10 by volume
  tickCount: number
  lastUpdate: number

Actions:
  updateTick(tick: Tick)            // update single symbol, recalc movers every 50 ticks
  loadSnapshot(symbols: Tick[])     // bulk load from REST /snapshot on app init
```

Performance: Don't recalculate breadth/movers on every single tick. Do it every 50 ticks or every 2 seconds — whichever comes first. Sorting 500 items on every tick kills performance.

### `src/stores/indexStore.ts`

Zustand store for all index data:

```typescript
State:
  indices: Map<string, IndexTick>    // "KSE100" → latest
  sparklines: Map<string, number[]>  // "KSE100" → [185100, 185400, ...] last 60 points
  lastUpdate: number

Actions:
  updateIndex(tick: IndexTick)       // update single index + append to sparkline
  loadIndices(indices: IndexTick[])  // bulk load from REST
```

## Create WebSocket hooks

### `src/hooks/useMarketData.ts`

Hook that:
1. On mount: fetch `GET /snapshot` → call `marketStore.loadSnapshot()` + `indexStore.loadIndices()`
2. Connect to `/ws/ticks` → on each message → call `marketStore.updateTick()`
3. On unmount: disconnect WS
4. Return: { connected, tickCount }

### `src/hooks/useIndices.ts`

Hook that:
1. Connect to `/ws/indices` → on each message → call `indexStore.updateIndex()`
2. On unmount: disconnect WS
3. Return: { connected }

## Build Dashboard page — `src/pages/Dashboard.tsx`

Replace the placeholder. Uses both hooks above.

### Section 1: KSE-100 Hero — `src/components/IndexHero.tsx`

Large hero card for KSE-100:

```
┌────────────────────────────────────────────────────────────┐
│  KSE-100 INDEX                          Open:  185,077.37  │
│  187,761.69                             High:  188,200.50  │
│  ▲ +2,684.32 (+1.45%)                  Low:   185,100.20  │
│                                                            │
│  [═══════════════ sparkline chart ═══════════════════════] │
└────────────────────────────────────────────────────────────┘
```

- Background: `linear-gradient(135deg, #0f172a, #1e293b)`
- Left border: 4px green if up, red if down
- Value: white, text-4xl, font-bold
- Change: green/red, text-xl
- Open/High/Low: muted text on right side
- Sparkline: use Lightweight Charts line series (height ~120px)
  - Feed from indexStore sparklines for "KSE100"
  - Green line if current > open, red if below
- Updates in real-time as index ticks arrive

### Section 2: Secondary Index Cards — `src/components/IndexCard.tsx`

Row of 4 cards: KSE-30, KMI-30, All Share, KMI All Shares

Each card:
- Index name (muted, small)
- Value (white, text-xl, bold)
- Change% (green/red)
- Tiny sparkline (height ~40px, just dots or simple line)
- Left border color: green/red based on change
- Background: var(--bg-secondary)

Use CSS grid: `grid grid-cols-2 lg:grid-cols-4 gap-4`

### Section 3: Breadth Bar — `src/components/BreadthBar.tsx`

```
  🟢 293 Gainers              ⚪ 51          🔴 145 Losers
  [██████████████████████████|████|███████████████████]
```

- Three metrics above the bar
- Horizontal stacked bar below
- Green section width = gainers/total * 100%
- Gray section width = unchanged/total * 100%
- Red section width = losers/total * 100%
- Rounded corners, height ~24px
- CSS transition on widths for smooth animation

### Section 4: Top Movers — `src/components/TopMovers.tsx`

Three columns side by side:

```
  🚀 Top Gainers          📉 Top Losers          📊 Most Active
  GUSM   +10.03%          FNEL   -10.01%          HUBC   5.7M
  LOTCHEM +8.21%           AGSML  -7.44%           OGDC   4.2M
  ...5 each                ...5 each                ...5 each
```

- Show top 5 from marketStore topGainers/topLosers/mostActive
- Symbol in white, metric in green/red/blue
- Rows should subtly flash when data changes

### Section 5: All Indices Table

Below the movers, show ALL 12 indices in a table grouped by category:

**Equity Indices:** KSE100, KSE30, KSE100PR, ALLSHR
**Islamic Indices:** KMI30, KMIALLSHR, MII30, MZNPI
**Sectoral Indices:** BKTI, JSGBKTI, JSMFI, ACI

Columns: Name | Symbol | Value | Change | Chg% | High | Low
Green/red text on Change and Chg% columns.

Use index name mapping:
```typescript
const INDEX_NAMES: Record<string, string> = {
  KSE100: "KSE-100",
  KSE30: "KSE-30",
  KSE100PR: "KSE-100 Price Return",
  ALLSHR: "All Share",
  KMI30: "KMI-30",
  KMIALLSHR: "KMI All Shares",
  MII30: "Mahaana Islamic 30",
  MZNPI: "Meezan Pakistan",
  BKTI: "Banks Tradable",
  JSGBKTI: "JS Global Banks",
  JSMFI: "JS Momentum Factor",
  ACI: "Alfalah Consumer",
};
```

## VERIFY

```bash
cd ~/projects/psx-live
npm run dev

# Start tick_service in another terminal if not running:
# python -m psx_ohlcv.services.tick_service

# Browser at localhost:3000 should show:
# - KSE-100 hero card with live value (updates on each index tick)
# - 4 secondary index cards
# - Breadth bar (updates as stock ticks arrive)
# - Top 5 gainers/losers/active
# - All 12 indices table
# - Connection badge showing 🟢 LIVE

npx tsc --noEmit  # no errors
```

## Files created/modified in this step

| Action | File | Purpose |
|--------|------|---------|
| CREATE | `src/stores/marketStore.ts` | Zustand — symbols, breadth, movers |
| CREATE | `src/stores/indexStore.ts` | Zustand — indices, sparklines |
| CREATE | `src/hooks/useMarketData.ts` | Hook — connect /ws/ticks + load snapshot |
| CREATE | `src/hooks/useIndices.ts` | Hook — connect /ws/indices |
| CREATE | `src/components/IndexHero.tsx` | KSE-100 large hero card |
| CREATE | `src/components/IndexCard.tsx` | Secondary index card |
| CREATE | `src/components/BreadthBar.tsx` | Gainers/losers bar |
| CREATE | `src/components/TopMovers.tsx` | Gainers/losers/active columns |
| CREATE | `src/components/SparklineChart.tsx` | Small inline sparkline |
| MODIFY | `src/pages/Dashboard.tsx` | Full dashboard with all sections |
