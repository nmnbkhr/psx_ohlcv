# Claude Code Prompt: Local PSX Infrastructure Audit — READ ONLY

## Objective

Investigate everything running locally related to PSX data collection, storage, 
and services. **DO NOT modify, delete, or fix anything.** Report only.

## Rules

- **READ ONLY** — no file modifications, no DB writes, no table drops
- **NO table scans** — do NOT run `SELECT COUNT(*)` on large tables (they hang)
- Use `PRAGMA` commands and file sizes for DB analysis
- Use `ps`, `grep`, `ls`, `du` for system investigation
- Output a clean audit report at the end

## Step 1: Running Processes

```bash
echo "═══ RUNNING PROCESSES ═══"

# Anything PSX/pakfindata related
ps aux | grep -iE "tick_service|ws_relay|market_watch|streamlit|pakfindata|psx" | grep -v grep

# Any Python processes
ps aux | grep python | grep -v grep

# Any node/React processes
ps aux | grep -iE "node|vite|react" | grep -v grep

# Anything using port 8765 (WS relay)
ss -tlnp | grep 8765 2>/dev/null || netstat -tlnp 2>/dev/null | grep 8765

# Anything using port 8501 (Streamlit)
ss -tlnp | grep 8501 2>/dev/null || netstat -tlnp 2>/dev/null | grep 8501

# Crontabs
echo ""
echo "═══ CRONTABS ═══"
crontab -l 2>/dev/null || echo "No crontab"
```

## Step 2: Startup/Stop Scripts

```bash
echo "═══ STARTUP SCRIPTS ═══"

# Find all shell scripts related to PSX
find ~/pakfindata/ -name "*.sh" -type f 2>/dev/null | while read f; do
    echo ""
    echo "--- $f ---"
    cat "$f"
done

# Check if any systemd user services exist
ls ~/.config/systemd/user/psx* 2>/dev/null && cat ~/.config/systemd/user/psx* || echo "No user systemd services"
systemctl --user list-timers 2>/dev/null | grep psx || echo "No user timers"
```

## Step 3: Database Files — Sizes Only (NO scans)

```bash
echo "═══ DATABASE FILES ═══"

# Find all SQLite files
find /mnt/e/psxdata/ -name "*.db" -o -name "*.sqlite" 2>/dev/null | while read db; do
    size=$(du -h "$db" | awk '{print $1}')
    echo ""
    echo "--- $db ($size) ---"
    
    # Tables (instant)
    sqlite3 "$db" ".tables" 2>/dev/null
    
    # Schema (instant)
    sqlite3 "$db" ".schema" 2>/dev/null | grep "CREATE TABLE"
    
    # Page info (instant, no scan)
    echo "  Page count: $(sqlite3 "$db" "PRAGMA page_count;" 2>/dev/null)"
    echo "  Page size:  $(sqlite3 "$db" "PRAGMA page_size;" 2>/dev/null)"
    echo "  Journal:    $(sqlite3 "$db" "PRAGMA journal_mode;" 2>/dev/null)"
    
    # WAL file size
    wal="${db}-wal"
    if [ -f "$wal" ]; then
        echo "  WAL file:   $(du -h "$wal" | awk '{print $1}')"
    fi
    
    # SHM file
    shm="${db}-shm"
    if [ -f "$shm" ]; then
        echo "  SHM file:   $(du -h "$shm" | awk '{print $1}')"
    fi
done
```

## Step 4: Data Files on Disk

```bash
echo "═══ DISK USAGE ═══"

# Top-level psxdata breakdown
echo "--- /mnt/e/psxdata/ ---"
du -sh /mnt/e/psxdata/*/ 2>/dev/null
du -sh /mnt/e/psxdata/*.db 2>/dev/null
du -sh /mnt/e/psxdata/*.sqlite 2>/dev/null
du -sh /mnt/e/psxdata/*.json 2>/dev/null

echo ""
echo "--- Tick logs (local) ---"
ls -lh /mnt/e/psxdata/tick_logs/ 2>/dev/null | tail -10
du -sh /mnt/e/psxdata/tick_logs/ 2>/dev/null

echo ""
echo "--- Tick logs (cloud) ---"
ls -lh /mnt/e/psxdata/tick_logs_cloud/ 2>/dev/null | tail -10
du -sh /mnt/e/psxdata/tick_logs_cloud/ 2>/dev/null

echo ""
echo "--- Intraday ---"
ls -lh /mnt/e/psxdata/intraday/ 2>/dev/null | tail -10
du -sh /mnt/e/psxdata/intraday/ 2>/dev/null

echo ""
echo "--- Downloads ---"
du -sh /mnt/e/psxdata/downloads/*/ 2>/dev/null
du -sh /mnt/e/psxdata/downloads/ 2>/dev/null

echo ""
echo "--- MUFAP ---"
du -sh /mnt/e/psxdata/mufapnav/ 2>/dev/null

echo ""
echo "--- Total ---"
du -sh /mnt/e/psxdata/ 2>/dev/null

echo ""
echo "--- Drive E free space ---"
df -h /mnt/e/
```

## Step 5: Project Code Structure

```bash
echo "═══ PROJECT STRUCTURE ═══"

# Source modules
echo "--- Sources (data scrapers) ---"
ls ~/pakfindata/src/pakfindata/sources/ 2>/dev/null

echo ""
echo "--- Services (tick collector, relay, poller) ---"
ls ~/pakfindata/src/pakfindata/services/ 2>/dev/null

echo ""
echo "--- Engine (analytics) ---"
ls ~/pakfindata/src/pakfindata/engine/ 2>/dev/null

echo ""
echo "--- UI Pages ---"
ls ~/pakfindata/src/pakfindata/ui/page_views/ 2>/dev/null

echo ""
echo "--- Config paths ---"
grep -n "DATA_ROOT\|DB_PATH\|SNAPSHOT\|TICK_LOG\|/mnt/e" ~/pakfindata/src/pakfindata/config.py 2>/dev/null
```

## Step 6: What Writes to Each DB

```bash
echo "═══ DB WRITE SOURCES ═══"

echo "--- What writes to tick_bars.db ---"
grep -rn "tick_bars" ~/pakfindata/src/ --include="*.py" 2>/dev/null | grep -v __pycache__ | grep -v ".pyc"

echo ""
echo "--- What writes to psx.sqlite ---"
grep -rn "psx.sqlite\|psx_db\|DB_PATH" ~/pakfindata/src/ --include="*.py" 2>/dev/null | grep -v __pycache__ | grep -v ".pyc" | head -30

echo ""
echo "--- What reads tick_logs ---"
grep -rn "tick_logs\|tick_log\|\.jsonl" ~/pakfindata/src/ --include="*.py" 2>/dev/null | grep -v __pycache__ | head -20

echo ""
echo "--- What reads/writes live_snapshot.json ---"
grep -rn "live_snapshot\|snapshot" ~/pakfindata/src/ --include="*.py" 2>/dev/null | grep -v __pycache__ | head -20
```

## Step 7: Cloud vs Local Overlap

```bash
echo "═══ CLOUD vs LOCAL ═══"

echo "--- Cloud collector (Oracle VM) ---"
echo "  IP: 80.225.73.99"
echo "  SSH: ssh psx-cloud"
echo "  Service: psx-tick-collector (systemd timer, Mon-Fri 9:10 AM PKT)"
echo "  Output: ~/psxdata/tick_logs/*.jsonl (cloud)"
echo "  Downloaded to: /mnt/e/psxdata/tick_logs_cloud/"

echo ""
echo "--- Local collector ---"
echo "  Script: ~/pakfindata/start_psx.sh"
echo "  Service: tick_service.py (manual, nohup)"
echo "  Output: tick_bars.db (raw_ticks + ohlcv_5s) + tick_logs/*.jsonl (local)"
echo "  Status: NOT running currently"

echo ""
echo "--- Overlap ---"
echo "  Both collect the same WebSocket data from psxterminal.com"
echo "  Cloud: cleaner (deduplicated, 652K ticks/day)"
echo "  Local: has duplicates (46%, 1.15M rows/day)"
echo "  Cloud JSONL is primary source going forward"

echo ""
echo "--- Files that may be redundant ---"
echo "  /mnt/e/psxdata/tick_logs/ (local) — duplicated by cloud"
if [ -d "/mnt/e/psxdata/tick_logs" ] && [ -d "/mnt/e/psxdata/tick_logs_cloud" ]; then
    local_count=$(ls /mnt/e/psxdata/tick_logs/*.jsonl 2>/dev/null | wc -l)
    cloud_count=$(ls /mnt/e/psxdata/tick_logs_cloud/*.jsonl 2>/dev/null | wc -l)
    echo "  Local JSONL files: $local_count"
    echo "  Cloud JSONL files: $cloud_count"
    
    # Overlapping dates
    comm -12 \
        <(ls /mnt/e/psxdata/tick_logs/*.jsonl 2>/dev/null | xargs -I{} basename {} | sort) \
        <(ls /mnt/e/psxdata/tick_logs_cloud/*.jsonl 2>/dev/null | xargs -I{} basename {} | sort) \
    2>/dev/null | head -10
    echo "  (files existing in both locations)"
fi
```

## Step 8: Generate Audit Report

After running all steps above, compile into a summary:

```
═══════════════════════════════════════════════════════════
  PSX LOCAL INFRASTRUCTURE AUDIT — {date}
═══════════════════════════════════════════════════════════

RUNNING PROCESSES:
  [list what's running]

DATABASES:
  tick_bars.db:  {size}  | Tables: {list} | WAL: {size}
  psx.sqlite:    {size}  | Tables: {list} | WAL: {size}

DISK USAGE:
  Total psxdata:    {size}
  tick_bars.db:     {size}
  psx.sqlite:       {size}
  tick_logs local:  {size} ({count} files)
  tick_logs cloud:  {size} ({count} files)
  intraday:         {size}
  downloads:        {size}
  mufapnav:         {size}
  Drive E free:     {free}

DB WRITERS:
  tick_bars.db ← tick_service.py (EOD flush: raw_ticks, ohlcv_5s, index_ticks)
  psx.sqlite   ← [list all writers]

REDUNDANCIES:
  [list what's duplicated between local and cloud]
  [list what can be safely removed]

RECOMMENDATIONS (do NOT implement):
  1. [suggestion]
  2. [suggestion]
  3. ...
═══════════════════════════════════════════════════════════
```

## IMPORTANT

- **This is an AUDIT — do NOT take any action**
- No DROP TABLE, no DELETE, no file removal
- No modifications to tick_service.py or any code
- If a command hangs (DB locked), skip it and note "LOCKED" in report
- If a query takes >5 seconds, CTRL+C and note "TOO SLOW" in report
