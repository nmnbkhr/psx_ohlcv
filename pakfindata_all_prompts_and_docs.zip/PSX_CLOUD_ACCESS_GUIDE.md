# PSX Cloud Collector — Quick Access Guide

## Server Details

```
IP:       80.225.73.99
User:     ubuntu
Key:      /home/adnoman/.ssh/oracle-psx.key (WSL2)
          E:\ovcn\ssh-key-2026-03-18.key (Windows)
Region:   Saudi Arabia (Jeddah)
```

---

## 1. WSL2 (Linux Terminal)

### First-time setup (already done)

```bash
cat >> ~/.ssh/config << 'EOF'
Host psx-cloud
    HostName 80.225.73.99
    User ubuntu
    IdentityFile /home/adnoman/.ssh/oracle-psx.key
    StrictHostKeyChecking no
EOF
chmod 600 ~/.ssh/config
```

### Daily commands

```bash
# SSH into server
ssh psx-cloud

# Quick status check
ssh psx-cloud "tail -10 ~/psxdata/logs/tick_collector.log"

# Full status
ssh psx-cloud "bash ~/pakfindata/services/status.sh"

# Check service
ssh psx-cloud "sudo systemctl status psx-tick-collector"

# Check timer
ssh psx-cloud "sudo systemctl list-timers | grep psx"

# Download today's data
rsync -avz psx-cloud:~/psxdata/ ~/psxdata/cloud/

# Download only tick_bars.db
rsync -avz psx-cloud:~/psxdata/tick_bars.db /mnt/e/psxdata/

# Download today's JSONL logs
rsync -avz psx-cloud:~/psxdata/tick_logs/ /mnt/e/psxdata/tick_logs_cloud/

# Restart service
ssh psx-cloud "sudo systemctl restart psx-tick-collector"

# Stop service
ssh psx-cloud "sudo systemctl stop psx-tick-collector"

# View live log (Ctrl+C to exit)
ssh psx-cloud "tail -f ~/psxdata/logs/tick_collector.log"
```

---

## 2. Android (Mobile)

### Option A: Termux (Free, recommended)

1. Install **Termux** from F-Droid (NOT Play Store — Play Store version is outdated)
   - https://f-droid.org/packages/com.termux/

2. First-time setup in Termux:

```bash
pkg update && pkg install openssh

# Create key directory
mkdir -p ~/.ssh

# Type the private key manually OR transfer via:
# Option 1: Copy key file to phone → Internal Storage → then:
cp /storage/emulated/0/Download/ssh-key-2026-03-18.key ~/.ssh/oracle-psx.key
chmod 400 ~/.ssh/oracle-psx.key

# Option 2: Generate new key on phone and add to server
ssh-keygen -t ed25519 -f ~/.ssh/oracle-psx.key -N ""
# Then SSH from laptop and add the public key:
# ssh psx-cloud "cat >> ~/.ssh/authorized_keys" < ~/.ssh/oracle-psx.key.pub

# Setup config
cat >> ~/.ssh/config << 'EOF'
Host psx-cloud
    HostName 80.225.73.99
    User ubuntu
    IdentityFile ~/.ssh/oracle-psx.key
    StrictHostKeyChecking no
EOF
chmod 600 ~/.ssh/config
```

3. Daily use in Termux:

```bash
# Check status
ssh psx-cloud "tail -5 ~/psxdata/logs/tick_collector.log"

# Full SSH
ssh psx-cloud
```

### Option B: JuiceSSH (Free, GUI app)

1. Install **JuiceSSH** from Play Store
2. Open → Connections → New
   - Nickname: PSX Cloud
   - Type: SSH
   - Address: 80.225.73.99
   - Port: 22
3. Identity → New
   - Nickname: Ubuntu
   - Username: ubuntu
   - Private Key: Import from `E:\ovcn\ssh-key-2026-03-18.key`
     (transfer to phone first via email/drive/USB)
4. Save → Connect

### Option C: Termius (Free tier available)

1. Install **Termius** from Play Store
2. Add Host:
   - Label: PSX Cloud
   - Hostname: 80.225.73.99
   - Username: ubuntu
   - Key: Import private key file
3. Connect and run commands

---

## 3. Windows (PowerShell / CMD)

### First-time setup

```powershell
# Create SSH config (PowerShell)
mkdir $HOME\.ssh -Force

# Copy key
Copy-Item "E:\ovcn\ssh-key-2026-03-18.key" "$HOME\.ssh\oracle-psx.key"

# Create config file
@"
Host psx-cloud
    HostName 80.225.73.99
    User ubuntu
    IdentityFile C:\Users\$env:USERNAME\.ssh\oracle-psx.key
    StrictHostKeyChecking no
"@ | Out-File -FilePath "$HOME\.ssh\config" -Encoding ASCII
```

### Fix key permissions (PowerShell as Admin)

```powershell
$keyPath = "$HOME\.ssh\oracle-psx.key"
icacls $keyPath /inheritance:r /grant "${env:USERNAME}:(R)"
```

### Daily commands (PowerShell or CMD)

```powershell
# SSH in
ssh psx-cloud

# Quick check
ssh psx-cloud "tail -5 ~/psxdata/logs/tick_collector.log"

# Check service
ssh psx-cloud "sudo systemctl status psx-tick-collector"

# View live log
ssh psx-cloud "tail -f ~/psxdata/logs/tick_collector.log"
```

### Download data (PowerShell)

```powershell
# Install rsync alternative — use scp instead
scp -i $HOME\.ssh\oracle-psx.key ubuntu@80.225.73.99:~/psxdata/tick_bars.db E:\psxdata\
scp -r -i $HOME\.ssh\oracle-psx.key ubuntu@80.225.73.99:~/psxdata/tick_logs/ E:\psxdata\tick_logs_cloud\
```

---

## Common Tasks

### Check if market data is flowing (run from any device)

```bash
ssh psx-cloud "tail -3 ~/psxdata/logs/tick_collector.log"
```

**Good output (during market hours 9:15-15:30 PKT):**
```
⚡ Ticks: 45,231 | Bars: 8,234 | Symbols: 487 | Indices: 6 | RAM: 45 MB
```

**Normal output (outside market hours):**
```
⚠️ Disconnected: no close frame received or sent. Reconnecting in 1s...
🔗 Connected to wss://psxterminal.com/
✅ Subscribed: REG FUT ODL BNB IDX
```

### Check disk usage

```bash
ssh psx-cloud "df -h / && du -sh ~/psxdata/"
```

### Reboot server (after kernel update)

```bash
ssh psx-cloud "sudo reboot"
# Wait 60 seconds then reconnect
ssh psx-cloud
```

### Check if timer will fire tomorrow

```bash
ssh psx-cloud "sudo systemctl list-timers psx-*"
```

### Emergency: manually start collector

```bash
ssh psx-cloud "sudo systemctl start psx-tick-collector && sudo systemctl status psx-tick-collector"
```

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `Permission denied (publickey)` | Key path wrong — use `/home/adnoman/.ssh/oracle-psx.key` |
| `Connection refused` | VM might be rebooting — wait 2 min, try again |
| `Connection timed out` | Check Oracle Console — VM might be stopped |
| Ticks: 0 during market hours | `ssh psx-cloud "sudo systemctl restart psx-tick-collector"` |
| Log file empty | `ssh psx-cloud "cat ~/psxdata/logs/tick_collector_error.log"` |
| Disk full | `ssh psx-cloud "find ~/psxdata/logs -mtime +30 -delete"` |
