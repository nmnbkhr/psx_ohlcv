# Claude Code Prompt: Add pakfindata Logo to Both Apps

## Context

We have 5 SVG logo files to integrate into two apps:
- **pakfindata** (Streamlit) — `~/pakfindata/`
- **psx-live** (React) — `~/projects/psx-live/`

The SVG files are at: (copy them from wherever they were downloaded to)

## Step 1: Create assets directories and copy logos

```bash
# Streamlit app
mkdir -p ~/pakfindata/src/pakfindata/ui/assets

# React app
mkdir -p ~/projects/psx-live/public
```

Copy these 5 SVG files into both locations:
- `pakfindata-icon.svg` (100x100 app icon)
- `pakfindata-logo-full.svg` (380x100 full wordmark)
- `pakfindata-nav-logo.svg` (240x44 compact nav)
- `pakfindata-banner.svg` (600x120 wide banner)
- `pakfindata-favicon.svg` (32x32 favicon)

```bash
# Copy to Streamlit assets
cp pakfindata-*.svg ~/pakfindata/src/pakfindata/ui/assets/

# Copy to React public folder
cp pakfindata-*.svg ~/projects/psx-live/public/
```

If the SVG files aren't on disk yet, create them. Here are the exact SVG contents:

### pakfindata-icon.svg (100x100)
```svg
<svg width="100" height="100" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
  <rect x="0" y="0" width="100" height="100" rx="20" fill="#0a0e17"/>
  <g transform="translate(12, 12)">
    <circle cx="10" cy="10" r="5" fill="#1D9E75"/>
    <circle cx="26" cy="10" r="5" fill="#378ADD"/>
    <circle cx="42" cy="10" r="5" fill="#378ADD"/>
    <circle cx="58" cy="10" r="5" fill="#22c55e"/>
    <circle cx="74" cy="10" r="5" fill="#1e293b"/>
    <circle cx="10" cy="26" r="5" fill="#1D9E75"/>
    <circle cx="26" cy="26" r="5" fill="#1e293b"/>
    <circle cx="42" cy="26" r="5" fill="#1e293b"/>
    <circle cx="58" cy="26" r="5" fill="#378ADD"/>
    <circle cx="74" cy="26" r="5" fill="#1e293b"/>
    <circle cx="10" cy="42" r="5" fill="#1D9E75"/>
    <circle cx="26" cy="42" r="5" fill="#378ADD"/>
    <circle cx="42" cy="42" r="5" fill="#378ADD"/>
    <circle cx="58" cy="42" r="5" fill="#22c55e" opacity="0.5"/>
    <circle cx="74" cy="42" r="5" fill="#1e293b"/>
    <circle cx="10" cy="58" r="5" fill="#1D9E75"/>
    <circle cx="26" cy="58" r="5" fill="#1e293b"/>
    <circle cx="42" cy="58" r="5" fill="#1e293b"/>
    <circle cx="58" cy="58" r="5" fill="#1e293b"/>
    <circle cx="74" cy="58" r="5" fill="#1e293b"/>
    <circle cx="10" cy="74" r="5" fill="#1D9E75"/>
    <circle cx="26" cy="74" r="5" fill="#1e293b"/>
    <circle cx="42" cy="74" r="5" fill="#1e293b"/>
    <circle cx="58" cy="74" r="5" fill="#1e293b"/>
    <circle cx="74" cy="74" r="5" fill="#1e293b"/>
  </g>
</svg>
```

### pakfindata-favicon.svg (32x32)
```svg
<svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
  <rect x="0" y="0" width="32" height="32" rx="7" fill="#0a0e17"/>
  <g transform="translate(4, 4)">
    <circle cx="3" cy="3" r="2.2" fill="#1D9E75"/>
    <circle cx="9" cy="3" r="2.2" fill="#378ADD"/>
    <circle cx="15" cy="3" r="2.2" fill="#378ADD"/>
    <circle cx="21" cy="3" r="2.2" fill="#22c55e"/>
    <circle cx="3" cy="9" r="2.2" fill="#1D9E75"/>
    <circle cx="9" cy="9" r="2.2" fill="#1e293b"/>
    <circle cx="15" cy="9" r="2.2" fill="#1e293b"/>
    <circle cx="21" cy="9" r="2.2" fill="#378ADD"/>
    <circle cx="3" cy="15" r="2.2" fill="#1D9E75"/>
    <circle cx="9" cy="15" r="2.2" fill="#378ADD"/>
    <circle cx="15" cy="15" r="2.2" fill="#378ADD"/>
    <circle cx="21" cy="15" r="2.2" fill="#22c55e" opacity="0.5"/>
    <circle cx="3" cy="21" r="2.2" fill="#1D9E75"/>
    <circle cx="9" cy="21" r="2.2" fill="#1e293b"/>
    <circle cx="15" cy="21" r="2.2" fill="#1e293b"/>
    <circle cx="21" cy="21" r="2.2" fill="#1e293b"/>
  </g>
</svg>
```

### pakfindata-nav-logo.svg (240x44)
```svg
<svg width="240" height="44" viewBox="0 0 240 44" xmlns="http://www.w3.org/2000/svg">
  <rect x="0" y="0" width="44" height="44" rx="10" fill="#0a0e17"/>
  <g transform="translate(5, 5)">
    <circle cx="5" cy="5" r="3" fill="#1D9E75"/>
    <circle cx="14" cy="5" r="3" fill="#378ADD"/>
    <circle cx="23" cy="5" r="3" fill="#378ADD"/>
    <circle cx="32" cy="5" r="3" fill="#22c55e"/>
    <circle cx="5" cy="14" r="3" fill="#1D9E75"/>
    <circle cx="14" cy="14" r="3" fill="#1e293b"/>
    <circle cx="23" cy="14" r="3" fill="#1e293b"/>
    <circle cx="32" cy="14" r="3" fill="#378ADD"/>
    <circle cx="5" cy="23" r="3" fill="#1D9E75"/>
    <circle cx="14" cy="23" r="3" fill="#378ADD"/>
    <circle cx="23" cy="23" r="3" fill="#378ADD"/>
    <circle cx="32" cy="23" r="3" fill="#22c55e" opacity="0.5"/>
    <circle cx="5" cy="32" r="3" fill="#1D9E75"/>
    <circle cx="14" cy="32" r="3" fill="#1e293b"/>
    <circle cx="23" cy="32" r="3" fill="#1e293b"/>
    <circle cx="32" cy="32" r="3" fill="#1e293b"/>
  </g>
  <text x="54" y="22" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif" font-size="18" font-weight="500" fill="#f1f5f9" letter-spacing="-0.5">pak</text>
  <text x="99" y="22" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif" font-size="18" font-weight="500" fill="#378ADD" letter-spacing="-0.5">fin</text>
  <text x="130" y="22" font-family="-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif" font-size="18" font-weight="500" fill="#f1f5f9" letter-spacing="-0.5">data</text>
  <text x="54" y="37" font-family="'SF Mono', 'Consolas', monospace" font-size="7" fill="#64748b" letter-spacing="2">QUANTITATIVE FINANCE</text>
</svg>
```

(The banner and full logo SVGs are the same as downloaded — just copy them.)

---

## Step 2: Add to Streamlit App (pakfindata)

### 2A: Add logo to sidebar in app.py

Find `src/pakfindata/ui/app.py`. Locate where the sidebar is built 
(look for sidebar navigation buttons or the custom sidebar section).

Add the nav logo at the TOP of the sidebar, before any navigation:

```python
import base64
from pathlib import Path

def render_sidebar_logo():
    """Render pakfindata logo at top of sidebar."""
    logo_path = Path(__file__).parent / "assets" / "pakfindata-nav-logo.svg"
    if logo_path.exists():
        svg_content = logo_path.read_text()
        # Encode for st.markdown HTML rendering
        b64 = base64.b64encode(svg_content.encode()).decode()
        st.sidebar.markdown(
            f"""
            <div style="padding: 1rem 0.5rem 1.5rem 0.5rem; border-bottom: 1px solid #1e293b; margin-bottom: 1rem;">
                <img src="data:image/svg+xml;base64,{b64}" width="200" />
            </div>
            """,
            unsafe_allow_html=True,
        )
```

Call `render_sidebar_logo()` at the start of the sidebar rendering, 
BEFORE the navigation buttons.

### 2B: Add favicon to Streamlit config

Create or update `~/pakfindata/.streamlit/config.toml`:

```toml
[browser]
gatherUsageStats = false
```

Then in app.py where `st.set_page_config()` is called, add the favicon:

```python
# Find the existing st.set_page_config() call and update it:
st.set_page_config(
    page_title="pakfindata",
    page_icon="src/pakfindata/ui/assets/pakfindata-favicon.svg",  # ADD THIS
    layout="wide",
    initial_sidebar_state="expanded",
)
```

If page_icon doesn't accept SVG path, convert to PNG or use emoji fallback:
```python
page_icon="📊",  # fallback if SVG doesn't work
```

### 2C: Add logo to any "About" or landing page

If there's a dashboard or landing page, add the full banner:

```python
def render_banner():
    logo_path = Path(__file__).parent / "assets" / "pakfindata-banner.svg"
    if logo_path.exists():
        svg = logo_path.read_text()
        b64 = base64.b64encode(svg.encode()).decode()
        st.markdown(
            f'<img src="data:image/svg+xml;base64,{b64}" width="100%" style="max-width: 600px;" />',
            unsafe_allow_html=True,
        )
```

---

## Step 3: Add to React App (psx-live)

### 3A: Favicon

Edit `~/projects/psx-live/index.html`:

Find the existing `<link rel="icon"` tag and replace:

```html
<link rel="icon" type="image/svg+xml" href="/pakfindata-favicon.svg" />
<title>pakfindata — PSX Live Terminal</title>
```

### 3B: Nav bar logo

Edit `~/projects/psx-live/src/components/Layout.tsx`:

Find the top bar / header section. Replace the text "PSX LIVE" with the logo:

```tsx
// Replace this:
// <span className="text-xl font-bold">PSX LIVE</span>

// With this:
<a href="/" className="flex items-center gap-3">
  <img src="/pakfindata-nav-logo.svg" alt="pakfindata" className="h-8" />
</a>
```

If the nav logo SVG doesn't render well (text rendering varies by browser), 
use the icon + inline text approach instead:

```tsx
<a href="/" className="flex items-center gap-2">
  <img src="/pakfindata-icon.svg" alt="pakfindata" className="h-8 w-8 rounded-lg" />
  <span className="text-lg font-medium">
    <span className="text-slate-100">pak</span>
    <span className="text-blue-400">fin</span>
    <span className="text-slate-100">data</span>
  </span>
</a>
```

### 3C: Update page title

In `~/projects/psx-live/index.html`:
```html
<title>pakfindata — PSX Live Terminal</title>
```

---

## VERIFY

```bash
# Check Streamlit assets exist
ls -la ~/pakfindata/src/pakfindata/ui/assets/pakfindata-*.svg

# Check React public folder
ls -la ~/projects/psx-live/public/pakfindata-*.svg

# Check favicon reference in React
grep -n "favicon\|pakfindata" ~/projects/psx-live/index.html

# Check logo in Layout
grep -n "pakfindata\|nav-logo\|icon.svg" ~/projects/psx-live/src/components/Layout.tsx

# Check Streamlit page_icon
grep -n "page_icon\|set_page_config" ~/pakfindata/src/pakfindata/ui/app.py

# Check sidebar logo
grep -n "sidebar_logo\|nav-logo\|render_sidebar" ~/pakfindata/src/pakfindata/ui/app.py

# Run both apps and verify visually
streamlit run ~/pakfindata/src/pakfindata/ui/app.py
cd ~/projects/psx-live && npm run dev
```
