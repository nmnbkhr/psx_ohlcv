# Claude Code Prompt: Standardize All Sync Operations + Nightly Workflow

## Context

Tick data audit is done. DuckDB ohlcv_5s sync completed using the /tmp/ copy pattern.
Now standardize EVERYTHING to use the same fast approach.

**Key lesson from today:** DuckDB sqlite_scanner on /mnt/e/ (USB) = 30+ minutes. 
Copy to /tmp/ first = 1.4 seconds. ALWAYS copy to /tmp/ for any cross-DB operation.

**Market is still open today — don't disrupt anything. Build the tools now, 
run them tonight after market close.**

## Step 1: Create the master sync script

Create `~/sync_psx_cloud.sh` — downloads everything from Oracle Cloud VM:

```bash
cat > ~/sync_psx_cloud.sh << 'SCRIPT'
#!/bin/bash
echo "════════════════════════════════════════"
echo "  PSX Cloud → Local Sync"
echo "════════════════════════════════════════"
echo ""

# ── 1. Download JSONL tick files ──
echo "📥 Syncing JSONL tick files..."
rsync -avz --progress psx-cloud:~/psxdata/tick_logs/ /mnt/e/psxdata/tick_logs_cloud/
echo ""

# ── 2. Download tick_bars.db (ohlcv_5s, index tables) ──
echo "📥 Syncing tick_bars.db..."
rsync -avz --progress psx-cloud:~/psxdata/tick_bars.db /mnt/e/psxdata/tick_bars.db
echo ""

# ── 3. Summary ──
echo "════════════════════════════════════════"
echo "  Sync Complete"
echo "════════════════════════════════════════"
echo ""
echo "JSONL files:"
ls -lh /mnt/e/psxdata/tick_logs_cloud/*.jsonl 2>/dev/null | tail -5
echo ""
echo "tick_bars.db:"
ls -lh /mnt/e/psxdata/tick_bars.db
echo ""
echo "Next steps:"
echo "  1. Run: bash ~/sync_duckdb.sh"
echo "  2. Or use Tick Analytics → Sync tab in the app"
SCRIPT
chmod +x ~/sync_psx_cloud.sh
```

## Step 2: Create DuckDB sync script

Create `~/sync_duckdb.sh` — merges all sources into DuckDB using /tmp/ pattern:

```bash
cat > ~/sync_duckdb.sh << 'SCRIPT'
#!/bin/bash
echo "════════════════════════════════════════"
echo "  DuckDB Sync (via /tmp/ for speed)"
echo "════════════════════════════════════════"
echo ""

DUCK="/mnt/e/psxdata/pakfindata.duckdb"
TICK_DB="/mnt/e/psxdata/tick_bars.db"
PSX_DB="/mnt/e/psxdata/psx.sqlite"
JSONL_DIR="/mnt/e/psxdata/tick_logs_cloud"
TMP="/tmp/duckdb_sync_$$"

mkdir -p "$TMP"

# ── 1. Copy files to /tmp/ (fast I/O) ──
echo "📋 Copying to /tmp/ for fast I/O..."
cp "$DUCK" "$TMP/pakfindata.duckdb"
cp "$TICK_DB" "$TMP/tick_bars.db" 2>/dev/null
cp "$PSX_DB" "$TMP/psx.sqlite" 2>/dev/null
echo "  Done"
echo ""

# ── 2. Run all syncs in Python ──
python3 << 'PYEOF'
import duckdb
import os
from pathlib import Path

TMP = os.environ.get("TMP_DIR", "/tmp/duckdb_sync_" + str(os.getpid()))
# Find the actual tmp dir
import glob
tmp_dirs = glob.glob("/tmp/duckdb_sync_*")
TMP = tmp_dirs[-1] if tmp_dirs else "/tmp/duckdb_sync"

DUCK = f"{TMP}/pakfindata.duckdb"
TICK_DB = f"{TMP}/tick_bars.db"
PSX_DB = f"{TMP}/psx.sqlite"
JSONL_DIR = "/mnt/e/psxdata/tick_logs_cloud"

con = duckdb.connect(DUCK)
con.execute("INSTALL sqlite; LOAD sqlite;")

print("════ SYNC 1: tick_bars.db → DuckDB ════")
if os.path.exists(TICK_DB):
    con.execute(f"ATTACH '{TICK_DB}' AS tdb (TYPE SQLITE, READ_ONLY)")
    
    for table in ['ohlcv_5s', 'index_ohlcv_5s', 'index_raw_ticks']:
        try:
            before = con.execute(f"SELECT COUNT(*) FROM main.{table}").fetchone()[0]
            con.execute(f"INSERT OR IGNORE INTO main.{table} SELECT * FROM tdb.{table}")
            after = con.execute(f"SELECT COUNT(*) FROM main.{table}").fetchone()[0]
            print(f"  {table}: {before:,} → {after:,} (+{after-before:,})")
        except Exception as e:
            print(f"  {table}: ⚠️ {e}")
    
    con.execute("DETACH tdb")
else:
    print("  ⚠️ tick_bars.db not found in /tmp/")

print("")
print("════ SYNC 2: psx.sqlite → DuckDB ════")
if os.path.exists(PSX_DB):
    con.execute(f"ATTACH '{PSX_DB}' AS psx (TYPE SQLITE, READ_ONLY)")
    
    # Sync tables that exist in both
    for src_table, dst_table in [
        ('eod_ohlcv', 'eod_ohlcv'),
        ('intraday_bars', 'intraday_bars'),
        ('tick_logs', 'tick_logs'),
    ]:
        try:
            before = con.execute(f"SELECT COUNT(*) FROM main.{dst_table}").fetchone()[0]
            con.execute(f"INSERT OR IGNORE INTO main.{dst_table} SELECT * FROM psx.{src_table}")
            after = con.execute(f"SELECT COUNT(*) FROM main.{dst_table}").fetchone()[0]
            added = after - before
            if added > 0:
                print(f"  {dst_table}: {before:,} → {after:,} (+{added:,})")
            else:
                print(f"  {dst_table}: {before:,} (no new rows)")
        except Exception as e:
            print(f"  {dst_table}: ⚠️ {e}")
    
    con.execute("DETACH psx")
else:
    print("  ⚠️ psx.sqlite not found in /tmp/")

print("")
print("════ SYNC 3: JSONL → DuckDB tick_logs ════")
jsonl_dir = Path(JSONL_DIR)
if jsonl_dir.exists():
    # Find dates already in DuckDB
    try:
        existing_dates = set(r[0].strftime("%Y-%m-%d") if hasattr(r[0], 'strftime') else str(r[0]) 
                           for r in con.execute("SELECT DISTINCT date FROM tick_logs").fetchall())
    except:
        existing_dates = set()
    
    # Find JSONL files — handle both naming conventions
    jsonl_files = sorted(jsonl_dir.glob("*.jsonl"))
    # Filter to tick files only (not raw_ws)
    tick_files = [f for f in jsonl_files if not f.name.startswith("raw_ws")]
    
    missing = []
    for f in tick_files:
        # Extract date from filename: ticks_2026-03-24.jsonl or 2026-03-24.jsonl
        name = f.stem
        date_str = name.replace("ticks_", "")
        if date_str not in existing_dates:
            missing.append((f, date_str))
    
    if missing:
        total_imported = 0
        for filepath, date_str in missing:
            try:
                count_before = con.execute("SELECT COUNT(*) FROM tick_logs").fetchone()[0]
                con.execute(f"""
                    INSERT OR IGNORE INTO tick_logs
                    SELECT * FROM read_json_auto('{filepath}',
                         format='newline_delimited',
                         maximum_object_size=10485760)
                """)
                count_after = con.execute("SELECT COUNT(*) FROM tick_logs").fetchone()[0]
                added = count_after - count_before
                total_imported += added
                print(f"  {filepath.name}: +{added:,} rows")
            except Exception as e:
                print(f"  {filepath.name}: ⚠️ {e}")
        print(f"  Total imported: {total_imported:,}")
    else:
        print(f"  All {len(tick_files)} JSONL dates already in DuckDB")
else:
    print(f"  ⚠️ JSONL dir not found: {JSONL_DIR}")

print("")
print("════ FINAL STATUS ════")
for table in ['ohlcv_5s', 'index_ohlcv_5s', 'index_raw_ticks', 
              'tick_logs', 'eod_ohlcv', 'intraday_bars', 'psx_eod']:
    try:
        count = con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        print(f"  {table:25s} {count:>12,}")
    except:
        pass

con.close()
print("")
print("✅ All syncs complete")
PYEOF

# ── 3. Copy merged DuckDB back to /mnt/e/ ──
echo ""
echo "📋 Copying merged DuckDB back to /mnt/e/..."
cp "$TMP/pakfindata.duckdb" "$DUCK"
echo "  Done"
echo ""

# ── 4. Cleanup ──
rm -rf "$TMP"

echo "════════════════════════════════════════"
echo "  ✅ DuckDB fully synced"
echo "════════════════════════════════════════"
ls -lh "$DUCK"
SCRIPT
chmod +x ~/sync_duckdb.sh
```

## Step 3: Create combined nightly sync script

```bash
cat > ~/nightly_sync.sh << 'SCRIPT'
#!/bin/bash
echo "════════════════════════════════════════"
echo "  PSX Nightly Sync — Full Pipeline"
echo "  $(date '+%Y-%m-%d %H:%M PKT')"
echo "════════════════════════════════════════"
echo ""

# Step 1: Download from cloud
echo "━━━ Step 1/3: Cloud → Local ━━━"
bash ~/sync_psx_cloud.sh
echo ""

# Step 2: Merge into DuckDB
echo "━━━ Step 2/3: All Sources → DuckDB ━━━"
bash ~/sync_duckdb.sh
echo ""

# Step 3: Download PSX gap files (OI, circuit limits, etc.)
echo "━━━ Step 3/3: PSX Downloads ━━━"
cd ~/pakfindata && conda run -n psx python -m pakfindata.sources.psx_downloads today 2>/dev/null
echo ""

echo "════════════════════════════════════════"
echo "  ✅ Nightly sync complete"
echo "  $(date '+%Y-%m-%d %H:%M PKT')"
echo "════════════════════════════════════════"
SCRIPT
chmod +x ~/nightly_sync.sh
```

## Step 4: Add Sync buttons to Tick Analytics Sync tab

Read the current Sync tab code:
```bash
grep -n "def.*sync\|Sync\|Import\|tick_bars\|ohlcv_5s\|DuckDB" \
    ~/pakfindata/src/pakfindata/ui/page_views/tick_analytics.py | head -30
```

Add these buttons to the existing Sync tab (DO NOT remove existing buttons):

```python
# ═══ NEW SECTION: tick_bars.db → DuckDB Sync ═══
st.markdown("---")
st.markdown("#### Sync tick_bars.db → DuckDB (ohlcv_5s + index tables)")
st.caption("Merges cloud tick_bars.db data into DuckDB. Uses /tmp/ for fast I/O.")

col1, col2 = st.columns(2)

with col1:
    if st.button("🔄 Sync tick_bars.db → DuckDB", type="primary"):
        import shutil, tempfile
        
        tick_db = Path("/mnt/e/psxdata/tick_bars.db")
        duck_db = Path("/mnt/e/psxdata/pakfindata.duckdb")
        
        if not tick_db.exists():
            st.error("tick_bars.db not found. Run: bash ~/sync_psx_cloud.sh")
        else:
            with st.spinner("Copying to /tmp/ for fast I/O..."):
                tmp_dir = Path(tempfile.mkdtemp(prefix="ticksync_"))
                shutil.copy2(str(tick_db), str(tmp_dir / "tick_bars.db"))
                shutil.copy2(str(duck_db), str(tmp_dir / "pakfindata.duckdb"))
            
            with st.spinner("Syncing ohlcv_5s + index tables..."):
                import duckdb
                con = duckdb.connect(str(tmp_dir / "pakfindata.duckdb"))
                con.execute("INSTALL sqlite; LOAD sqlite;")
                con.execute(f"ATTACH '{tmp_dir}/tick_bars.db' AS tdb (TYPE SQLITE, READ_ONLY)")
                
                results = []
                for table in ['ohlcv_5s', 'index_ohlcv_5s', 'index_raw_ticks']:
                    try:
                        before = con.execute(f"SELECT COUNT(*) FROM main.{table}").fetchone()[0]
                        con.execute(f"INSERT OR IGNORE INTO main.{table} SELECT * FROM tdb.{table}")
                        after = con.execute(f"SELECT COUNT(*) FROM main.{table}").fetchone()[0]
                        results.append(f"{table}: {before:,} → {after:,} (+{after-before:,})")
                    except Exception as e:
                        results.append(f"{table}: ⚠️ {e}")
                
                con.execute("DETACH tdb")
                con.close()
            
            with st.spinner("Copying back to /mnt/e/..."):
                shutil.copy2(str(tmp_dir / "pakfindata.duckdb"), str(duck_db))
                shutil.rmtree(tmp_dir)
            
            for r in results:
                st.success(r)

with col2:
    # Show current DuckDB status
    try:
        import duckdb
        con = duckdb.connect(str(Path("/mnt/e/psxdata/pakfindata.duckdb")), read_only=True)
        for table in ['ohlcv_5s', 'index_ohlcv_5s', 'index_raw_ticks']:
            try:
                count = con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                min_d = con.execute(f"SELECT MIN(date) FROM {table}").fetchone()[0]
                max_d = con.execute(f"SELECT MAX(date) FROM {table}").fetchone()[0]
                st.metric(table, f"{count:,}", f"{min_d} → {max_d}")
            except:
                pass
        con.close()
    except:
        st.warning("DuckDB not accessible")
```

## Step 5: Fix signal_dashboard.py — use DuckDB instead of SQLite

```bash
# Find the SQLite tick_logs queries
grep -n "tick_logs\|psx\.sqlite\|sqlite3.*connect" \
    ~/pakfindata/src/pakfindata/ui/page_views/signal_dashboard.py | head -20
```

Replace SQLite tick_logs reads with DuckDB:

```python
# BEFORE:
con = sqlite3.connect("/mnt/e/psxdata/psx.sqlite")
df = pd.read_sql("SELECT ... FROM tick_logs ...", con)

# AFTER:
from pakfindata.db.connections import duck
df = duck("SELECT ... FROM tick_logs ...")
```

DuckDB has 4.6M tick_logs rows vs SQLite's 2.5M — more data, faster queries.

## Step 6: Fix Intraday Index tab — use DuckDB not raw JSONL

```bash
grep -n "jsonl\|JSONL\|tick_logs/" \
    ~/pakfindata/src/pakfindata/ui/page_views/intraday.py | head -10
```

If it reads JSONL directly for the Index tab, change to DuckDB:

```python
# BEFORE:
# Reading JSONL file directly for index data

# AFTER:
from pakfindata.db.connections import duck
df = duck("""
    SELECT * FROM index_ohlcv_5s 
    WHERE symbol = 'KSE100' AND date = ?
    ORDER BY ts
""", [date_str])
```

## Step 7: Verify all pages work

After all fixes, test each page:

```bash
# Run the app
cd ~/pakfindata
streamlit run src/pakfindata/ui/app.py

# Check these pages:
# 1. Tick Analytics → Overview (should show DuckDB tick_logs data)
# 2. Tick Analytics → Intraday Analytics (should show ohlcv_5s charts)
# 3. Tick Analytics → Sync (should show new sync buttons)
# 4. Signal Analysis → Run Analysis (should use DuckDB)
# 5. Intraday → Index tab (should use DuckDB index tables)
# 6. Microstructure → select date/symbol (should load JSONL)
# 7. Tick Replay → load + play (should work)
```

## DAILY WORKFLOW (after today)

```bash
# After market close (~17:45 PKT):
bash ~/nightly_sync.sh

# That's it. One command does everything:
#   1. Downloads JSONL + tick_bars.db from cloud
#   2. Merges tick_bars.db → DuckDB (ohlcv_5s, index tables)
#   3. Merges JSONL → DuckDB tick_logs
#   4. Merges psx.sqlite → DuckDB (intraday_bars, eod_ohlcv)
#   5. Downloads PSX gap files (OI, circuit limits)
```

## IMPORTANT

1. **ALL sync operations copy to /tmp/ first** — never do cross-DB ops on /mnt/e/
2. **Don't run sync while market is open** — tick_service writes to tick_bars.db
3. **DuckDB is single-writer** — close Streamlit before running ~/sync_duckdb.sh 
   OR use the Sync tab buttons (which already have write access)
4. **Keep SQLite files** — they're the write targets for scrapers + fallback source
5. **JSONL naming** — cloud produces `ticks_YYYY-MM-DD.jsonl`, code should handle both 
   `ticks_` prefix and bare `YYYY-MM-DD.jsonl` naming
6. **Don't modify tick_service.py** — cloud collection is working fine
7. **psxt_klines tables** — leave as-is for now (only quant_lab reads CSVs)
