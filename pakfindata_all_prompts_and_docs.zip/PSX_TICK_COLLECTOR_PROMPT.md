# Claude Code Prompt: PSX Real-Time Tick Collector + WS Relay (Oracle Cloud)

## Context

This runs on an Oracle Cloud ARM VM (Ubuntu 22.04, 2 CPU, 12GB RAM) in Jeddah.
It connects to PSX Terminal's WebSocket, collects every tick for all ~487 symbols,
stores everything to SQLite, and relays live data to any connected frontend client.

**This is the ONLY source of tick-level PSX data. No historical tick data exists 
for free anywhere. Every day this runs, we build irreplaceable data.**

## Project Structure

```
~/pakfindata/
├── src/pakfindata/
│   ├── __init__.py
│   ├── config.py
│   └── services/
│       ├── __init__.py
│       ├── tick_collector.py      ← NEW: WebSocket collector + storage
│       └── ws_relay.py            ← NEW: Relay for React frontend
├── .venv/                         ← Python virtual environment
└── services/
    └── psx_cloud_collector.sh     ← systemd wrapper script

~/psxdata/
├── tick_bars.db                   ← SQLite: 5s bars + raw ticks + indices
├── live_snapshot.json             ← JSON snapshot every 2s for polling clients
├── intraday/                      ← Daily CSV backups (DPS ticks, PSXT 1m)
└── logs/                          ← Daily log files
```

## Step 1: Check what exists

```bash
ls -la ~/pakfindata/src/pakfindata/services/ 2>/dev/null
cat ~/pakfindata/src/pakfindata/config.py 2>/dev/null
which python3
python3 --version
pip list 2>/dev/null | grep -i "websocket\|requests\|fastapi"
```

Read the output. If tick_service.py or ws_relay.py already exist, read them 
and ADAPT — don't duplicate. If nothing exists, create from scratch.

## Step 2: Install dependencies

```bash
cd ~/pakfindata
python3 -m venv .venv
source .venv/bin/activate
pip install websockets requests aiohttp
```

## Step 3: Create config.py

Create `~/pakfindata/src/pakfindata/config.py`:

```python
"""PSX pakfindata configuration — Oracle Cloud deployment."""
from pathlib import Path
from datetime import timezone, timedelta

# Paths (cloud — no /mnt/e/)
DATA_ROOT = Path.home() / "psxdata"
DB_PATH = DATA_ROOT / "tick_bars.db"
SNAPSHOT_PATH = DATA_ROOT / "live_snapshot.json"
INTRADAY_DIR = DATA_ROOT / "intraday"
LOG_DIR = DATA_ROOT / "logs"

# Ensure directories exist
DATA_ROOT.mkdir(parents=True, exist_ok=True)
INTRADAY_DIR.mkdir(parents=True, exist_ok=True)
LOG_DIR.mkdir(parents=True, exist_ok=True)

# PSX constants
PKT = timezone(timedelta(hours=5))
TRADING_DAYS_PER_YEAR = 245
CIRCUIT_BREAKER_PCT = 7.5
AUCTION_OPEN = (9, 15)   # 09:15 PKT
AUCTION_CLOSE = (15, 28)  # 15:28 PKT
MARKET_OPEN = (9, 30)     # 09:30 PKT (continuous)
MARKET_CLOSE = (15, 30)   # 15:30 PKT

# WebSocket
WS_URL = "wss://psxterminal.com/ws"
WS_RELAY_PORT = 8765

# Markets to subscribe (CSF not supported)
MARKETS = ["REG", "FUT", "ODL", "BNB", "IDX"]
```

## Step 4: Create tick_collector.py

Create `~/pakfindata/src/pakfindata/services/tick_collector.py`:

This is the core service. It must:

### 4A: WebSocket Connection

1. Connect to `wss://psxterminal.com/ws`
2. On connect, send subscription messages:
   ```json
   {"type": "subscribe", "market": "REG"}
   {"type": "subscribe", "market": "FUT"}
   {"type": "subscribe", "market": "ODL"}
   {"type": "subscribe", "market": "BNB"}
   {"type": "subscribe", "market": "IDX"}
   ```
3. Parse incoming messages. Each message is JSON with structure:
   ```json
   {
     "type": "lt",           // "lt" = last trade (tick)
     "symbol": "HUBC",
     "market": "REG",
     "data": {
       "price": 188.38,
       "volume": 500,
       "change": -6.72,
       "changePercent": -3.44,
       "high": 197.9,
       "low": 187.1,
       "open": 195.1,
       "close": 195.1,       // previous close
       "timestamp": 1773650988000,
       "turnover": 1234567890,
       "totalVolume": 5978764
     }
   }
   ```
   Other message types: `"idx"` (index update), `"bid"`, `"ask"`, `"status"`

4. Ping every 30 seconds to keep connection alive
5. If no message received for 60 seconds during market hours → force reconnect
6. Auto-reconnect on any disconnect with exponential backoff (1s, 2s, 4s, max 30s)

### 4B: In-Memory Storage (during market hours)

Store everything in RAM during market hours. Three data structures:

```python
# 1. Raw ticks — every trade
raw_ticks: dict[str, list] = {}  
# key = symbol, value = list of (timestamp_ms, price, volume)

# 2. OHLCV 5-second bars — aggregated
bars_5s: dict[str, dict] = {}
# key = (symbol, bar_timestamp), value = {open, high, low, close, volume, trades}

# 3. Index ticks
index_ticks: dict[str, list] = {}
# key = index name (KSE100, KSE30, etc), value = list of (timestamp_ms, value, change, change_pct)

# 4. Latest quote per symbol (for snapshot)
latest: dict[str, dict] = {}
# key = symbol, value = full last-trade data
```

For 5-second bars: floor each tick's timestamp to nearest 5-second boundary.
```python
bar_ts = (tick_ts // 5000) * 5000  # 5-second floor
```

### 4C: Snapshot Writer (every 2 seconds)

Write `live_snapshot.json` every 2 seconds containing:
```json
{
  "timestamp": 1773650988000,
  "symbols": {
    "HUBC": {"price": 188.38, "volume": 500, "change": -6.72, "changePct": -3.44, 
             "high": 197.9, "low": 187.1, "open": 195.1, "prevClose": 195.1, 
             "totalVolume": 5978764, "lastTick": 1773650988000},
    ...
  },
  "indices": {
    "KSE100": {"value": 117234.56, "change": -1234.56, "changePct": -1.04},
    ...
  },
  "meta": {"totalSymbols": 487, "ticksToday": 87044, "lastUpdate": "13:49:48"}
}
```

Write directly (no .tmp rename — causes issues on some filesystems):
```python
with open(SNAPSHOT_PATH, 'w') as f:
    json.dump(snapshot_data, f)
```

### 4D: Checkpoint Saves (every 30 minutes)

Every 30 minutes during market hours, flush current data to SQLite as crash protection.
Use WAL mode for concurrent reads.

### 4E: EOD Flush (15:35 PKT)

At 15:35 PKT, flush ALL data to SQLite:

**Table: `ohlcv_5s`**
```sql
CREATE TABLE IF NOT EXISTS ohlcv_5s (
    symbol TEXT NOT NULL,
    timestamp INTEGER NOT NULL,  -- ms epoch, bar start time
    open REAL,
    high REAL,
    low REAL,
    close REAL,
    volume INTEGER,
    trades INTEGER,
    date TEXT,  -- YYYY-MM-DD
    PRIMARY KEY (symbol, timestamp)
);
CREATE INDEX IF NOT EXISTS idx_ohlcv_5s_date ON ohlcv_5s(date);
```

**Table: `raw_ticks`**
```sql
CREATE TABLE IF NOT EXISTS raw_ticks (
    symbol TEXT NOT NULL,
    timestamp INTEGER NOT NULL,  -- ms epoch
    price REAL,
    volume INTEGER,
    date TEXT,  -- YYYY-MM-DD
    PRIMARY KEY (symbol, timestamp, price, volume)
);
CREATE INDEX IF NOT EXISTS idx_raw_ticks_date ON raw_ticks(date);
```

**Table: `index_ticks`**
```sql
CREATE TABLE IF NOT EXISTS index_ticks (
    index_name TEXT NOT NULL,
    timestamp INTEGER NOT NULL,  -- ms epoch
    value REAL,
    change REAL,
    change_pct REAL,
    date TEXT,
    PRIMARY KEY (index_name, timestamp)
);
```

Use `INSERT OR IGNORE` to handle duplicate ticks from checkpoint + EOD.

After flush, log:
```
✅ EOD complete: 42,976 stock bars, 87,044 raw ticks, 1,294 index ticks
```

Clear in-memory data after successful flush.

### 4F: Sleep/Wake Schedule

```
Boot → Sleep until 09:10 PKT
09:10 → Connect WebSocket, subscribe all markets
09:15 → Market opens (auction), ticks start
09:30 → Continuous trading begins
Every 2s → Write snapshot
Every 30m → Checkpoint to DB
15:28 → Closing auction starts
15:30 → Market closes
15:35 → EOD flush to DB
15:40 → Disconnect WebSocket, exit
```

If started outside market hours, calculate seconds until next 09:10 PKT and sleep.

### 4G: Console Output

Print with emoji for quick visual status:
```
[09:10:00] 😴 Sleeping until 09:15 PKT...
[09:15:01] 🔌 Connecting to wss://psxterminal.com/ws...
[09:15:02] ✅ Connected. Subscribing to REG, FUT, ODL, BNB, IDX...
[09:15:03] 📡 Subscribed. Waiting for ticks...
[09:15:05] 📊 Tick #1: HUBC 195.10 x 30650
[09:15:30] 📈 1m: 2,341 ticks | 487 symbols | KSE100: 117,234
[09:30:00] 📈 15m: 18,432 ticks | 487 symbols active
[09:45:00] 💾 Checkpoint: 35,211 ticks, 8,234 bars saved
[15:35:00] 💾 EOD flush: 87,044 ticks, 42,976 bars, 1,294 index ticks
[15:40:00] 🔌 Disconnected. Done for today.
```

Print summary every 1 minute (not every tick — too noisy).

## Step 5: Create ws_relay.py

Create `~/pakfindata/src/pakfindata/services/ws_relay.py`:

This runs alongside tick_collector.py. It:

1. Listens on `0.0.0.0:8765` (accessible from outside VM)
2. Accepts WebSocket connections from React frontend
3. Reads `live_snapshot.json` every 2 seconds
4. Broadcasts snapshot to ALL connected clients
5. Also provides HTTP health check at `GET /health`

```python
"""
WS Relay — broadcasts live_snapshot.json to connected frontends.

Does NOT connect to PSX Terminal directly.
Does NOT store anything.
Pure pass-through from snapshot file → WebSocket clients.

Usage:
    python -m pakfindata.services.ws_relay
"""
```

Implementation:
- Use `websockets` library
- On new client connect: immediately send latest snapshot
- Every 2 seconds: read snapshot file, broadcast to all clients
- Handle client disconnects gracefully
- If snapshot file doesn't exist or is stale (>10s old), send status message:
  ```json
  {"type": "status", "message": "Market closed or collector not running", "timestamp": ...}
  ```

## Step 6: Create systemd services

### tick_collector service

Create `/etc/systemd/system/psx-tick-collector.service`:

```ini
[Unit]
Description=PSX Tick Collector — WebSocket → SQLite
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/pakfindata
Environment=HOME=/home/ubuntu
Environment=PYTHONPATH=/home/ubuntu/pakfindata/src
ExecStart=/home/ubuntu/pakfindata/.venv/bin/python -m pakfindata.services.tick_collector
StandardOutput=append:/home/ubuntu/psxdata/logs/tick_collector.log
StandardError=append:/home/ubuntu/psxdata/logs/tick_collector_error.log
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### tick_collector timer (9:10 AM PKT = 4:10 AM UTC)

Create `/etc/systemd/system/psx-tick-collector.timer`:

```ini
[Unit]
Description=PSX Tick Collector Timer — 9:10 AM PKT Mon-Fri

[Timer]
OnCalendar=Mon..Fri *-*-* 04:10:00 UTC
Persistent=true

[Install]
WantedBy=timers.target
```

### ws_relay service (always running)

Create `/etc/systemd/system/psx-ws-relay.service`:

```ini
[Unit]
Description=PSX WebSocket Relay — broadcasts to frontends
After=network-online.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/pakfindata
Environment=HOME=/home/ubuntu
Environment=PYTHONPATH=/home/ubuntu/pakfindata/src
ExecStart=/home/ubuntu/pakfindata/.venv/bin/python -m pakfindata.services.ws_relay
StandardOutput=append:/home/ubuntu/psxdata/logs/ws_relay.log
StandardError=append:/home/ubuntu/psxdata/logs/ws_relay_error.log
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

### Post-market backup service

Create `/etc/systemd/system/psx-backup.service`:

```ini
[Unit]
Description=PSX Post-Market DPS + PSXT Backup
After=psx-tick-collector.service

[Service]
Type=oneshot
User=ubuntu
WorkingDirectory=/home/ubuntu/pakfindata
Environment=HOME=/home/ubuntu
Environment=PYTHONPATH=/home/ubuntu/pakfindata/src
ExecStart=/home/ubuntu/pakfindata/.venv/bin/python -m pakfindata.services.post_market_backup
StandardOutput=append:/home/ubuntu/psxdata/logs/backup.log
StandardError=append:/home/ubuntu/psxdata/logs/backup_error.log
```

### Post-market backup timer (15:45 PKT = 10:45 UTC)

Create `/etc/systemd/system/psx-backup.timer`:

```ini
[Unit]
Description=PSX Post-Market Backup Timer

[Timer]
OnCalendar=Mon..Fri *-*-* 10:45:00 UTC
Persistent=true

[Install]
WantedBy=timers.target
```

### Enable all services

```bash
sudo systemctl daemon-reload

# Timer for tick collector (Mon-Fri 9:10 AM PKT)
sudo systemctl enable psx-tick-collector.timer
sudo systemctl start psx-tick-collector.timer

# WS relay always running
sudo systemctl enable psx-ws-relay.service
sudo systemctl start psx-ws-relay.service

# Timer for post-market backup (Mon-Fri 3:45 PM PKT)
sudo systemctl enable psx-backup.timer
sudo systemctl start psx-backup.timer
```

## Step 7: Create post_market_backup.py

Create `~/pakfindata/src/pakfindata/services/post_market_backup.py`:

```python
"""
Post-market backup — fetches DPS ticks + PSXT 1m klines after market close.
Run by systemd timer at 15:45 PKT.
"""
```

This does exactly what the DPS ticks + PSXT 1m section from 
PSX_MARKET_DATA_PROMPT.md does:

1. Fetch all symbols from PSXT /symbols API
2. For each symbol, GET `https://dps.psx.com.pk/timeseries/int/{sym}`
   - Save to `~/psxdata/intraday/dps_ticks_YYYY-MM-DD.csv`
3. For each symbol, paginate `https://psxterminal.com/api/klines/{sym}/1m`
   - Save to `~/psxdata/intraday/psxt_YYYY-MM-DD_1m.csv`
4. Print summary
5. Optionally send Discord webhook notification

Skip weekends (check day of week at start).

## Step 8: Create status script

Create `~/pakfindata/services/status.sh`:

```bash
#!/bin/bash
echo "═══════════════════════════════════════"
echo "  PSX CLOUD COLLECTOR STATUS"
echo "═══════════════════════════════════════"
DATE=$(date +%Y-%m-%d)
echo "📅 $DATE $(date +%H:%M:%S) PKT"
echo ""

echo "=== SERVICES ==="
for svc in psx-tick-collector psx-ws-relay; do
    if systemctl is-active --quiet $svc; then
        echo "  ✅ $svc"
    else
        echo "  ⏸️  $svc (inactive)"
    fi
done

echo ""
echo "=== TIMERS ==="
systemctl list-timers psx-* --no-pager 2>/dev/null | grep psx | sed 's/^/  /'

echo ""
echo "=== DATA ==="
DB="$HOME/psxdata/tick_bars.db"
if [ -f "$DB" ]; then
    echo "  tick_bars.db: $(du -h $DB | awk '{print $1}')"
    sqlite3 "$DB" "
        SELECT '  ohlcv_5s:    ' || COUNT(*) || ' bars' FROM ohlcv_5s;
        SELECT '  raw_ticks:   ' || COUNT(*) || ' ticks' FROM raw_ticks;
        SELECT '  index_ticks: ' || COUNT(*) || ' points' FROM index_ticks;
    " 2>/dev/null
fi

SNAP="$HOME/psxdata/live_snapshot.json"
if [ -f "$SNAP" ]; then
    AGE=$(($(date +%s) - $(stat -c %Y "$SNAP")))
    echo "  snapshot: ${AGE}s old"
fi

echo ""
echo "=== RECENT FILES ==="
ls -lt ~/psxdata/intraday/*.csv 2>/dev/null | head -5 | awk '{print "  " $6,$7,$8,$9}'

echo ""
echo "=== DISK ==="
df -h / | tail -1 | awk '{print "  " $3 " used / " $2 " (" $5 " full)"}'
echo "  psxdata: $(du -sh ~/psxdata/ 2>/dev/null | awk '{print $1}')"
```

```bash
chmod +x ~/pakfindata/services/status.sh
```

## Step 9: Keepalive cron (prevent Oracle idle reclaim)

```bash
crontab -e
# Add:
0 */6 * * * curl -s https://dps.psx.com.pk > /dev/null 2>&1
```

## VERIFY

```bash
# Test tick collector manually (will connect, collect, and exit at 15:40)
source ~/pakfindata/.venv/bin/activate
export PYTHONPATH=~/pakfindata/src
python -m pakfindata.services.tick_collector

# Test WS relay
python -m pakfindata.services.ws_relay &
# From another terminal: 
python -c "
import asyncio, websockets, json
async def test():
    async with websockets.connect('ws://localhost:8765') as ws:
        msg = await ws.recv()
        print(json.loads(msg))
asyncio.run(test())
"

# Check timers
sudo systemctl list-timers psx-*

# Run status
bash ~/pakfindata/services/status.sh

# Check from your laptop (replace YOUR_IP):
ssh ubuntu@YOUR_IP bash ~/pakfindata/services/status.sh
```

## IMPORTANT NOTES

1. **Timestamps from PSX Terminal WebSocket are in MILLISECONDS** (13 digits).
   DPS timestamps are in SECONDS (10 digits). Always check and normalize.

2. **No .tmp + rename for snapshot** — write directly. Atomic rename fails
   on some filesystems and WSL2.

3. **5-second bars, not 1-second** — PSX doesn't tick fast enough per symbol
   to justify 1s bars. 5s gives meaningful OHLCV.

4. **INSERT OR IGNORE** — ticks may overlap between checkpoint and EOD flush.
   Primary keys prevent duplicates.

5. **WS relay reads file, does NOT connect to PSX** — separation of concerns.
   If relay crashes, collector keeps running. If collector crashes, relay 
   sends "market closed" status to frontend.

6. **Memory usage**: ~500MB for full day. 487 symbols × ~200 ticks each × 
   24 bytes = ~2.3MB for raw ticks. Bars are much smaller. No memory leak 
   since we clear after EOD flush.

7. **Oracle VM timezone**: Set to PKT with `sudo timedatectl set-timezone Asia/Karachi`

8. **This runs UNATTENDED**. No human interaction. Auto-start, auto-collect,
   auto-save, auto-stop. Check status via SSH from anywhere.
