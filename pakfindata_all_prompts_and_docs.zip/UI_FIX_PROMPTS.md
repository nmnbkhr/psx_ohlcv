# Claude Code Prompt: Streamlit UI Fixes — Phase 1 (Quick Bleeding Fixes)

## Context

UI audit completed. No critical page bleeding found. These are quick fixes.

## Fix 1: Remove sidebar writes from chat.py

File: `src/pakfindata/ui/page_views/chat.py` lines 279-296

The chat page writes "Clear Chat" and "Reset Agents" buttons to st.sidebar.
This leaks sidebar content when navigating to other pages.

Move these buttons INTO the chat page content area (not sidebar).
Replace `st.sidebar.button(...)` with regular `st.button(...)` in a 
columns layout at the top of the page:

```python
# Instead of sidebar buttons, put them inline
col1, col2, col3 = st.columns([6, 1, 1])
with col2:
    if st.button("🗑️ Clear"):
        # existing clear logic
with col3:
    if st.button("🔄 Reset"):
        # existing reset logic
```

## Fix 2: Fix red color inconsistency

File: `src/pakfindata/ui/app.py` line 274
File: `src/pakfindata/ui/helpers.py` line 130

Change `#FF1744` → `#FF5252` to match the Bloomberg theme red used everywhere else.
Search entire ui/ directory for `#FF1744` and replace all occurrences with `#FF5252`.

```bash
grep -rn "FF1744" src/pakfindata/ui/ --include="*.py"
# Replace all
```

## Fix 3: Fix get_connection() timeout inconsistency

File: `src/pakfindata/ui/app.py` line 483

Check what timeout value is set. It should match whatever helpers.py uses.
Standardize to `timeout=30` across all get_connection() calls.

```bash
grep -rn "get_connection\|sqlite3.connect\|timeout" src/pakfindata/ui/ --include="*.py" | head -20
```

Make them all consistent.

## Fix 4: Clean dead code

- `live_ohlcv.py:29` — imports render_footer but never calls it. Remove the import.
- `regular_market.py:223,247` — uses legacy nav_to names. Update to current names.

## VERIFY

```bash
# No sidebar writes outside app.py
grep -rn "st\.sidebar" src/pakfindata/ui/page_views/ --include="*.py" | grep -v __pycache__

# No FF1744 remaining
grep -rn "FF1744" src/pakfindata/ui/ --include="*.py" | grep -v __pycache__

# Connection timeout consistent
grep -rn "timeout" src/pakfindata/ui/ --include="*.py" | grep -v __pycache__

# Run app — navigate between pages, no stale sidebar content
```

---
---
---

# Claude Code Prompt: Streamlit UI Fixes — Phase 2 (Theme Standardization)

## Context

UI audit found 267 hardcoded hex colors across 30 page files. Four pages use 
completely different color schemes from the Bloomberg theme. This prompt 
standardizes everything.

## The Bloomberg Theme Tokens

The app already has a Bloomberg-style theme defined in app.py. These are the 
canonical colors. ALL pages must use ONLY these:

```python
# Read the existing theme from app.py first — find the CSS injection block
# around line 1149. Extract the exact colors used.
# Typical Bloomberg terminal palette:
THEME = {
    "bg_primary": "#0f1117",      # Deepest background
    "bg_secondary": "#1a1b26",    # Card/panel background  
    "bg_tertiary": "#262730",     # Elevated surfaces
    "bg_hover": "#333645",        # Hover state
    "text_primary": "#fafafa",    # Main text
    "text_secondary": "#a0a0a0",  # Muted text
    "text_muted": "#666666",      # Very muted
    "accent_blue": "#2F81F7",     # Primary accent (Bloomberg blue)
    "green": "#00C853",           # Price up / positive
    "red": "#FF5252",             # Price down / negative
    "amber": "#FFB300",           # Warning / neutral
    "border": "#333645",          # Borders
}
```

FIRST: Read app.py's CSS injection to get the EXACT colors. Don't assume — 
extract them. Then use those exact values below.

## Step 1: Create a shared theme module

Create `src/pakfindata/ui/theme.py`:

```python
"""
Centralized Bloomberg-style theme tokens for all Streamlit pages.
Import this instead of hardcoding colors.
"""

# Read from app.py's CSS injection — extract exact values
# These must match what app.py injects globally

COLORS = {
    # ... extracted from app.py
}

def bloomberg_card_css(title: str = "") -> str:
    """Return CSS for a Bloomberg-style card container."""
    return f"""
    <div style="
        background: {COLORS['bg_secondary']};
        border: 1px solid {COLORS['border']};
        border-radius: 8px;
        padding: 1rem;
        margin-bottom: 1rem;
    ">
    {"<h4 style='margin:0 0 0.5rem 0;color:" + COLORS['text_secondary'] + "'>" + title + "</h4>" if title else ""}
    """

def metric_card(label: str, value: str, delta: str = "", color: str = "blue") -> str:
    """Return HTML for a consistent metric card."""
    color_hex = COLORS.get(color, COLORS['accent_blue'])
    return f"""
    <div style="
        background: {COLORS['bg_secondary']};
        border-left: 3px solid {color_hex};
        border-radius: 4px;
        padding: 0.75rem 1rem;
    ">
        <div style="font-size: 12px; color: {COLORS['text_muted']}; text-transform: uppercase; letter-spacing: 1px;">{label}</div>
        <div style="font-size: 24px; font-weight: 500; color: {COLORS['text_primary']}; margin-top: 4px;">{value}</div>
        {"<div style='font-size: 13px; color:" + color_hex + ";margin-top:2px;'>" + delta + "</div>" if delta else ""}
    </div>
    """
```

## Step 2: Fix the 4 off-theme pages

### ai_insights.py
- Remove lines 34-94 (purple gradient CSS override)
- Remove lines 484-583 (cyan table override)
- Replace `#667eea` / `#764ba2` purple → `{COLORS['accent_blue']}`
- Replace all `linear-gradient()` → solid `{COLORS['bg_secondary']}`
- Import and use theme.py tokens

### signal_dashboard.py
- Remove lines 80-136 (custom CSS block)
- Replace `#C8A96E` gold → `{COLORS['amber']}`
- Replace `#12151A` / `#1A1D23` → `{COLORS['bg_primary']}` / `{COLORS['bg_secondary']}`
- Replace `.metric-card` custom CSS → use theme.metric_card()

### debt_terminal.py
- Remove lines 36-119 (custom CSS block)
- Replace `#0a0e17` / `#0f1520` → `{COLORS['bg_primary']}`
- Replace `#00d4aa` → `{COLORS['green']}`
- Replace `.metric-card` custom CSS → use theme.metric_card()
- ⚠️ This page and signal_dashboard.py BOTH define `.metric-card` differently — 
  this is the CSS collision. Fix by using theme.metric_card() in both.

### chat.py
- Replace `#1a1a2e` / `#16213e` → `{COLORS['bg_primary']}` / `{COLORS['bg_secondary']}`
- Replace `#ff9800` orange → `{COLORS['amber']}`
- Remove any `linear-gradient()` 

## Step 3: Remove all linear-gradient() from pages

```bash
grep -rn "linear-gradient" src/pakfindata/ui/page_views/ --include="*.py" | grep -v __pycache__
```

Replace every `linear-gradient(...)` with the solid bg color from THEME.
Bloomberg Terminal doesn't use gradients — flat surfaces only.

## Step 4: Deduplicate app.py ↔ helpers.py

The audit found 600+ lines duplicated between app.py and helpers.py.

```bash
# Find the overlap
diff <(grep -n "def " src/pakfindata/ui/app.py) <(grep -n "def " src/pakfindata/ui/helpers.py)
```

- Move all shared functions to helpers.py (single source of truth)
- app.py imports from helpers.py
- Remove duplicate function definitions from app.py
- Keep app.py focused on: navigation setup, page config, CSS injection, main()

## VERIFY

```bash
# No more off-theme colors
echo "=== Purple gradients ==="
grep -rn "667eea\|764ba2" src/pakfindata/ui/ --include="*.py" | grep -v __pycache__

echo "=== Gold accent ==="
grep -rn "C8A96E" src/pakfindata/ui/ --include="*.py" | grep -v __pycache__

echo "=== Orange accent ==="
grep -rn "ff9800" src/pakfindata/ui/ --include="*.py" | grep -v __pycache__

echo "=== Custom dark bg ==="
grep -rn "0a0e17\|0f1520\|1a1a2e\|16213e\|12151A\|1A1D23" src/pakfindata/ui/ --include="*.py" | grep -v __pycache__

echo "=== Gradients ==="
grep -rn "linear-gradient" src/pakfindata/ui/page_views/ --include="*.py" | grep -v __pycache__

echo "=== .metric-card redefinitions ==="
grep -rn "metric-card" src/pakfindata/ui/page_views/ --include="*.py" | grep -v __pycache__

# Run app — all pages should look consistent
streamlit run src/pakfindata/ui/app.py
```

---
---
---

# Claude Code Prompt: Streamlit UI Fixes — Phase 3 (Performance)

## Context

UI audit found 39 of 50 pages have ZERO caching. DB connections are not pooled.
Live pages refresh aggressively.

## Fix 1: Add caching to data-heavy pages

For each page listed below, find the main data-loading function(s) and wrap 
with `@st.cache_data(ttl=300)` (5 minute cache):

Priority pages (heaviest queries, most visited):
1. `fixed_income.py` — bond data queries
2. `company_deep.py` — company fundamental data
3. `fx_dashboard.py` — FX rate queries
4. `alm_dashboard.py` — ALM calculations
5. `market_summary.py` — market overview data
6. `sector_analysis.py` — sector breakdown
7. `intraday.py` — historical intraday data (NOT live data)
8. `pmex.py` — commodity data
9. `quote_monitor.py` — stock quotes
10. `regular_market.py` — market data
11. `screener.py` — stock screener

For each page:
1. Find the data loading function (usually calls get_connection() + SQL query)
2. Extract into a standalone function if inline
3. Add `@st.cache_data(ttl=300)` decorator
4. Make sure the function takes serializable args (no connection objects as params)
   - Pass the DB path string, not the connection
   - Create connection inside the cached function

Pattern:
```python
@st.cache_data(ttl=300)
def load_sector_data(db_path: str) -> pd.DataFrame:
    con = sqlite3.connect(db_path, timeout=30)
    df = pd.read_sql("SELECT ...", con)
    con.close()
    return df
```

DO NOT cache:
- Live data pages (live_ticker.py, live_market.py, live_indices.py)
- Pages that modify data (sync pages, admin pages)
- User-specific queries with session_state filters (cache after filter applied)

## Fix 2: Connection pooling

Currently `get_connection()` creates a new sqlite3 connection on every call.

Create a cached connection factory:

```python
@st.cache_resource
def get_cached_connection(db_path: str):
    """Return a cached SQLite connection. Reused across reruns."""
    con = sqlite3.connect(db_path, timeout=30, check_same_thread=False)
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA cache_size=-64000")  # 64MB cache
    return con
```

Replace `get_connection()` calls in read-only pages with `get_cached_connection()`.
Keep `get_connection()` for write operations (sync, admin).

## Fix 3: Reduce live page refresh rates

- `live_ticker.py`: Change refresh from 2s → 5s (reduce server load)
- `live_indices.py`: Keep at 2s (indices update less frequently, lightweight)
- `live_market.py`: Not a live page (reads from DB), no change needed

```bash
grep -rn "autorefresh\|interval.*2000\|interval.*3000" src/pakfindata/ui/page_views/ --include="*.py" | grep -v __pycache__
```

## VERIFY

```bash
# Count cached pages (should be 11+)
echo "=== Pages with caching ==="
grep -rln "cache_data\|cache_resource" src/pakfindata/ui/page_views/ --include="*.py" | grep -v __pycache__ | wc -l

# No uncached heavy queries
echo "=== Pages with SQL but no cache ==="
for f in $(find src/pakfindata/ui/page_views/ -name "*.py" -not -path "*__pycache__*"); do
    has_sql=$(grep -c "read_sql\|execute\|SELECT" "$f" 2>/dev/null)
    has_cache=$(grep -c "cache_data\|cache_resource" "$f" 2>/dev/null)
    if [ "$has_sql" -gt 0 ] && [ "$has_cache" -eq 0 ]; then
        echo "  ⚠️ $(basename $f): $has_sql SQL calls, 0 cache"
    fi
done

# Connection pooling in place
grep -rn "get_cached_connection" src/pakfindata/ui/ --include="*.py" | grep -v __pycache__ | wc -l

# Run app — pages should load faster on second visit
streamlit run src/pakfindata/ui/app.py
```
