# Claude Code Prompt: Auto-Start PSX Tick Collection Service

## What this does

Creates a fully automatic service that:
- Starts tick_service.py at 9:10 AM PKT every trading day (Mon-Fri)
- Collects all ticks via WebSocket + saves to tick_bars.db
- WS relay runs on port 8765 for React frontend
- Checkpoint saves every 30 min (crash protection)
- EOD flush at 15:35 PKT saves everything
- Fetches DPS intraday ticks as backup after market close
- Fetches PSX Terminal 1m klines as secondary backup
- Stops cleanly at 15:45 PKT
- Auto-starts next trading day — NO manual intervention ever

## Step 1: Create the wrapper script

Create `~/pakfindata/services/psx_collector_service.sh`:

```bash
#!/bin/bash
# PSX Market Data Collection Service
# Auto-runs tick collector + post-market backups
# Managed by systemd timer — no manual start needed

set -euo pipefail

# ─── CONFIG ───────────────────────────────────────────
PROJ_DIR="$HOME/pakfindata"
PSXDATA_DIR="$HOME/psxdata"
INTRADAY_DIR="$PSXDATA_DIR/intraday"
LOG_DIR="$PSXDATA_DIR/logs"
PYTHON="/path/to/python3"  # UPDATE THIS — find with: which python3
DPS_BASE="https://dps.psx.com.pk"
PSXT_BASE="https://psxterminal.com/api"
PKT_OFFSET="+05:00"

# Auto-detect Python
if [ -f "$PROJ_DIR/.venv/bin/python" ]; then
    PYTHON="$PROJ_DIR/.venv/bin/python"
elif command -v python3 &> /dev/null; then
    PYTHON=$(which python3)
fi

mkdir -p "$LOG_DIR" "$INTRADAY_DIR"

DATE=$(TZ="Asia/Karachi" date +%Y-%m-%d)
LOG="$LOG_DIR/collector_${DATE}.log"

log() {
    echo "[$(TZ='Asia/Karachi' date '+%H:%M:%S')] $1" | tee -a "$LOG"
}

# ─── PRE-MARKET CHECK ─────────────────────────────────
DAY_OF_WEEK=$(TZ="Asia/Karachi" date +%u)  # 1=Mon, 7=Sun
if [ "$DAY_OF_WEEK" -gt 5 ]; then
    log "Weekend — skipping"
    exit 0
fi

# TODO: Add Pakistan public holiday check here if needed

log "═══════════════════════════════════════════════"
log "  PSX COLLECTOR SERVICE — $DATE"
log "═══════════════════════════════════════════════"

# ─── PHASE 1: RUN TICK COLLECTOR (9:10 → 15:40) ──────
log "🚀 Starting tick_service.py..."

cd "$PROJ_DIR"
export PYTHONPATH="$PROJ_DIR/src:$PYTHONPATH"

# Start tick collector in background
$PYTHON -m pakfindata.services.tick_service >> "$LOG" 2>&1 &
TICK_PID=$!
log "📡 Tick collector PID: $TICK_PID"

# Wait for market close (15:40 PKT)
# tick_service handles its own EOD flush at 15:35
# We give it 5 extra minutes then proceed to backups
while true; do
    CURRENT_HOUR=$(TZ="Asia/Karachi" date +%H)
    CURRENT_MIN=$(TZ="Asia/Karachi" date +%M)
    
    # Check if tick_service is still running
    if ! kill -0 $TICK_PID 2>/dev/null; then
        log "⚠️ tick_service died unexpectedly. Restarting..."
        $PYTHON -m pakfindata.services.tick_service >> "$LOG" 2>&1 &
        TICK_PID=$!
        log "🔄 Restarted with PID: $TICK_PID"
    fi
    
    # Exit loop after 15:40 PKT
    if [ "$CURRENT_HOUR" -ge 15 ] && [ "$CURRENT_MIN" -ge 40 ]; then
        break
    fi
    
    # Also exit if it's somehow past 16:00
    if [ "$CURRENT_HOUR" -ge 16 ]; then
        break
    fi
    
    sleep 60
done

log "🔔 Market closed. Waiting for EOD flush to complete..."
sleep 30  # Give tick_service time to finish EOD flush

# Gracefully stop tick_service
if kill -0 $TICK_PID 2>/dev/null; then
    kill -SIGTERM $TICK_PID
    wait $TICK_PID 2>/dev/null || true
    log "✅ Tick collector stopped"
fi

# ─── PHASE 2: DPS TICK BACKUP (POST-MARKET) ──────────
log ""
log "═══ POST-MARKET BACKUPS ═══"
log "📥 Fetching DPS intraday ticks..."

$PYTHON -c "
import requests, csv, time, json
from datetime import datetime, timezone, timedelta
from pathlib import Path

DPS = '$DPS_BASE'
PSXT = '$PSXT_BASE'
PKT = timezone(timedelta(hours=5))
DATE = datetime.now(PKT).strftime('%Y-%m-%d')
OUT = Path('$INTRADAY_DIR')

# Get symbols from PSX Terminal
try:
    syms = requests.get(f'{PSXT}/symbols', timeout=10).json()['data']
except:
    syms = []

skip = {'ALLSHR','KSE100','KSE100PR','KSE30','KMI30','KMIALLSHR',
        'BKTI','OGTI','PSXDIV20','UPP9','NITPGI','NBPPGI','MZNPI',
        'JSMFI','ACI','JSGBKTI','HBLTTI','MII30'}
syms = [s for s in syms if s not in skip]

if not syms:
    print('⚠️ Could not get symbols — using DPS market-watch')
    try:
        mw = requests.get(f'{DPS}/market-watch', timeout=10).json()
        syms = list(set(r.get('symbol','') for r in mw.get('data',[])))
        syms = [s for s in syms if s and s not in skip]
    except:
        print('❌ No symbols available')
        syms = []

print(f'{len(syms)} symbols')

# ── DPS Ticks (every trade, official source) ──
all_ticks = []
for i, sym in enumerate(syms, 1):
    try:
        r = requests.get(f'{DPS}/timeseries/int/{sym}', timeout=15)
        if r.status_code == 200:
            d = r.json()
            if d.get('status') == 1 and d.get('data'):
                for row in d['data']:
                    all_ticks.append([sym, row[0], row[1], row[2]])
    except: pass
    if i % 50 == 0: print(f'  DPS ticks [{i}/{len(syms)}] {len(all_ticks):,}')
    time.sleep(0.3)

if all_ticks:
    fp = OUT / f'dps_ticks_{DATE}.csv'
    with open(fp, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['symbol','timestamp','price','volume'])
        for row in sorted(all_ticks, key=lambda x: (x[0], x[1])):
            w.writerow(row)
    print(f'✅ dps_ticks_{DATE}.csv: {len(all_ticks):,} ticks')

# ── PSX Terminal 1m klines (supplementary) ──
start_ts = int(datetime.now(PKT).replace(hour=9, minute=15, second=0, microsecond=0).timestamp() * 1000)
all_1m = []
for i, sym in enumerate(syms, 1):
    ts = start_ts
    while True:
        try:
            r = requests.get(f'{PSXT}/klines/{sym}/1m?limit=100&startTimestamp={ts}', timeout=10)
            if r.status_code != 200: break
            text = r.text.split('<')[0]
            d = json.loads(text)
            if not d.get('success') or not d.get('data'): break
            all_1m.extend(d['data'])
            if len(d['data']) < 100: break
            ts = max(b['timestamp'] for b in d['data']) + 1
            time.sleep(0.2)
        except: break
    if i % 50 == 0: print(f'  PSXT 1m [{i}/{len(syms)}] {len(all_1m):,}')
    time.sleep(0.2)

if all_1m:
    fp = OUT / f'psxt_{DATE}_1m.csv'
    with open(fp, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['symbol','timestamp','datetime','open','high','low','close','volume'])
        for b in sorted(all_1m, key=lambda x: (x['symbol'], x['timestamp'])):
            dt = datetime.fromtimestamp(b['timestamp']/1000, PKT).strftime('%Y-%m-%d %H:%M:%S')
            w.writerow([b['symbol'], b['timestamp'], dt, b['open'], b['high'], b['low'], b['close'], b['volume']])
    print(f'✅ psxt_{DATE}_1m.csv: {len(all_1m):,} bars')

print(f'📊 Total: {len(all_ticks):,} ticks + {len(all_1m):,} bars')
" >> "$LOG" 2>&1

log ""
log "✅ All done for $DATE"
log "═══════════════════════════════════════════════"
```

Make it executable:
```bash
chmod +x ~/pakfindata/services/psx_collector_service.sh
```

### Step 2: Find the correct Python path

```bash
# Find which python has the pakfindata project
which python3
# Or if using conda/venv:
conda activate psx_env && which python
# Or:
ls ~/pakfindata/.venv/bin/python 2>/dev/null
```

Update the PYTHON variable in the script with the correct path.

### Step 3: Create systemd service + timer

```bash
# Create service file
mkdir -p ~/.config/systemd/user/

cat > ~/.config/systemd/user/psx-collector.service << 'EOF'
[Unit]
Description=PSX Market Data Collector
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=%h/pakfindata/services/psx_collector_service.sh
WorkingDirectory=%h/pakfindata
Environment=HOME=%h
Environment=PATH=%h/.local/bin:/usr/local/bin:/usr/bin:/bin
StandardOutput=append:%h/psxdata/logs/systemd.log
StandardError=append:%h/psxdata/logs/systemd_error.log
Restart=no
TimeoutStopSec=60

[Install]
WantedBy=default.target
EOF

# Create timer — fires at 9:10 AM PKT (4:10 AM UTC) Mon-Fri
cat > ~/.config/systemd/user/psx-collector.timer << 'EOF'
[Unit]
Description=PSX Market Data Collector Timer

[Timer]
OnCalendar=Mon..Fri *-*-* 04:10:00 UTC
Persistent=true
RandomizedDelaySec=30

[Install]
WantedBy=timers.target
EOF
```

### Step 4: Enable the service

```bash
# Reload systemd
systemctl --user daemon-reload

# Enable timer (auto-starts on boot)
systemctl --user enable psx-collector.timer

# Start timer now
systemctl --user start psx-collector.timer

# Verify
systemctl --user status psx-collector.timer
systemctl --user list-timers

# To test manually (run now without waiting for timer):
systemctl --user start psx-collector.service
```

### Step 5: Handle WSL2 boot — systemd may need lingering

WSL2 doesn't run systemd by default in older versions. Check:

```bash
# Check if systemd is PID 1
ps -p 1 -o comm=
```

If it says `init` (not `systemd`), systemd timers won't work. 
Use **cron** instead:

```bash
# ALTERNATIVE: Use cron if systemd not available in WSL2
crontab -e

# Add this line (9:10 AM PKT = 4:10 AM UTC):
10 4 * * 1-5 /bin/bash $HOME/pakfindata/services/psx_collector_service.sh >> $HOME/psxdata/logs/cron.log 2>&1
```

Also ensure WSL2 stays running. Create a Windows Task Scheduler task 
that starts WSL before market open:

**Windows Task Scheduler (run in PowerShell as admin):**
```powershell
# Create task to start WSL at 4:00 AM UTC (9:00 AM PKT) Mon-Fri
$action = New-ScheduledTaskAction -Execute "wsl.exe" -Argument "-d Ubuntu -u adnoman -- sleep 28800"
$trigger = New-ScheduledTaskTrigger -Weekly -DaysOfWeek Monday,Tuesday,Wednesday,Thursday,Friday -At "4:00AM"
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -WakeToRun
Register-ScheduledTask -TaskName "WSL_PSX_Collector" -Action $action -Trigger $trigger -Settings $settings -Description "Start WSL for PSX market data collection"
```

The `-WakeToRun` flag wakes the laptop from sleep to run the collection!

### Step 6: Create a status check script

Create `~/pakfindata/services/psx_status.sh`:

```bash
#!/bin/bash
# Quick status check for PSX collection
echo "═══════════════════════════════════════════════"
echo "  PSX COLLECTOR STATUS"
echo "═══════════════════════════════════════════════"

DATE=$(TZ="Asia/Karachi" date +%Y-%m-%d)
TIME=$(TZ="Asia/Karachi" date +%H:%M:%S)
echo "Date: $DATE  Time: $TIME PKT"
echo ""

# Check if tick_service is running
echo "=== PROCESSES ==="
if pgrep -f "tick_service" > /dev/null; then
    PID=$(pgrep -f "tick_service" | head -1)
    echo "  ✅ tick_service.py running (PID: $PID)"
    # Show RAM usage
    RSS=$(ps -o rss= -p $PID 2>/dev/null | tr -d ' ')
    echo "     RAM: $((RSS / 1024)) MB"
else
    echo "  ❌ tick_service.py NOT running"
fi

# Check WS relay
if curl -s http://localhost:8765/health > /dev/null 2>&1; then
    HEALTH=$(curl -s http://localhost:8765/health)
    echo "  ✅ WS Relay on port 8765"
    echo "     $HEALTH" | python3 -m json.tool 2>/dev/null | head -5
else
    echo "  ❌ WS Relay not responding"
fi

echo ""
echo "=== TODAY'S DATA ==="

# Snapshot
SNAP="/mnt/e/psxdata/live_snapshot.json"
if [ -f "$SNAP" ]; then
    AGE=$(($(date +%s) - $(stat -c %Y "$SNAP")))
    SIZE=$(stat -c %s "$SNAP")
    echo "  Snapshot: ${SIZE} bytes, ${AGE}s old"
else
    echo "  Snapshot: NOT FOUND"
fi

# tick_bars.db
DB="/mnt/e/psxdata/tick_bars.db"
if [ -f "$DB" ]; then
    SIZE=$(stat -c %s "$DB")
    echo "  tick_bars.db: $((SIZE / 1024 / 1024)) MB"
fi

# Today's intraday files
echo ""
echo "=== INTRADAY FILES (today) ==="
ls -la ~/psxdata/intraday/*${DATE}* 2>/dev/null || echo "  No files yet for $DATE"

echo ""
echo "=== LOGS ==="
LOG="$HOME/psxdata/logs/collector_${DATE}.log"
if [ -f "$LOG" ]; then
    echo "  Last 5 lines of today's log:"
    tail -5 "$LOG" | sed 's/^/  /'
else
    echo "  No log for today"
fi

echo ""
echo "=== TIMER STATUS ==="
if systemctl --user is-active psx-collector.timer > /dev/null 2>&1; then
    systemctl --user status psx-collector.timer --no-pager | head -5
else
    echo "  Timer not active (using cron?)"
    crontab -l 2>/dev/null | grep -i psx || echo "  No cron entry found"
fi
```

```bash
chmod +x ~/pakfindata/services/psx_status.sh
```

### Step 7: Prevent laptop sleep during market hours

Create a Windows scheduled task that prevents sleep 9:00-16:00 PKT:

Save as `C:\Scripts\prevent_sleep.ps1`:
```powershell
# Prevent sleep during PSX market hours
$hour = (Get-Date).ToUniversalTime().Hour + 5  # PKT offset
if ($hour -ge 9 -and $hour -le 16) {
    # Prevent sleep by calling SetThreadExecutionState
    Add-Type -TypeDefinition @"
    using System;
    using System.Runtime.InteropServices;
    public class SleepPreventer {
        [DllImport("kernel32.dll")]
        public static extern uint SetThreadExecutionState(uint esFlags);
        public const uint ES_CONTINUOUS = 0x80000000;
        public const uint ES_SYSTEM_REQUIRED = 0x00000001;
        public const uint ES_DISPLAY_REQUIRED = 0x00000002;
    }
"@
    [SleepPreventer]::SetThreadExecutionState(
        [SleepPreventer]::ES_CONTINUOUS -bor 
        [SleepPreventer]::ES_SYSTEM_REQUIRED -bor 
        [SleepPreventer]::ES_DISPLAY_REQUIRED
    )
    Write-Host "Sleep prevented for PSX market hours"
    Start-Sleep -Seconds 3600  # Re-run every hour
} else {
    # Allow sleep outside market hours
    Add-Type -TypeDefinition @"
    using System;
    using System.Runtime.InteropServices;
    public class SleepAllower {
        [DllImport("kernel32.dll")]
        public static extern uint SetThreadExecutionState(uint esFlags);
        public const uint ES_CONTINUOUS = 0x80000000;
    }
"@
    [SleepAllower]::SetThreadExecutionState([SleepAllower]::ES_CONTINUOUS)
}
```

Add to Windows Task Scheduler: Run every hour, all day.

## VERIFY

```bash
# Check service script exists and is executable
ls -la ~/pakfindata/services/psx_collector_service.sh
ls -la ~/pakfindata/services/psx_status.sh

# Check timer/cron
systemctl --user list-timers 2>/dev/null || crontab -l | grep psx

# Run status check
bash ~/pakfindata/services/psx_status.sh

# Test the collector manually (will start tick_service)
bash ~/pakfindata/services/psx_collector_service.sh

# Check logs
ls -la ~/psxdata/logs/
tail -20 ~/psxdata/logs/collector_$(TZ="Asia/Karachi" date +%Y-%m-%d).log
```

## What happens each trading day (fully automatic):

```
04:00 UTC (09:00 PKT) — Windows wakes laptop from sleep
04:10 UTC (09:10 PKT) — WSL starts, cron/timer fires
  ├── tick_service.py starts
  ├── WebSocket connects to psxterminal.com
  ├── WS relay starts on port 8765
  ├── Ticks flow into RAM
  ├── Snapshot written every 2s
  ├── Checkpoint to DB every 30 min
  │
  ├── 09:15 PKT — Market opens, ticks start flowing
  ├── 09:45 PKT — First checkpoint (~30 min of data saved)
  ├── 10:15, 10:45, ... — Checkpoints continue
  ├── ...
  ├── 15:30 PKT — Market closes
  ├── 15:35 PKT — EOD flush → tick_bars.db
  │
10:40 UTC (15:40 PKT) — Post-market backups start
  ├── DPS intraday ticks → dps_ticks_2026-03-17.csv
  ├── PSX Terminal 1m → psxt_2026-03-17_1m.csv
  │
10:45 UTC (15:45 PKT) — tick_service stopped
11:00 UTC (16:00 PKT) — Windows allowed to sleep again

Next day: repeat automatically
```

**You never touch anything. It just runs.**
