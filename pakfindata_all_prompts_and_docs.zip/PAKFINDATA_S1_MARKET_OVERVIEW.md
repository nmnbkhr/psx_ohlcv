# pakfindata — Section 1: Market Overview

## The Command Center

The Market Overview section is where every user starts their day. Three pages provide a complete top-down view of the Pakistan Stock Exchange — from headline index to individual sector performance to multi-index comparison — in under 30 seconds.

---

## Page 1: Market Dashboard

### What You See

The dashboard is the home screen — a single-pane view of the entire market:

**Index Header:** KSE-100 at 153,966.36 with daily change (+1,225.99, +0.80%). High, Low, Volume (220M), and YTD performance. Market status indicator (OPEN/CLOSED) with timestamp.

**Macro Ticker Bar:** SBP rate (10.5%), KIBOR 3M (11.21%), T-Bill 3M (11.50%), PKRV 10Y (11.24%), USD (279.36), EUR (333.66), GBP (381.86) — all in one scrollable row.

**Data Freshness Badges:** Color-coded pills showing when each data source was last updated: Equity EOD (1.0d), Intraday Ticks (1.0d), PSX Indices (1.0d), Mutual Funds (0.0d), Treasury Auctions (9.0d), PIB Auctions (9.0d), KIBOR Rates (0.0d), FX Interbank (1.0d), Yield Curves (0.0d), ETFs (0.0d), Commodities, Company Profiles (36.0d). Green = fresh, yellow = aging, red = stale.

**Market Breadth:** Donut chart showing 201 gainers (green), 318 losers (red), 79 unchanged (gray). Net: Bullish +117. At a glance: is the market broad-based or narrow?

**Top Gainers:** Horizontal bar chart — HINOON (+37.3%), SCL (+46.2%), SAZEWXD (+62.7%), BTL (+76.4%), UPFL (300%+ — right issue). Visual impact shows magnitude.

**Top Losers:** PRET (-34.6%), FASM (-38.5%), SAZEM (-55.2%), THALLXD (-69.3%), NESTLE (-135%). Extreme movers immediately visible.

**Volume Leaders:** KEL (35.8M, +0.26%), UNITY (31.6M, -2.44%), BOP (24.5M, +0.50%), CNERGY (12.9M, +1.60%), FCCL (10.9M, -2.05%). Where the money is flowing.

**52-Week Range:** Stocks near 52-week highs (AASM 100%, BTL 100%, DKTM 100%) and 52-week lows (BNL 0%, BLUEX 2%, BIFO 6%). Breakout candidates and distressed names.

**Sector Performance:** Table of top sectors by average change — TOBACCO (+11.54%, 2 stocks, led by PAKT), PHARMACEUTICALS (+8.31%, 14 stocks, led by HINOON), LEATHER (+6.45%), FOOD & PERSONAL CARE (+5.05%), FERTILIZER (+3.43%), TRANSPORT (+1.73%).

### Business Value

A portfolio manager walks in at 9:30 AM. In 10 seconds they know: the market is up 0.80%, breadth is positive (201 vs 140), pharma and tobacco are leading, KEL has 35M volume, SBP rate unchanged, KIBOR slightly up, PKR stable at 279. No Bloomberg needed.

A fund distributor pitching to a client checks freshness badges — all data is same-day. Credibility established instantly.

### Target Audience

Everyone. This is the universal landing page — fund managers, brokers, retail investors, treasury desks, research analysts. Every user type gets actionable information within seconds.

### Comparable Products

Bloomberg TOP<GO>, Reuters Market Overview, PSX DPS homepage (much less data). pakfindata combines what takes 3-4 Bloomberg screens into one.

---

## Page 2: Market Pulse

### What You See

End-of-day market report in table format — the raw data behind the Dashboard's visual summary.

**Header Bar:** 277 Adv / 140 Dec / 67 Unch. Volume: 375M. Value: Rs.22.83B. Market average return: +1.09%.

**Breadth Donut:** 277/140 ratio with visual breakdown. Return Distribution histogram showing most stocks moved +0-10% with a long right tail (a few extreme gainers).

**Top Gainers Table (9 rows):** MFFLR1 (+99.01%, 1,114 vol), CTM (+18.52%, 1.1M), FANM (+16.64%, 766K), AGSML (+13.26%, 850K), ITANZ (+10.02%), JATM (+10.02%), 786 (+10.00%), BAPL (+10.00%), RTI (+10.00%). Note: several at exactly +10% — circuit breaker hits.

**Top Losers Table (9 rows):** SHDTR1 (-18.98%, 823K), CRTM (-10.00%), MQTM (-9.92%), DADX (-9.91%), TCORPCPS (-9.90%), FASM (-9.28%), ASLCPS (-9.04%), STML (-8.77%), KCI (-8.75%). Again, several at -10% circuit breakers.

**Volume Leaders:** KEL (35.8M), UNITY (31.6M), BOP (24.5M), CNERGY (12.9M), FCCL (10.9M), NCPL (10.1M), PIBTL (9.3M), WTL (9.1M), HASCOL (9.0M).

**Value Leaders (Turnover):** LUCK (Rs.1.58B, +2.92%), OGDC (Rs.1.46B, -0.04%), ENGROH (Rs.1.44B, +6.52%), PPL (Rs.1.23B, +0.43%), NBP (Rs.1.19B, -1.63%), FFC (Rs.1.19B, +1.68%), HUBC (Rs.1.01B, +1.32%), DGKC (Rs.666M, +2.91%).

### Business Value

This is the "daily market report" page. A research analyst writing the morning note copies these tables directly. An AML officer checks if unusual volume spikes coincide with insider activity. A broker explains the day to clients using concrete numbers.

**Time saved:** What takes 30 minutes manually (collecting data from PSX website, formatting tables) is done in 0 seconds — the page auto-generates on load.

### Target Audience

Research analysts writing daily reports, brokers preparing client communications, compliance officers monitoring for unusual activity, financial journalists covering PSX.

### Comparable Products

Bloomberg MOV<GO>, broker morning notes (this automates the creation of those notes).

---

## Page 3: Index Analytics (Index Monitor)

### What You See

**All Indices Performance Table:** 18 PSX indices in one view:

| Index | Last | 1D | 1W | 1M | 3M | Vol 30D |
|-------|------|----|----|----|----|---------| 
| ACI (Alfalah Consumer) | 20,440 | +4.13% | +6.75% | -14.11% | -18.19% | +61.64% |
| ALLSHR (All Share) | 94,665 | +2.55% | +5.47% | -8.93% | -8.38% | +52.21% |
| BKTI (Banking) | 43,251 | +3.03% | +2.19% | -15.29% | -8.30% | +57.17% |
| HBLTTI (Treasury) | 18,132 | +0.03% | +0.16% | +0.56% | +2.06% | +1.00% |
| KMI30 (Islamic) | 229,679 | +3.32% | +7.62% | -5.45% | -6.15% | +61.46% |
| KSE100 | 158,313 | +2.82% | +6.12% | -8.58% | -7.53% | +57.06% |

**Key insight visible:** Banking index (-15.29% 1M) underperforming vs KMI30 (-5.45% 1M) — capital rotating out of banks into Islamic/consumer names. HBL Treasury index (+0.56% 1M) is the only positive — flight to safety.

**Market Summary Cards:** 0 gainers, 0 losers (indices, not stocks), Avg 1M return: -7.86%, Total: 18 indices.

**Index Detail Selector:** Pick any index (e.g., KSE-100) + time range (90 days) → historical price chart with performance metrics.

### Business Value

Fund managers running index funds need this daily. "Is my KMI-30 fund tracking correctly?" — compare the index performance against fund NAV.

Sector rotation traders: "Banking is down 15% in a month but volume up 57% — accumulation phase or further selling?" This page gives the cross-sector momentum comparison no other Pakistani terminal provides.

Macro strategists: "PKRV 10Y yield index (HBLTTI) only up 1% while equities swing ±8% — bonds disconnected from equities." Multi-asset allocation signals.

### Target Audience

Index fund managers, sector rotation strategists, macro analysts, ETF issuers, passive investment trackers, regulatory bodies (SECP) monitoring market health.

### Comparable Products

Bloomberg WEIX<GO> (World Equity Index Monitor). PSX website shows index values but not multi-period comparison or relative performance in one view.

---

## Section Summary: Market Overview

| Page | Primary Use | Time Saved | Key Differentiator |
|------|------------|------------|-------------------|
| Dashboard | Morning market snapshot | 15-20 min/day | Everything on one screen — index, breadth, sectors, rates, FX |
| Market Pulse | Daily report generation | 30+ min/day | Auto-generated tables, circuit breaker detection |
| Index Monitor | Cross-index comparison | 10-15 min/day | 18 indices × 5 time periods in one view |

**Total daily time saved for a research analyst: ~60 minutes.**
**Monthly value (at PKR 5,000/hour analyst cost): PKR 1.2M/month for a 20-person team.**

---

*Section 2: Equities — coming next.*
