# Claude Code Prompt: pakfindata-demo Git Repo Setup

## Context

The demo has been built at ~/pakfindata-demo/. Now create a separate Git repo 
for it — completely independent from the main ~/pakfindata/ repo.

## Step 1: Initialize Git repo

```bash
cd ~/pakfindata-demo

# Initialize
git init
git branch -M main

# Create .gitignore
cat > .gitignore << 'EOF'
# Python
__pycache__/
*.pyc
*.pyo
*.egg-info/
dist/
build/
.eggs/
*.egg

# Virtual environments
.venv/
venv/
env/

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Demo data (large files — download separately)
data/psx.sqlite
data/tick_bars.db
data/pakfindata.duckdb
data/tick_logs_cloud/*.jsonl
data/intraday/*.csv
data/intraday/*.json
data/downloads/daily/
data/sbp_easydata/series/

# Keep directory structure
!data/.gitkeep
!data/tick_logs_cloud/.gitkeep
!data/intraday/.gitkeep
!data/downloads/.gitkeep
!data/downloads/reference/
!data/sbp_easydata/.gitkeep
!data/sbp_easydata/catalog.json

# Logs
*.log
*.jsonl

# Docker volumes
docker-data/

# Environment
.env
.env.local
EOF

# Create .gitkeep files for empty dirs
mkdir -p data/tick_logs_cloud data/intraday data/downloads/reference data/sbp_easydata/series
touch data/.gitkeep
touch data/tick_logs_cloud/.gitkeep
touch data/intraday/.gitkeep
touch data/downloads/.gitkeep
touch data/sbp_easydata/.gitkeep
```

## Step 2: Create setup script for demo data

Since DB files are too large for Git, create a setup script:

```bash
cat > scripts/setup_data.sh << 'SCRIPT'
#!/bin/bash
# ═══════════════════════════════════════
# pakfindata-demo — Data Setup
# ═══════════════════════════════════════
#
# Run this ONCE after cloning to generate demo data
# from the production pakfindata databases.
#
# Prerequisites:
#   - Production DBs at /mnt/e/psxdata/ (or set PSX_PROD_DATA env var)
#   - Python 3.11+ with duckdb, pandas, openpyxl
#
# Usage:
#   bash scripts/setup_data.sh
# ═══════════════════════════════════════

set -e

PROD_DATA="${PSX_PROD_DATA:-/mnt/e/psxdata}"
DEMO_DIR="$(cd "$(dirname "$0")/.." && pwd)/data"

echo "═══════════════════════════════════════"
echo "  pakfindata-demo — Data Setup"
echo "═══════════════════════════════════════"
echo "  Production data: $PROD_DATA"
echo "  Demo output:     $DEMO_DIR"
echo ""

if [ ! -f "$PROD_DATA/psx.sqlite" ]; then
    echo "❌ Production data not found at $PROD_DATA"
    echo "   Set PSX_PROD_DATA env var to your psxdata path"
    exit 1
fi

echo "📦 Creating trimmed demo databases..."
python scripts/create_demo_db.py

echo ""
echo "✅ Demo data ready!"
echo "   Run: docker compose up --build"
echo "   Open: http://localhost:8501"
SCRIPT
chmod +x scripts/setup_data.sh
```

## Step 3: Create CONTRIBUTING.md

```bash
cat > CONTRIBUTING.md << 'EOF'
# Contributing to pakfindata-demo

## Project Structure

```
pakfindata-demo/
├── Dockerfile              # Docker build
├── docker-compose.yml      # One-command run
├── requirements.txt        # Python deps
├── README.md               # User guide
├── CONTRIBUTING.md          # This file
├── .gitignore
├── scripts/
│   ├── create_demo_db.py   # Trims production DBs to demo size
│   ├── patch_paths.py      # Replaces hardcoded paths with config
│   ├── add_demo_tooltips.py
│   ├── gate_live_features.py
│   └── setup_data.sh       # One-command data setup
├── src/pakfindata/
│   ├── config.py            # Centralized path config (env vars)
│   ├── demo.py              # Demo mode helpers (badges, tooltips)
│   ├── ui/                  # Streamlit pages
│   ├── db/                  # Database connections (DuckDB + SQLite)
│   ├── engine/              # Analytics engines
│   └── sources/             # Data scrapers (disabled in demo)
└── data/                    # Demo data (not in Git — generate locally)
    ├── psx.sqlite
    ├── tick_bars.db
    ├── pakfindata.duckdb
    ├── tick_logs_cloud/
    └── ...
```

## Setup for Development

```bash
# Clone
git clone https://github.com/godaitec/pakfindata-demo.git
cd pakfindata-demo

# Generate demo data (requires production DBs)
bash scripts/setup_data.sh

# Run with Docker
docker compose up --build

# Or run locally
pip install -r requirements.txt
DEMO_MODE=1 PSX_DATA_ROOT=./data streamlit run src/pakfindata/ui/app.py
```

## Updating from Production

When the main pakfindata codebase changes:

```bash
# 1. Copy updated source
cp -r ~/pakfindata/src/pakfindata/* src/pakfindata/

# 2. Re-patch paths
python scripts/patch_paths.py

# 3. Re-add tooltips
python scripts/add_demo_tooltips.py

# 4. Re-gate live features
python scripts/gate_live_features.py

# 5. Rebuild
docker compose build
```

## LLM Integration

AI commentary supports OpenAI or Anthropic. Set in docker-compose.yml:

```yaml
environment:
  - LLM_PROVIDER=openai
  - LLM_API_KEY=sk-your-key
  - LLM_MODEL=gpt-4o-mini
```

Without an API key, AI features show placeholder text — all other features work.

## Data Notes

- Demo data is trimmed to top 50 symbols by volume
- 30 days of daily history
- 3 days of tick-level JSONL
- All live scraping/sync disabled
- Read-only mode — no writes to DBs
EOF
```

## Step 4: Create LICENSE

```bash
cat > LICENSE << 'EOF'
MIT License

Copyright (c) 2026 Godaitec (godai.tech)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
EOF
```

## Step 5: Initial commit

```bash
cd ~/pakfindata-demo

# Stage everything
git add -A

# Verify what's being committed (should NOT include large data files)
git status

# Check no large files
find . -name "*.sqlite" -o -name "*.db" -o -name "*.duckdb" -o -name "*.jsonl" | \
    xargs ls -lh 2>/dev/null

# If any large files show up in git status, add them to .gitignore

# Commit
git commit -m "Initial commit: pakfindata demo — PSX analytics terminal

- Bloomberg Terminal-style Streamlit app for Pakistan Stock Exchange
- Docker one-command deployment
- Top 50 symbols, 30 days history
- Features: tick replay (60fps), microstructure, derivatives, signals
- DuckDB + SQLite hybrid (104x speedup)
- Optional AI commentary (OpenAI/Anthropic)
- Demo mode with guided tooltips

Built by Godaitec (godai.tech)"
```

## Step 6: Create GitHub repo and push

```bash
# Option A: Using GitHub CLI (if installed)
gh repo create godaitec/pakfindata-demo --public --description "Bloomberg Terminal-style PSX analytics — Docker demo" --push

# Option B: Manual
# 1. Go to https://github.com/new
# 2. Create repo: godaitec/pakfindata-demo (public)
# 3. Then:
git remote add origin git@github.com:godaitec/pakfindata-demo.git
git push -u origin main
```

## Step 7: Add GitHub repo description and topics

After pushing, set these on GitHub:

**Description:** Bloomberg Terminal-style Pakistan Stock Exchange analytics terminal — Docker demo

**Topics:** `pakistan` `stock-exchange` `psx` `streamlit` `duckdb` `trading` `analytics` `fintech` `bloomberg-terminal` `tick-data`

**Website:** https://godai.tech

## Step 8: Create release with demo data

Since data files can't go in Git, create a release with data as an attachment:

```bash
# Create a compressed data archive
cd ~/pakfindata-demo
tar -czf pakfindata-demo-data.tar.gz data/

# Check size
ls -lh pakfindata-demo-data.tar.gz
```

Then on GitHub:
1. Go to Releases → Create New Release
2. Tag: `v1.0.0`
3. Title: `pakfindata Demo v1.0.0`
4. Description:
```markdown
## pakfindata Demo — PSX Analytics Terminal

### Quick Start
```bash
git clone https://github.com/godaitec/pakfindata-demo.git
cd pakfindata-demo

# Download demo data (attached below)
tar -xzf pakfindata-demo-data.tar.gz

# Run
docker compose up --build
# → http://localhost:8501
```

### What's Included
- 12 analytics pages (microstructure, derivatives, tick replay, signals, etc.)
- Top 50 PSX symbols, 30 days history
- 3 days tick-level data (bid/ask, every trade)
- SBP macro data (KIBOR, CPI, exchange rates)
- Optional AI commentary (bring your own API key)

### Requirements
- Docker & Docker Compose
- ~500MB disk space
```

5. Attach: `pakfindata-demo-data.tar.gz`
6. Publish

## Step 9: Update README with clone instructions

Update the README.md to include the complete setup flow:

```bash
cat >> README.md << 'EOF'

## Installation

### Option 1: Docker (Recommended)

```bash
# Clone
git clone https://github.com/godaitec/pakfindata-demo.git
cd pakfindata-demo

# Download demo data from latest release
# https://github.com/godaitec/pakfindata-demo/releases/latest
# Extract pakfindata-demo-data.tar.gz into the repo root:
tar -xzf pakfindata-demo-data.tar.gz

# Run
docker compose up --build
# → http://localhost:8501
```

### Option 2: Local (without Docker)

```bash
git clone https://github.com/godaitec/pakfindata-demo.git
cd pakfindata-demo

# Install dependencies
pip install -r requirements.txt

# Download and extract demo data (same as above)

# Run
DEMO_MODE=1 PSX_DATA_ROOT=./data PYTHONPATH=./src \
    streamlit run src/pakfindata/ui/app.py
```

### Option 3: Generate data from production

If you have the full pakfindata setup with live data:

```bash
git clone https://github.com/godaitec/pakfindata-demo.git
cd pakfindata-demo

# Generate demo data from your production databases
bash scripts/setup_data.sh

# Run
docker compose up --build
```

## Screenshots

_Coming soon_

## License

MIT — See [LICENSE](LICENSE)

## Built by

[Godaitec](https://godai.tech) — Tech consulting, Karachi, Pakistan
EOF
```

## Step 10: Final commit and push

```bash
cd ~/pakfindata-demo
git add -A
git commit -m "Add setup guide, contributing docs, license, release instructions"
git push origin main
```

## IMPORTANT NOTES

1. **Separate from ~/pakfindata/** — this is a completely independent repo
2. **No data in Git** — DB/JSONL files in .gitignore, distributed via GitHub Releases
3. **Demo data ~60MB compressed** — attached to GitHub release
4. **GitHub repo is PUBLIC** — anyone can clone and run
5. **No API keys in repo** — LLM keys set via docker-compose env vars
6. **No PSX credentials** — demo uses pre-downloaded data only
7. **License: MIT** — change if you prefer proprietary
8. **Update flow:** copy from pakfindata → re-patch → rebuild → push
