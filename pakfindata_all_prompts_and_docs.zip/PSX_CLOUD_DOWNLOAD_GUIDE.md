# PSX Cloud — Download Data Guide

All commands run in **WSL2**.

---

## Download Tick Logs (Daily Use)

```bash
# All tick log JSONL files
rsync -avz psx-cloud:~/psxdata/tick_logs/ /mnt/e/psxdata/tick_logs_cloud/
```

## Download Specific Date

```bash
# Single day
scp psx-cloud:~/psxdata/tick_logs/2026-03-18.jsonl /mnt/e/psxdata/tick_logs_cloud/
```

## View Files Without Downloading

```bash
# List all files
ssh psx-cloud "ls -lh ~/psxdata/tick_logs/"

# Preview first 5 lines
ssh psx-cloud "head -5 ~/psxdata/tick_logs/2026-03-18.jsonl"

# Count ticks in a file
ssh psx-cloud "wc -l ~/psxdata/tick_logs/2026-03-18.jsonl"

# Check disk usage
ssh psx-cloud "du -sh ~/psxdata/*"
```

## Daily Sync Script

Run once to create:

```bash
cat > ~/sync_psx_cloud.sh << 'SCRIPT'
#!/bin/bash
echo "📥 Syncing PSX Cloud tick logs..."
rsync -avz --progress psx-cloud:~/psxdata/tick_logs/ /mnt/e/psxdata/tick_logs_cloud/
echo "✅ Done"
du -sh /mnt/e/psxdata/tick_logs_cloud/
SCRIPT
chmod +x ~/sync_psx_cloud.sh
```

Then anytime:

```bash
bash ~/sync_psx_cloud.sh
```

## Cleanup VM (After Downloading)

```bash
# Delete files older than 30 days
ssh psx-cloud "find ~/psxdata/tick_logs -name '*.jsonl' -mtime +30 -delete"

# Delete old logs
ssh psx-cloud "find ~/psxdata/logs -name '*.log' -mtime +30 -delete"

# Check disk
ssh psx-cloud "du -sh ~/psxdata/* && df -h /"
```
