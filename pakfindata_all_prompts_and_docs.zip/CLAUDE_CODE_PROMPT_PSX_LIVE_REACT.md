# Claude Code Prompt: PSX Live Terminal — React Frontend

## What this is

Build a real-time PSX trading terminal as a standalone React app. Connects to the WebSocket relay at `ws://localhost:8765` for true <1ms streaming. Dark theme, professional trading terminal aesthetic.

**This is a SEPARATE project from psx_ohlcv. It only talks to the WS relay — zero dependency on Python, Streamlit, or SQLite.**

## Rules — READ THESE FIRST

1. **Project location:** `~/projects/psx-live`
2. **Scaffold with:** `npm create vite@latest psx-live -- --template react-typescript`
3. **Stack:** Vite + React 18 + TypeScript + Tailwind CSS v3 + TradingView Lightweight Charts + Zustand (state)
4. **ZERO backend** — all data comes from `ws://localhost:8765` (WebSocket) and `http://localhost:8765` (REST)
5. **Dark theme ONLY** — trading terminal aesthetic. Dark navy/slate backgrounds, green/red for up/down
6. **Mobile responsive** — works on phone browsers too (Noman may check from mobile)
7. **Single page app** with client-side routing (react-router-dom)

## Tech Stack

```bash
npm create vite@latest psx-live -- --template react-typescript
cd psx-live
npm install
npm install -D tailwindcss @tailwindcss/vite
npm install react-router-dom zustand lightweight-charts lucide-react clsx
```

Tailwind v4 with Vite plugin (NOT PostCSS):
```ts
// vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 3000,
    proxy: {
      '/api': 'http://localhost:8765',  // proxy REST calls
    }
  }
})
```

```css
/* src/index.css */
@import "tailwindcss";
```

## Architecture

```
~/projects/psx-live/
├── src/
│   ├── main.tsx                    # Entry point
│   ├── App.tsx                     # Router + layout
│   ├── index.css                   # Tailwind import + custom trading theme
│   │
│   ├── hooks/
│   │   ├── useWebSocket.ts         # Core WS connection manager
│   │   ├── useMarketData.ts        # Subscribe to ticks channel
│   │   ├── useIndices.ts           # Subscribe to indices channel
│   │   └── useSymbol.ts            # Subscribe to single symbol
│   │
│   ├── stores/
│   │   ├── marketStore.ts          # Zustand — all symbol prices + breadth
│   │   └── indexStore.ts           # Zustand — all index values + sparklines
│   │
│   ├── pages/
│   │   ├── Dashboard.tsx           # KSE-100 hero + indices + breadth
│   │   ├── LiveMarket.tsx          # Full market table (all symbols)
│   │   ├── SymbolDetail.tsx        # Single symbol — chart + depth
│   │   └── Heatmap.tsx             # Sector heatmap
│   │
│   ├── components/
│   │   ├── Layout.tsx              # Sidebar + top bar + connection status
│   │   ├── ConnectionBadge.tsx     # 🟢 LIVE / 🔴 DISCONNECTED indicator
│   │   ├── IndexCard.tsx           # Single index metric card
│   │   ├── IndexHero.tsx           # KSE-100 large hero card
│   │   ├── BreadthBar.tsx          # Gainers/Losers visual bar
│   │   ├── PriceCell.tsx           # Animated price cell (flash green/red on change)
│   │   ├── SparklineChart.tsx      # Tiny inline sparkline
│   │   ├── CandlestickChart.tsx    # TradingView Lightweight Charts wrapper
│   │   ├── MarketTable.tsx         # Virtualized table for 500+ symbols
│   │   ├── HeatmapGrid.tsx         # Sector color blocks
│   │   ├── TopMovers.tsx           # Gainers / Losers / Most Active columns
│   │   └── SearchBar.tsx           # Symbol search with autocomplete
│   │
│   ├── lib/
│   │   ├── ws.ts                   # WebSocket singleton + reconnect logic
│   │   ├── api.ts                  # REST client (fetch from localhost:8765)
│   │   └── format.ts              # Number formatting (PKR, %, commas)
│   │
│   └── types/
│       └── market.ts               # TypeScript interfaces for ticks, indices, etc.
│
├── index.html
├── vite.config.ts
├── tailwind.config.ts              # NOT needed with Tailwind v4 Vite plugin
├── tsconfig.json
└── package.json
```

---

## Types — `src/types/market.ts`

```typescript
export interface Tick {
  symbol: string;
  market: string;       // REG, FUT, ODL, BNB, IDX
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  high: number;
  low: number;
  bid?: number;
  ask?: number;
  bidVol?: number;
  askVol?: number;
  trades?: number;
  timestamp: number;
}

export interface IndexTick {
  symbol: string;
  value: number;
  change: number;
  changePercent: number;
  volume: number;
  turnover: number;
  high: number;
  low: number;
  open: number;
  previousClose: number;
  timestamp: number;
}

export interface WSMessage {
  type: "tick" | "snapshot";
  data: Tick | IndexTick;
}

export interface MarketBreadth {
  gainers: number;
  losers: number;
  unchanged: number;
}

export interface Snapshot {
  connected: boolean;
  tick_count: number;
  symbol_count: number;
  index_count: number;
  ws_clients: number;
  symbols: Tick[];
  indices: IndexTick[];
}

// Sector mapping for heatmap
export interface SectorData {
  name: string;
  symbols: string[];
  avgChange: number;
  totalVolume: number;
  marketCap: number;
}
```

---

## Core: WebSocket Manager — `src/lib/ws.ts`

```typescript
type MessageHandler = (data: WSMessage) => void;

class WSManager {
  private ws: WebSocket | null = null;
  private url: string;
  private handlers = new Map<string, Set<MessageHandler>>();
  private reconnectDelay = 2000;
  private maxReconnectDelay = 30000;
  private currentDelay = 2000;
  private _connected = false;
  private _listeners = new Set<(connected: boolean) => void>();

  constructor(baseUrl: string = "ws://localhost:8765") {
    this.url = baseUrl;
  }

  get connected() { return this._connected; }

  onConnectionChange(fn: (connected: boolean) => void) {
    this._listeners.add(fn);
    return () => this._listeners.delete(fn);
  }

  private _setConnected(val: boolean) {
    this._connected = val;
    this._listeners.forEach(fn => fn(val));
  }

  connect(channel: string): () => void {
    const fullUrl = `${this.url}${channel}`;
    
    // If already connected to this channel, just add handler
    // For simplicity, one WS per channel
    const ws = new WebSocket(fullUrl);
    
    ws.onopen = () => {
      this.currentDelay = this.reconnectDelay;
      this._setConnected(true);
      console.log(`[WS] Connected: ${channel}`);
    };

    ws.onmessage = (event) => {
      try {
        const msg: WSMessage = JSON.parse(event.data);
        const handlers = this.handlers.get(channel);
        if (handlers) {
          handlers.forEach(h => h(msg));
        }
      } catch (e) {
        console.error("[WS] Parse error:", e);
      }
    };

    ws.onclose = () => {
      this._setConnected(false);
      console.log(`[WS] Disconnected: ${channel}. Reconnecting in ${this.currentDelay}ms`);
      setTimeout(() => this.connect(channel), this.currentDelay);
      this.currentDelay = Math.min(this.currentDelay * 1.5, this.maxReconnectDelay);
    };

    ws.onerror = (err) => {
      console.error("[WS] Error:", err);
      ws.close();
    };

    this.ws = ws;

    // Return cleanup function
    return () => {
      ws.close();
      this.handlers.delete(channel);
    };
  }

  subscribe(channel: string, handler: MessageHandler): () => void {
    if (!this.handlers.has(channel)) {
      this.handlers.set(channel, new Set());
    }
    this.handlers.get(channel)!.add(handler);
    return () => this.handlers.get(channel)?.delete(handler);
  }
}

export const wsManager = new WSManager();
export default wsManager;
```

---

## Zustand Stores

### `src/stores/marketStore.ts`

```typescript
import { create } from 'zustand';
import { Tick, MarketBreadth } from '../types/market';

interface MarketState {
  symbols: Map<string, Tick>;           // "HUBC" → latest tick
  breadth: MarketBreadth;
  topGainers: Tick[];                   // top 10
  topLosers: Tick[];                    // top 10
  mostActive: Tick[];                   // top 10 by volume
  tickCount: number;
  lastUpdate: number;
  
  // Actions
  updateTick: (tick: Tick) => void;
  loadSnapshot: (symbols: Tick[]) => void;
}

export const useMarketStore = create<MarketState>((set, get) => ({
  symbols: new Map(),
  breadth: { gainers: 0, losers: 0, unchanged: 0 },
  topGainers: [],
  topLosers: [],
  mostActive: [],
  tickCount: 0,
  lastUpdate: 0,

  updateTick: (tick) => {
    set((state) => {
      const symbols = new Map(state.symbols);
      symbols.set(tick.symbol, tick);
      
      // Recalculate breadth + top movers every 50 ticks (not every tick — too expensive)
      const newCount = state.tickCount + 1;
      if (newCount % 50 === 0) {
        const all = Array.from(symbols.values()).filter(t => t.market !== "IDX");
        const breadth = {
          gainers: all.filter(t => t.changePercent > 0).length,
          losers: all.filter(t => t.changePercent < 0).length,
          unchanged: all.filter(t => t.changePercent === 0).length,
        };
        const sorted = [...all].sort((a, b) => b.changePercent - a.changePercent);
        const byVol = [...all].sort((a, b) => b.volume - a.volume);
        
        return {
          symbols,
          breadth,
          topGainers: sorted.slice(0, 10),
          topLosers: sorted.slice(-10).reverse(),
          mostActive: byVol.slice(0, 10),
          tickCount: newCount,
          lastUpdate: Date.now(),
        };
      }
      
      return { symbols, tickCount: newCount, lastUpdate: Date.now() };
    });
  },

  loadSnapshot: (ticks) => {
    const symbols = new Map<string, Tick>();
    ticks.forEach(t => symbols.set(t.symbol, t));
    const all = ticks.filter(t => t.market !== "IDX");
    const sorted = [...all].sort((a, b) => b.changePercent - a.changePercent);
    const byVol = [...all].sort((a, b) => b.volume - a.volume);
    
    set({
      symbols,
      breadth: {
        gainers: all.filter(t => t.changePercent > 0).length,
        losers: all.filter(t => t.changePercent < 0).length,
        unchanged: all.filter(t => t.changePercent === 0).length,
      },
      topGainers: sorted.slice(0, 10),
      topLosers: sorted.slice(-10).reverse(),
      mostActive: byVol.slice(0, 10),
      tickCount: ticks.length,
      lastUpdate: Date.now(),
    });
  },
}));
```

### `src/stores/indexStore.ts`

```typescript
import { create } from 'zustand';
import { IndexTick } from '../types/market';

interface IndexState {
  indices: Map<string, IndexTick>;       // "KSE100" → latest
  sparklines: Map<string, number[]>;     // "KSE100" → [185100, 185400, ...]
  lastUpdate: number;
  
  updateIndex: (tick: IndexTick) => void;
  loadIndices: (indices: IndexTick[]) => void;
}

export const useIndexStore = create<IndexState>((set) => ({
  indices: new Map(),
  sparklines: new Map(),
  lastUpdate: 0,

  updateIndex: (tick) => {
    set((state) => {
      const indices = new Map(state.indices);
      indices.set(tick.symbol, tick);
      
      // Append to sparkline (keep last 60 points)
      const sparklines = new Map(state.sparklines);
      const existing = sparklines.get(tick.symbol) || [];
      sparklines.set(tick.symbol, [...existing.slice(-59), tick.value]);
      
      return { indices, sparklines, lastUpdate: Date.now() };
    });
  },

  loadIndices: (ticks) => {
    const indices = new Map<string, IndexTick>();
    ticks.forEach(t => indices.set(t.symbol, t));
    set({ indices, lastUpdate: Date.now() });
  },
}));
```

---

## Pages

### Page 1: `src/pages/Dashboard.tsx` — KSE-100 Hero + Indices + Breadth

This is the landing page. Shows:

1. **KSE-100 Hero card** — large index value, change, change%, intraday sparkline
   - Dark navy gradient background (`#0f172a` → `#1e293b`)
   - Value in white, 48px bold
   - Change in green/red, 24px
   - Sparkline using Lightweight Charts (line series) — last 60 data points
   - Open / High / Low / Previous Close in muted text

2. **Secondary index cards row** — KSE-30, KMI-30, All Share, KMI All Shares
   - Each card: name, value, change%, small sparkline
   - Green border-left if up, red if down

3. **Market breadth bar** — horizontal stacked bar (green | gray | red)
   - Gainers count | Unchanged | Losers count
   - Animated width transitions

4. **Top Movers** — three columns side by side
   - 🚀 Top 5 Gainers (symbol, price, change%)
   - 📉 Top 5 Losers
   - 📊 Most Active (symbol, volume)
   - Each row flashes briefly when updated

5. **All 12 indices table**
   - Grouped: Equity (4), Islamic (4), Sectoral (4)
   - Columns: Name, Symbol, Value, Change, Chg%, High, Low, Volume

6. **Heatmap preview** — small version, clickable → goes to full heatmap page

### Page 2: `src/pages/LiveMarket.tsx` — Full Market Table

Full market table showing ALL symbols with real-time updates:

1. **Toolbar** — Market filter (ALL / REG / FUT / ODL / BNB), Search box, Sort controls
2. **Stats bar** — Total symbols, Tick count, Connected status
3. **Virtualized table** — MUST use virtualization for 500+ rows (use CSS grid + manual virtualization or a lightweight virtual list)
   - Columns: Symbol, Market, Price, Change, Chg%, Volume, High, Low, Bid, Ask, Trades
   - **Price flash animation** — cell background briefly flashes green on price up, red on price down, then fades
   - Sort by any column (click header)
   - Default sort: by volume descending
   - Green/red text for change columns
4. **Click any row** → navigate to `/symbol/HUBC` (SymbolDetail page)

Performance critical: With 500+ symbols updating multiple times per second, 
use React.memo aggressively. Only re-render rows whose data actually changed.
Use requestAnimationFrame for batch updates if needed.

### Page 3: `src/pages/SymbolDetail.tsx` — Single Symbol View

Route: `/symbol/:symbol` (e.g., `/symbol/HUBC`)

Subscribes to `ws://localhost:8765/ws/symbol/HUBC` for that symbol only.

1. **Header** — Symbol name, current price (large), change, change%
   - Previous close, open, day high, day low
   - Volume, trades count

2. **Candlestick chart** — TradingView Lightweight Charts
   - Build candles from incoming ticks in real-time
   - 1-minute candles by default (aggregate ticks into 1m OHLCV in the browser)
   - The chart updates live as new ticks arrive
   - Dark theme matching the app

3. **Order book / depth** (if bid/ask data available)
   - Bid side (green) | Ask side (red)
   - Show bid/ask prices and volumes
   - Simple horizontal bar visualization

4. **Tick log** — scrolling list of last 50 raw ticks
   - Timestamp, price, volume
   - New ticks appear at top, auto-scroll
   - Green/red row based on price direction

5. **Back button** → return to LiveMarket

### Page 4: `src/pages/Heatmap.tsx` — Sector Heatmap

Full-screen treemap-style heatmap showing all sectors:

1. **Fetch initial data** from REST: `GET http://localhost:8765/snapshot`
2. **Live updates** from `ws://localhost:8765/ws/ticks`

PSX sectors to map (use symbol prefix or hardcoded mapping):
- Banks, Oil & Gas, Cement, Fertilizer, Power, Technology, Textile, 
  Chemicals, Pharma, Auto, Food, Insurance, Telecom, Steel, REIT

Each sector block:
- Size proportional to total volume (or equal size if volume data sparse)
- Color intensity based on average change% of constituent stocks
  - Deep green: avg > +2%
  - Light green: 0 to +2%
  - Gray: ~0%
  - Light red: 0 to -2%
  - Deep red: avg < -2%
- Show sector name + avg change%
- Click sector → expand to show individual stocks within that sector

3. **Legend** at bottom showing color scale

---

## Key Components

### `ConnectionBadge.tsx`
```
Shows WebSocket connection status in the top bar:
- 🟢 LIVE (green dot + "LIVE" text) when connected
- 🔴 RECONNECTING... (red dot + pulsing animation) when disconnected
- Shows tick rate: "847 ticks/min"
- Shows latency estimate if possible
```

### `PriceCell.tsx`
```
A table cell that:
1. Shows current price formatted to 2 decimals
2. When price changes UP → background flashes green for 300ms then fades
3. When price changes DOWN → background flashes red for 300ms then fades
4. Uses CSS transitions, NOT re-rendering the whole table
5. Memoized — only re-renders when THIS cell's price changes
```

### `CandlestickChart.tsx`
```
Wrapper around TradingView Lightweight Charts:
- Creates chart on mount, destroys on unmount
- Dark theme: background #0f172a, text #94a3b8, grid #1e293b
- Candlestick series: up=#22c55e, down=#ef4444
- Volume histogram at bottom (separate pane)
- Accepts new candle data via props/callback
- Auto-scales Y axis
- Crosshair with price/time tooltip
```

### `MarketTable.tsx` — Virtualized
```
Must handle 500+ rows efficiently:
- Only render visible rows (virtual scrolling)
- Fixed header that doesn't scroll
- Row height: 36px
- Visible rows = Math.ceil(containerHeight / 36) + buffer
- On scroll: recalculate which rows to render
- Each row is React.memo'd — only re-renders on data change
- Sort state managed internally
```

---

## Theme / CSS

### Color palette (trading terminal dark theme)

```css
/* In src/index.css after Tailwind import */
@import "tailwindcss";

:root {
  --bg-primary: #0a0e17;        /* Deepest background */
  --bg-secondary: #0f172a;      /* Card backgrounds */
  --bg-tertiary: #1e293b;       /* Elevated surfaces */
  --bg-hover: #334155;          /* Hover state */
  --text-primary: #f1f5f9;      /* Main text */
  --text-secondary: #94a3b8;    /* Muted text */
  --text-muted: #475569;        /* Very muted */
  --green: #22c55e;             /* Price up */
  --green-bg: rgba(34,197,94,0.15);
  --red: #ef4444;               /* Price down */
  --red-bg: rgba(239,68,68,0.15);
  --blue: #3b82f6;              /* Accent / links */
  --border: #1e293b;            /* Borders */
}

body {
  background: var(--bg-primary);
  color: var(--text-primary);
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, monospace;
}

/* Price flash animations */
@keyframes flash-green {
  0% { background-color: rgba(34,197,94,0.4); }
  100% { background-color: transparent; }
}
@keyframes flash-red {
  0% { background-color: rgba(239,68,68,0.4); }
  100% { background-color: transparent; }
}
.flash-up { animation: flash-green 0.3s ease-out; }
.flash-down { animation: flash-red 0.3s ease-out; }

/* Scrollbar */
::-webkit-scrollbar { width: 6px; }
::-webkit-scrollbar-track { background: var(--bg-primary); }
::-webkit-scrollbar-thumb { background: var(--bg-tertiary); border-radius: 3px; }
```

---

## Layout — `src/components/Layout.tsx`

```
┌──────────────────────────────────────────────────────┐
│  PSX LIVE    Dashboard  Market  Heatmap    🟢 LIVE   │  ← Top bar (fixed)
├──────────────────────────────────────────────────────┤
│                                                      │
│                   Page Content                       │  ← Router outlet
│                                                      │
│                                                      │
└──────────────────────────────────────────────────────┘
```

- Top bar: Logo ("PSX LIVE"), nav links, connection badge (right side)
- No sidebar — horizontal nav to maximize screen space for data
- Sticky top bar, content scrolls underneath
- Nav items: Dashboard, Market, Heatmap
- Active nav item has blue underline

---

## Routing — `src/App.tsx`

```
/                → Dashboard (KSE-100 hero + indices)
/market          → LiveMarket (full table)
/market?filter=REG  → LiveMarket filtered
/symbol/:symbol  → SymbolDetail (chart + ticks)
/heatmap         → Heatmap
```

---

## Data Flow

```
                    ws://localhost:8765
                           │
              ┌────────────┼────────────┐
              │            │            │
         /ws/ticks    /ws/indices   /ws/symbol/X
              │            │            │
              ▼            ▼            ▼
        useMarketData  useIndices   useSymbol     ← React hooks
              │            │            │
              ▼            ▼            ▼
        marketStore    indexStore    local state   ← Zustand stores
              │            │            │
              ▼            ▼            ▼
        LiveMarket     Dashboard    SymbolDetail  ← Pages
        MarketTable    IndexHero    CandleChart
        Heatmap        IndexCards   TickLog
```

On app load:
1. Fetch `GET /snapshot` to get initial state for all symbols + indices
2. Connect to `/ws/ticks` for all stock updates (Dashboard + LiveMarket + Heatmap)
3. Connect to `/ws/indices` for index updates (Dashboard)
4. When user navigates to `/symbol/HUBC`, connect to `/ws/symbol/HUBC` (SymbolDetail)
5. Disconnect symbol-specific WS when navigating away

---

## REST API Client — `src/lib/api.ts`

```typescript
const BASE = "http://localhost:8765";

export const api = {
  snapshot: () => fetch(`${BASE}/snapshot`).then(r => r.json()),
  symbol: (sym: string) => fetch(`${BASE}/symbol/${sym}`).then(r => r.json()),
  health: () => fetch(`${BASE}/health`).then(r => r.json()),
  stats: () => fetch(`${BASE}/stats`).then(r => r.json()),
};
```

---

## Performance Requirements

1. **500+ symbols updating simultaneously** — must not lag
   - Virtual scrolling on market table (only render visible rows)
   - React.memo on every row component
   - Batch Zustand updates — don't trigger re-render on every single tick
   - Use `requestAnimationFrame` to throttle DOM updates to 60fps max
   
2. **Price flash animations via CSS only** — no React state for animations
   - Add/remove CSS class, let CSS handle the animation
   - Use `data-direction` attribute to trigger flash

3. **Chart updates** — TradingView Lightweight Charts handles its own rendering
   - Just call `candleSeries.update(candle)` — it's optimized internally

4. **Memory** — clear old data
   - Tick log: keep last 100 per symbol max
   - Sparklines: keep last 60 points
   - Don't accumulate unbounded arrays

---

## Build & Run

```bash
# Dev
cd ~/projects/psx-live
npm run dev
# Opens http://localhost:3000

# Make sure relay is running
python -m psx_ohlcv.services.tick_service
# Relay at ws://localhost:8765

# Production build
npm run build
# Output in dist/ — serve with any static server
```

---

## Implementation Order

Build in this order — each step is independently testable:

```
Step 1: Scaffold + theme + layout + routing           (works: empty pages with nav)
Step 2: WebSocket manager + connection badge           (works: shows LIVE/DISCONNECTED)
Step 3: Zustand stores + REST snapshot loader          (works: loads initial data)
Step 4: Dashboard page — KSE-100 hero + index cards    (works: shows indices)
Step 5: Dashboard — breadth bar + top movers           (works: full dashboard)
Step 6: LiveMarket — virtualized table with sort       (works: all symbols)
Step 7: LiveMarket — price flash animations            (works: cells flash on update)
Step 8: SymbolDetail — header + tick log               (works: single symbol view)
Step 9: SymbolDetail — candlestick chart               (works: live candles)
Step 10: Heatmap page                                  (works: sector color blocks)
```

VERIFY after each step:
```bash
npm run dev    # no errors in console
# Check browser at localhost:3000
```

AFTER ALL STEPS:
```bash
npm run build  # production build succeeds
npx tsc --noEmit  # TypeScript clean
```

---

## Files Summary

| File | Purpose |
|------|---------|
| `src/lib/ws.ts` | WebSocket singleton with auto-reconnect |
| `src/lib/api.ts` | REST client for /snapshot, /symbol, /health |
| `src/lib/format.ts` | Number formatting (commas, %, PKR) |
| `src/types/market.ts` | TypeScript interfaces |
| `src/stores/marketStore.ts` | Zustand store — symbols, breadth, movers |
| `src/stores/indexStore.ts` | Zustand store — indices, sparklines |
| `src/hooks/useWebSocket.ts` | Hook — manage WS connection lifecycle |
| `src/hooks/useMarketData.ts` | Hook — subscribe to /ws/ticks |
| `src/hooks/useIndices.ts` | Hook — subscribe to /ws/indices |
| `src/hooks/useSymbol.ts` | Hook — subscribe to /ws/symbol/{sym} |
| `src/components/Layout.tsx` | Top bar + nav + connection badge |
| `src/components/ConnectionBadge.tsx` | Live/disconnected indicator |
| `src/components/IndexHero.tsx` | KSE-100 large card with sparkline |
| `src/components/IndexCard.tsx` | Secondary index card |
| `src/components/BreadthBar.tsx` | Gainers/losers visual bar |
| `src/components/TopMovers.tsx` | Gainers/losers/active columns |
| `src/components/MarketTable.tsx` | Virtualized 500+ row table |
| `src/components/PriceCell.tsx` | Animated price cell |
| `src/components/SparklineChart.tsx` | Inline sparkline |
| `src/components/CandlestickChart.tsx` | TradingView chart wrapper |
| `src/components/HeatmapGrid.tsx` | Sector color blocks |
| `src/components/SearchBar.tsx` | Symbol search autocomplete |
| `src/pages/Dashboard.tsx` | Landing — indices + breadth + movers |
| `src/pages/LiveMarket.tsx` | Full market table |
| `src/pages/SymbolDetail.tsx` | Symbol chart + depth + tick log |
| `src/pages/Heatmap.tsx` | Sector heatmap |
| `src/App.tsx` | Router + layout wrapper |
| `src/main.tsx` | Entry point |
| `src/index.css` | Tailwind + theme + animations |

**~28 files. Zero backend. All data from ws://localhost:8765.**
