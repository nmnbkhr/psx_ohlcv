# Claude Code Prompt: PSX Live Terminal — Step 4/4: Sector Heatmap

## What this is

Step 4 — Build the sector heatmap page. Treemap-style grid showing all PSX sectors colored by average change%, with live updates from the WebSocket.

**After this step:** Full trading terminal complete — Dashboard, Market, Symbol Detail, and Heatmap all working with real-time data.

**Prerequisite:** Steps 1-3 completed. Dashboard, Market table, and Symbol Detail all working.

## PSX Sector Mapping

Hardcode this sector-to-symbol mapping. These are the major PSX sectors:

```typescript
// src/lib/sectors.ts

export const SECTOR_MAP: Record<string, string[]> = {
  "Banks": ["HBL", "UBL", "MCB", "ABL", "BAHL", "MEBL", "NBP", "BAFL", "AKBL", "BOP", "SNBL", "JSBL", "BIPL", "SILK", "FABL"],
  "Oil & Gas": ["OGDC", "PPL", "MARI", "POL", "SSGC", "SNGP", "BYCO", "APL", "ATRL"],
  "Cement": ["LUCK", "DGKC", "MLCF", "FCCL", "ACPL", "KOHC", "PIOC", "CHCC", "BWCL", "FLYNG"],
  "Fertilizer": ["EFERT", "FFC", "ENGRO", "FATIMA", "FFBL"],
  "Power & Energy": ["HUBC", "KEL", "KAPCO", "NCPL", "NPL", "EPQL", "PKGP"],
  "Technology": ["SYS", "NETSOL", "TRG", "AVN"],
  "Textile": ["NML", "GATM", "NCL", "KTML", "CTM", "ILP"],
  "Chemicals": ["EPCL", "ICI", "LOTCHEM", "DOL", "AKZO"],
  "Pharma": ["SEARL", "AGP", "GLAXO", "HINOON", "FEROZ"],
  "Automobile": ["INDU", "PSMC", "HCAR", "MTL", "GHNL", "GHNI"],
  "Food & Consumer": ["NESTLE", "FML", "UNITY", "QUICE", "TREET", "CLOV"],
  "Insurance": ["AICL", "EFU", "JSGCL", "PKLI", "PREL"],
  "Telecom": ["PTC", "TELE", "WTL"],
  "Steel": ["ISL", "MUGHAL", "ASTL", "DSL", "ISIL"],
};

// Index for reverse lookup: symbol → sector
export const SYMBOL_TO_SECTOR: Record<string, string> = {};
for (const [sector, symbols] of Object.entries(SECTOR_MAP)) {
  for (const sym of symbols) {
    SYMBOL_TO_SECTOR[sym] = sector;
  }
}
```

## Heatmap Page — `src/pages/Heatmap.tsx`

### Data aggregation

Read from `marketStore.symbols` (already populated by useMarketData in Layout).

For each sector:
```typescript
interface SectorBlock {
  name: string;
  symbols: string[];           // symbols found in market data
  avgChange: number;           // average changePercent of constituent stocks
  totalVolume: number;         // sum of volumes
  stockCount: number;          // how many symbols have data
  topStock: string;            // highest volume stock in sector
  topStockChange: number;      // that stock's change%
}
```

Aggregate by iterating marketStore symbols and grouping by SYMBOL_TO_SECTOR lookup.
Recalculate every 5 seconds (not every tick — use setInterval + store subscription).

### Layout

```
┌──────────────────────────────────────────────────────────────┐
│  SECTOR HEATMAP              Last updated: 12:34:56 PKT      │
│  Size: [Volume ▾] [Equal]    Color: Change %                 │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌──────────────┐ ┌──────────┐ ┌────────────┐ ┌──────────┐ │
│  │              │ │          │ │            │ │          │ │
│  │    Banks     │ │  Oil &   │ │  Cement    │ │ Fertil-  │ │
│  │   +1.45%    │ │   Gas    │ │  -0.32%   │ │  izer    │ │
│  │   15 stocks │ │  +2.10%  │ │  10 stocks│ │ +0.89%   │ │
│  │              │ │          │ │            │ │          │ │
│  ├──────────────┤ ├──────────┤ ├────────────┤ ├──────────┤ │
│  │  Power  │Tech│ │  Textile │ │  Chemical  │ │ Pharma   │ │
│  │ +0.67%  │+3%│ │  -1.20%  │ │  +0.44%   │ │ -0.15%   │ │
│  ├─────────┤───┤ ├──────────┤ ├──────┬─────┤ ├──────────┤ │
│  │  Auto   │Ins│ │  Food    │ │Telcm │Steel│ │          │ │
│  │ -0.55%  │+1%│ │  +0.22%  │ │-0.8% │+1.5%│ │          │ │
│  └─────────┴───┘ └──────────┘ └──────┴─────┘ └──────────┘ │
│                                                              │
│  ◄──── -3% ════ -1% ════ 0% ════ +1% ════ +3% ────►        │
│        Deep Red    Light Red   Gray  Light Grn  Deep Green   │
└──────────────────────────────────────────────────────────────┘
```

### HeatmapGrid Component — `src/components/HeatmapGrid.tsx`

Props: `sectors: SectorBlock[]`, `sizeMode: "volume" | "equal"`

**Grid approach (simpler than true treemap):**

Use CSS Grid with areas sized by volume (or equal). 

For "equal" mode: `grid-template-columns: repeat(auto-fill, minmax(200px, 1fr))`
For "volume" mode: Calculate relative column/row spans based on totalVolume.

Each sector cell:
- **Background color** based on avgChange:
  ```
  avgChange >= +3%  → #166534 (deep green)
  avgChange >= +1%  → #22c55e (green)  
  avgChange >= +0.2% → #4ade80 (light green)
  avgChange >= -0.2% → #6b7280 (gray)
  avgChange >= -1%  → #ef4444 (red)
  avgChange >= -3%  → #991b1b (deep red)
  below -3%         → #7f1d1d (darkest red)
  ```
  Use a smooth gradient function, not hard steps:
  ```typescript
  function getHeatColor(change: number): string {
    // Clamp to -5% to +5%
    const clamped = Math.max(-5, Math.min(5, change));
    if (clamped >= 0) {
      const intensity = Math.min(clamped / 3, 1); // 0 to 1
      // Interpolate from gray (#374151) to green (#166534)
      return interpolateColor('#374151', '#166534', intensity);
    } else {
      const intensity = Math.min(Math.abs(clamped) / 3, 1);
      return interpolateColor('#374151', '#991b1b', intensity);
    }
  }
  ```

- **Content inside cell:**
  - Sector name (white, bold, text-lg)
  - Average change% (white, text-sm)
  - Stock count (muted, text-xs): "15 stocks"
  - Top stock badge (very small): "HUBC +2.1%"

- **Hover:** 
  - Border glow effect (box-shadow)
  - Tooltip or expanded view showing all symbols in that sector with individual changes

- **Click sector** → expand to show individual stocks:
  - Replace the sector grid with a detailed view of that sector
  - Show each symbol as a smaller colored block
  - Back button to return to sector view
  - OR: use a modal/slide-out panel

### Toolbar

- **Size toggle:** "Volume" (blocks proportional to volume) vs "Equal" (all same size)
  - Default: Equal (simpler, more readable)
- **Last updated timestamp**
- **Total stats:** "489 symbols across 14 sectors | Avg market change: +1.05%"

### Color Legend — `src/components/HeatmapLegend.tsx`

Horizontal gradient bar at the bottom:
```
  -3%        -1%         0%         +1%        +3%
  [Deep Red ──── Red ──── Gray ──── Green ──── Deep Green]
```

Use a CSS linear-gradient background on a thin bar (height 12px, rounded).
Labels positioned below at intervals.

### Sector Drill-down (click to expand)

When user clicks a sector block:

Option A (simpler — use this): Replace heatmap with a sector detail view:
```
┌──────────────────────────────────────────────────────────┐
│  ← Back to Heatmap     BANKS SECTOR    Avg: +1.45%       │
├──────────────────────────────────────────────────────────┤
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐          │
│  │ HBL  │ │ UBL  │ │ MCB  │ │ ABL  │ │ BAHL │          │
│  │+2.1% │ │+1.8% │ │+0.9% │ │+1.2% │ │+0.5% │          │
│  │██████│ │█████ │ │████  │ │████  │ │███   │          │
│  └──────┘ └──────┘ └──────┘ └──────┘ └──────┘          │
│  ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐          │
│  │ MEBL │ │ NBP  │ │ BAFL │ │ AKBL │ │ BOP  │          │
│  │-0.3% │ │+0.7% │ │+1.1% │ │-0.1% │ │+0.4% │          │
│  └──────┘ └──────┘ └──────┘ └──────┘ └──────┘          │
└──────────────────────────────────────────────────────────┘
```

Each stock block: colored by its own change%, shows symbol + change%.
Click any stock → navigate to `/symbol/{symbol}`.
Back button → return to sector heatmap.

Use React state: `selectedSector: string | null`. If null → show heatmap. If set → show drill-down.

---

## Final Polish (after all 4 steps)

Once Step 4 is done, do a final review pass:

1. **Responsive:** Test at mobile width (375px). Dashboard should stack vertically. Market table should be scrollable horizontally. Heatmap blocks should reflow.

2. **Empty state:** If no data (relay not running), show friendly messages:
   - "Waiting for market data... Is tick_service.py running?"
   - Not blank screens or error crashes

3. **Loading state:** On initial page load, show skeleton/loading before snapshot arrives.

4. **Error boundaries:** Wrap pages in error boundaries so one crash doesn't kill the whole app.

5. **Favicon:** Add a simple 📈 emoji or chart favicon.

6. **Title:** `<title>PSX Live Terminal</title>` in index.html.

---

## VERIFY

```bash
cd ~/projects/psx-live
npm run dev

# With tick_service running:

# 1. Dashboard: KSE-100 hero + indices + breadth + movers ✓
# 2. Market: 500+ symbols, flash animations, sort, filter, search ✓
# 3. Symbol: Live candlestick chart, tick log, back button ✓
# 4. Heatmap: Sector blocks colored by change%, click to drill down ✓
# 5. Connection badge: 🟢 LIVE ✓
# 6. Navigate between all pages — no errors ✓
# 7. Mobile view — responsive ✓

# Production build
npm run build     # succeeds, no errors
npx tsc --noEmit  # clean TypeScript

# Check bundle size
ls -la dist/assets/
```

## Files created/modified in this step

| Action | File | Purpose |
|--------|------|---------|
| CREATE | `src/lib/sectors.ts` | Sector-to-symbol mapping |
| CREATE | `src/components/HeatmapGrid.tsx` | Sector color blocks |
| CREATE | `src/components/HeatmapLegend.tsx` | Color scale legend |
| MODIFY | `src/pages/Heatmap.tsx` | Full heatmap page with drill-down |
| MODIFY | `index.html` | Title + favicon |

## All 4 Steps Complete — Full File List

```
~/projects/psx-live/src/
├── main.tsx                          # Step 1
├── App.tsx                           # Step 1
├── index.css                         # Step 1
├── types/
│   └── market.ts                     # Step 1
├── lib/
│   ├── ws.ts                         # Step 1
│   ├── api.ts                        # Step 1
│   ├── format.ts                     # Step 1
│   └── sectors.ts                    # Step 4
├── stores/
│   ├── marketStore.ts                # Step 2
│   └── indexStore.ts                 # Step 2
├── hooks/
│   ├── useMarketData.ts              # Step 2
│   ├── useIndices.ts                 # Step 2
│   └── useSymbol.ts                  # Step 3
├── components/
│   ├── Layout.tsx                    # Step 1
│   ├── ConnectionBadge.tsx           # Step 1
│   ├── IndexHero.tsx                 # Step 2
│   ├── IndexCard.tsx                 # Step 2
│   ├── BreadthBar.tsx                # Step 2
│   ├── TopMovers.tsx                 # Step 2
│   ├── SparklineChart.tsx            # Step 2
│   ├── MarketTable.tsx               # Step 3
│   ├── PriceCell.tsx                 # Step 3
│   ├── SearchBar.tsx                 # Step 3
│   ├── CandlestickChart.tsx          # Step 3
│   ├── HeatmapGrid.tsx              # Step 4
│   └── HeatmapLegend.tsx            # Step 4
├── pages/
│   ├── Dashboard.tsx                 # Step 2
│   ├── LiveMarket.tsx                # Step 3
│   ├── SymbolDetail.tsx              # Step 3
│   └── Heatmap.tsx                   # Step 4
```

**28 source files. Zero backend. All data from ws://localhost:8765.**
