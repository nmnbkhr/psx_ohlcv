# Claude Code Prompt: Tick Data Fixes — 3 Remaining Items

## Context

Tick data audit is complete. DuckDB ohlcv_5s sync is done (366K new rows merged).
Three fixes remain.

## Fix 1: Create ~/sync_psx_cloud.sh

This script does NOT exist. It downloads tick data from Oracle Cloud VM to local.

```bash
cat > ~/sync_psx_cloud.sh << 'SCRIPT'
#!/bin/bash
echo "📥 Syncing PSX data from Oracle Cloud..."
echo ""

# 1. JSONL tick files (normalized + raw WebSocket)
echo "═══ Tick JSONL files ═══"
rsync -avz --progress psx-cloud:~/psxdata/tick_logs/ /mnt/e/psxdata/tick_logs_cloud/

# 2. tick_bars.db (ohlcv_5s, index tables — cloud tick_service writes here)
echo ""
echo "═══ tick_bars.db ═══"
rsync -avz --progress psx-cloud:~/psxdata/tick_bars.db /mnt/e/psxdata/tick_bars.db

echo ""
echo "✅ Sync complete"
echo ""
echo "JSONL files:"
ls -lh /mnt/e/psxdata/tick_logs_cloud/*.jsonl 2>/dev/null | tail -5
echo ""
echo "tick_bars.db:"
ls -lh /mnt/e/psxdata/tick_bars.db
echo ""
echo "Next steps:"
echo "  1. Open Tick Analytics → Sync tab"
echo "  2. Click 'Sync tick_bars.db → DuckDB'"
echo "  3. Click 'Import ALL Missing Dates → DuckDB'"
SCRIPT
chmod +x ~/sync_psx_cloud.sh
echo "✅ Created ~/sync_psx_cloud.sh"
```

## Fix 2: Fix signal_dashboard.py — Use DuckDB instead of SQLite

signal_dashboard.py currently reads from `psx.sqlite tick_logs` (2.5M rows).
DuckDB `tick_logs` has 4.6M rows — more complete data.

```bash
# Find the SQLite tick_logs queries in signal_dashboard.py
grep -n "tick_logs\|psx\.sqlite\|sqlite3\|sqlite_query" \
    ~/pakfindata/src/pakfindata/ui/page_views/signal_dashboard.py | head -20
```

**Read the output. Then for each SQLite tick_logs query:**

Replace:
```python
# Old — SQLite (slow, fewer rows)
con = sqlite3.connect("/mnt/e/psxdata/psx.sqlite")
df = pd.read_sql("SELECT ... FROM tick_logs WHERE ...", con)
con.close()
```

With:
```python
# New — DuckDB (fast, 4.6M rows)
from pakfindata.db.connections import duck
df = duck("SELECT ... FROM tick_logs WHERE ...")
```

If the page uses `sqlite_query()` from connections.py, replace with `duck()`.

**Important:** Only change tick_logs queries. Don't touch other queries that 
correctly read from SQLite (signal_configs, companies, etc.).

## Fix 3: Add "Sync tick_bars.db → DuckDB" button in Tick Analytics Sync tab

```bash
# Find the Sync section in tick_analytics.py
grep -n "Sync\|sync\|import.*duck\|Import.*Duck\|Missing" \
    ~/pakfindata/src/pakfindata/ui/page_views/tick_analytics.py | head -20
```

**Read the Sync tab code. Then add a NEW section BEFORE the JSONL import section:**

```python
# ── Sync tick_bars.db → DuckDB (ohlcv_5s + index tables) ──
st.markdown("#### Sync tick_bars.db → DuckDB")
st.caption("Merges new ohlcv_5s, index_ohlcv_5s, index_raw_ticks from tick_bars.db into DuckDB.")

col1, col2 = st.columns([1, 1])

# Show current counts
try:
    from pakfindata.db.connections import duck
    duck_counts = duck("""
        SELECT 'ohlcv_5s' as tbl, COUNT(*) as cnt FROM ohlcv_5s
        UNION ALL SELECT 'index_ohlcv_5s', COUNT(*) FROM index_ohlcv_5s
        UNION ALL SELECT 'index_raw_ticks', COUNT(*) FROM index_raw_ticks
    """)
    for _, row in duck_counts.iterrows():
        col1.metric(f"DuckDB {row['tbl']}", f"{int(row['cnt']):,}")
except:
    col1.warning("Could not read DuckDB counts")

# Show tick_bars.db counts
try:
    import sqlite3
    tcon = sqlite3.connect("/mnt/e/psxdata/tick_bars.db")
    for tbl in ["ohlcv_5s", "index_ohlcv_5s", "index_raw_ticks"]:
        cnt = tcon.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
        col2.metric(f"tick_bars.db {tbl}", f"{cnt:,}")
    tcon.close()
except:
    col2.warning("Could not read tick_bars.db counts")

if st.button("🔄 Sync tick_bars.db → DuckDB", type="primary"):
    with st.spinner("Merging tick_bars.db into DuckDB..."):
        try:
            import duckdb
            import shutil
            from pathlib import Path
            
            DUCKDB_PATH = Path("/mnt/e/psxdata/pakfindata.duckdb")
            TICK_DB_PATH = Path("/mnt/e/psxdata/tick_bars.db")
            
            # Copy both to /tmp for fast I/O (avoids USB drive slowness)
            shutil.copy2(DUCKDB_PATH, "/tmp/merge_pakfindata.duckdb")
            shutil.copy2(TICK_DB_PATH, "/tmp/merge_tick_bars.db")
            
            con = duckdb.connect("/tmp/merge_pakfindata.duckdb")
            con.execute("INSTALL sqlite; LOAD sqlite;")
            con.execute("ATTACH '/tmp/merge_tick_bars.db' AS tdb (TYPE sqlite, READ_ONLY)")
            
            results = []
            for table in ["ohlcv_5s", "index_ohlcv_5s", "index_raw_ticks"]:
                before = con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                
                # Get max ts in DuckDB to only insert newer rows
                max_ts = con.execute(f"SELECT COALESCE(MAX(ts), '') FROM {table}").fetchone()[0]
                
                if max_ts:
                    con.execute(f"""
                        INSERT OR IGNORE INTO {table}
                        SELECT * FROM tdb.{table} WHERE ts > '{max_ts}'
                    """)
                else:
                    con.execute(f"""
                        INSERT OR IGNORE INTO {table}
                        SELECT * FROM tdb.{table}
                    """)
                
                after = con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                added = after - before
                results.append(f"{table}: {before:,} → {after:,} (+{added:,})")
            
            con.execute("DETACH tdb")
            con.close()
            
            # Copy merged DuckDB back
            shutil.copy2("/tmp/merge_pakfindata.duckdb", DUCKDB_PATH)
            
            # Cleanup
            Path("/tmp/merge_pakfindata.duckdb").unlink(missing_ok=True)
            Path("/tmp/merge_tick_bars.db").unlink(missing_ok=True)
            
            for r in results:
                st.success(r)
                
        except Exception as e:
            st.error(f"Sync failed: {e}")

st.divider()
```

**Place this ABOVE the existing "JSONL → DuckDB tick_logs" section.**

## Verify

```bash
# 1. Sync script exists and is executable
ls -la ~/sync_psx_cloud.sh

# 2. signal_dashboard.py uses DuckDB for tick_logs
grep -n "duck\|Duck\|tick_logs" ~/pakfindata/src/pakfindata/ui/page_views/signal_dashboard.py | head -10

# 3. Tick Analytics Sync tab has new button
grep -n "tick_bars\|Sync tick_bars\|merge" ~/pakfindata/src/pakfindata/ui/page_views/tick_analytics.py | head -10

# 4. Run the app and test
cd ~/pakfindata && streamlit run src/pakfindata/ui/app.py
# Navigate to Tick Analytics → Sync → verify "Sync tick_bars.db → DuckDB" button appears
# Navigate to Signal Analysis → verify it loads data (uses DuckDB now)
```

## DO NOT

- Do NOT modify tick_service.py
- Do NOT modify tick_bars.db or psx.sqlite 
- Do NOT delete any data
- Do NOT change the JSONL import buttons (they already work)
- Do NOT touch intraday.py or microstructure.py
