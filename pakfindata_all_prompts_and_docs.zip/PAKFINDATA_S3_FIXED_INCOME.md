# pakfindata — Section 3: Fixed Income

## Pakistan's Bond Market Intelligence

Pakistan's bond market is 99% OTC — not exchange-traded. Data comes from SBP, not PSX. This makes fixed income data harder to access than equities. pakfindata solves this by integrating SBP EasyData API (195 datasets, 18,000+ series), MUFAP revaluation rates, and PSX debt market data into a unified terminal.

---

## Page 1: Rates Overview

### What You See

**SBP Policy Rate Corridor — four key rates:**
- POLICY RATE: 10.5%
- CEILING (Reverse Repo): 11.5%
- FLOOR (Repo): 9.5%
- OVERNIGHT WA REPO: 10.25%

**Money Market Rates — KIBOR bid/offer:**

| Tenor | Bid | Offer |
|-------|-----|-------|
| KIBOR 3M | 11.09% | 11.34% |
| KIBOR 6M | 11.18% | 11.43% |
| KIBOR 1Y | 11.33% | 11.83% |

**Government Securities — Latest Auction Cutoffs:**

T-Bills (MTB): 3M 11.50%, 6M 11.50%, 12M 11.50% — flat across tenors.
PIBs: 2Y 10.34%, 3Y 10.25%, 5Y 10.75%, 10Y 11.24%, 15Y 11.50% — inverted at the belly.

**Quick navigation tabs:** Yield Curves, Auction History, Rate Trends.

### Business Value

A bank treasurer opens this page at 9 AM. In 5 seconds: policy rate 10.5%, KIBOR 3M offer 11.34%, T-Bill 3M cutoff 11.50%, PIB 5Y at 10.75%. The entire Pakistan interest rate environment on one screen.

**Critical insight visible:** T-Bills flat at 11.50% across all tenors while PIBs are inverted (2Y at 10.34% vs 15Y at 11.50%) — the market expects rate cuts in the medium term. This shapes the entire ALM strategy.

### Target Audience

Bank treasury desks, ALM teams, corporate treasurers, fixed income portfolio managers, money market dealers, central bank watchers.

---

## Page 2: Yield Curve

### What You See

**Curve Selector:** PKRV (Government) or PKISRV (Islamic), with date picker (2026-03-25).

**Term Structure Chart:** Interactive yield curve from 1M to 15Y showing the PKRV government curve:
- Short end (1M-12M): ~11.48-11.50% — flat, anchored to SBP policy rate
- Belly (2Y-3Y): **sharp dip to 10.2%** — the market is pricing aggressive rate cuts
- Long end (5Y-15Y): rising from 10.7% to 11.5% — term premium reasserting

**Summary Cards:**
- SHORT TERM (<1Y): 11.49%
- MEDIUM TERM (1-5Y): 10.70%
- LONG TERM (>5Y): 11.16%
- SPREAD (BPS): **-33** — inverted (short above long)

**Curve Points Table:** Every PKRV tenor with exact yields:

| Tenor | Days | Yield |
|-------|------|-------|
| 1M | 30 | 11.4795% |
| 3M | 91 | 11.5000% |
| 6M | 182 | 11.4998% |
| 1Y | 365 | 11.5000% |
| 2Y | ... | 10.34% |
| 3Y | ... | 10.25% |
| 5Y | ... | 10.75% |
| 10Y | ... | 11.24% |
| 15Y | ... | 11.50% |

**Compare mode:** Overlay two dates to see curve shifts.

### Business Value

This is the most important page for fixed income professionals in Pakistan. The yield curve tells you:

1. **Rate expectations:** The 3Y dip to 10.2% means the market expects SBP to cut from 10.5% to below 10% within 2-3 years
2. **Relative value:** Where on the curve to be long/short. The belly (2-3Y) is aggressively priced — if cuts are delayed, that's where losses concentrate
3. **Slope:** -33 bps inversion signals economic deceleration expectations
4. **Bond pricing:** Every fixed income instrument in Pakistan is priced off this curve. PKRV is the benchmark

Previously this data required a Bloomberg terminal or manual MUFAP website scraping. Now it's interactive, date-selectable, and comparable.

### Target Audience

Fixed income traders, bond portfolio managers, ALM teams (duration matching), insurance companies (liability-driven investing), pension funds, mutual fund managers, debt capital markets teams.

---

## Page 3: Treasury Terminal

### What You See

**Eight tabs:** Overview, Yield Curves, Auctions, KIBOR, Spreads, Global Rates, Bonds, Sync.

**Overview tab — Rate Dashboard:**
- SBP Policy Rate: 10.5% (last changed 2026-01-30, 54 days ago)
- KIBOR 3M: 11.34% (bid 11.09%, as of 2026-03-19)
- T-Bill 3M: 11.50% (auction 2026-03-16)
- KONIA (O/N): 10.25% (2026-03-25)
- PKRV 10Y: 11.24% (2026-03-25)
- SOFR: N/A

**Rate History Chart (20+ years):** Policy Rate (red step line), KIBOR 3M (gray), KONIA (blue), T-Bill 3M (dots) — from 2003 to 2026. Visible cycles:
- 2005-2008: rates rising from 8% to 15%
- 2009-2010: crisis cut to 5.5%
- 2011-2015: range-bound 9-12%
- 2019-2020: rate hiking cycle to 13.25%, then COVID cut to 7%
- 2022-2024: extreme tightening to 22% (highest in history)
- 2025-2026: easing cycle back to 10.5%

**SBP Policy Rate Timeline:** Annotated chart showing every rate change with basis point moves (+100bp, -150bp, etc.) in green (cuts) and red (hikes).

### Business Value

20 years of Pakistan rate history in one chart. A macro strategist can:
- Identify where we are in the cycle (easing phase, -1150 bps from peak of 22%)
- Compare current KIBOR-Policy spread to historical norms
- See how KONIA tracks the policy rate corridor
- Plan investment strategy based on rate cycle positioning

The annotated timeline with basis point moves is a research tool — "SBP has cut 1,150 bps since June 2024, how much more is priced in?" Answer: look at the 3Y PIB at 10.25% vs current policy at 10.5% — market expects another ~25 bps.

### Target Audience

Macro economists, fixed income strategists, banking ALM, treasury heads, investment committees, academic researchers, SBP watchers, financial journalists.

---

## Page 4: OTC Bond Market

### What You See

**SBP Policy Rate Corridor:** Same four rates (Policy 10.5%, Ceiling 11.5%, Floor 9.5%, Overnight WA Repo 10.25%).

**KIBOR Rates with Bid/Offer:**
- KIBOR 3M: 11.34% (bid 11.09%)
- KIBOR 6M: 11.43% (bid 11.18%)
- KIBOR 12M: 11.83% (bid 11.33%)

**Pakistan Sovereign Yield Curve:** Combined MTB (blue dots), PIB (red dots), and PKRV (yellow line) on one chart. The PKRV curve smoothly interpolates between the auction cutoff points.

**Sync from SBP:** Expandable section for data refresh.

### Business Value

The definitive view of Pakistan's sovereign curve. Three data sources (MTB cutoffs, PIB cutoffs, PKRV interpolated) plotted together show:
- Where auction cutoffs sit vs the smooth PKRV curve (potential trading signals)
- Gaps between MTB and PIB curves (market segmentation)
- The full term structure from overnight to 15Y

For a bond trader, seeing the MTB cutoff above the PKRV curve at 3M means T-Bills are trading cheap to the benchmark — a potential buy signal.

### Target Audience

Bond traders, primary dealers, fixed income portfolio managers, risk managers computing PV01 sensitivities.

---

## Page 5: Debt Intelligence Terminal

### What You See

**Three views:** Treasury, Investor, Quant — each tailored for different users.

**Treasury View (default):**
- 160 securities in the database
- Benchmark rates: KIBOR 6M (11.43%), KIBOR 1Y (11.83%), PKRV 5Y (10.75%)
- 19 securities with active data, 9 traded
- Curve Shift: +0 bps

**Security Blotter:** List of all debt securities (scrollable).

**Security Detail panel (example: P03FRR300528):**
- Name: "3 Year Fixed Rental Rate Mat. 30-05-2028"
- Badges: **ISLAMIC**, **SLR ELIGIBLE**
- Clean Price, Accrued Interest, Dirty Price, Days to Maturity
- YTM (Yield to Maturity), I-Spread, Modified Duration, 1% Shift PV Impact
- Signal: **CHEAP** (green badge — below fair value based on curve)
- Treasury View: SLR Eligible = Yes, Benchmark = IFRV 8...

### Business Value

This is a **Bloomberg PORT equivalent for Pakistan debt** — a security-level bond terminal with:

1. **Rich/Cheap analysis:** Each security gets a CHEAP or RICH signal based on its yield vs the interpolated curve. A bond trader scans for CHEAP signals — potential alpha
2. **Islamic filter:** Instantly identify Sharia-compliant securities for Islamic banks' SLR compliance
3. **SLR eligibility:** Pakistani banks must maintain Statutory Liquidity Requirements in eligible government securities. This filter is critical for treasury compliance
4. **Risk metrics:** Modified duration, I-Spread, PV01 — the building blocks of fixed income portfolio management
5. **160 securities:** Full coverage of Pakistan's listed and OTC debt

No other free platform in Pakistan provides security-level bond analytics with CHEAP/RICH signals. Bloomberg charges $24,000/year for this.

### Target Audience

Bank treasury desks (the primary users — every bank in Pakistan has a treasury), primary dealers (8 banks that participate in SBP auctions), fixed income mutual fund managers, insurance investment teams, pension fund fixed income allocators, SECP/SBP regulatory teams.

---

## Section Summary: Fixed Income

| Page | Primary Data | Key Feature | Bloomberg Equivalent |
|------|-------------|-------------|---------------------|
| Rates Overview | SBP, KIBOR, T-Bill, PIB | One-screen rate environment | BTMM<GO> |
| Yield Curve | PKRV/PKISRV term structure | Interactive with Compare mode | GC<GO> |
| Treasury Terminal | 20-year rate history | SBP timeline with bp annotations | FXIP<GO> |
| OTC Bond Market | MTB + PIB + PKRV combined | Sovereign curve composite | GLC<GO> |
| Debt Terminal | 160 securities with analytics | CHEAP/RICH signals, Islamic/SLR filters | PORT<GO> |

**Why this matters for Pakistan:**

Pakistan's debt market is Rs. 50+ trillion. Every bank, insurance company, mutual fund, and pension fund has fixed income exposure. Yet the tools available are:
- SBP website (raw data, no analytics)
- MUFAP (revaluation rates only)
- PSX DPS (only exchange-traded debt — 1% of the market)
- Bloomberg ($24K/year, only 20-30 Pakistani institutions subscribe)

pakfindata fills this gap with institutional-grade fixed income analytics at zero cost. The Debt Terminal's CHEAP/RICH signals alone could generate alpha for any bank treasury operating without Bloomberg.

**Estimated value:** A bank treasury desk making one additional profitable trade per month based on CHEAP/RICH signals — at Rs. 10M notional with 25bps improvement — generates Rs. 300,000/month in incremental P&L. That's the value of one page.

---

*Section 4: FX & Rates — coming next.*
